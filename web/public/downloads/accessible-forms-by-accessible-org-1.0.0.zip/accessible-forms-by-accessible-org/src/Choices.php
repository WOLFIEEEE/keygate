<?php
/** Choice values stay stable when their visible labels change. @package AccessibleForms */
namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
class Choices {
	public static function sanitize( array $field, array $legacy ) {
		$rows   = $field['choices'] ?? null;
		$values = array();
		$labels = array();
		$errors = array();
		if ( is_array( $rows ) ) {
			if ( count( $rows ) > 100 ) {
				$errors[] = __( 'Use no more than 100 choices per field.', 'accessible-forms-by-accessible-org' );
			}
			foreach ( array_slice( $rows, 0, 100 ) as $row ) {
				if ( ! is_array( $row ) ) {
					continue;
				}
				$label = FormOptions::text( $row['label'] ?? '', 500 );
				if ( '' === $label ) {
					continue;
				}
				if ( ! Schema::meaningful( $label ) ) {
					$errors[] = __( 'write each choice in words or numbers, not only symbols.', 'accessible-forms-by-accessible-org' );
					continue;
				}
				$value = FormOptions::text( $row['value'] ?? '', 500 ) ?: 'o_' . bin2hex( random_bytes( 8 ) );
				if ( isset( $labels[ $value ] ) || in_array( $label, $labels, true ) ) {
					$errors[] = __( 'Give each choice a distinct label and identity.', 'accessible-forms-by-accessible-org' );
					continue;
				}
				$values[]         = $value;
				$labels[ $value ] = $label;
			}
		} else {
			$values = $legacy;
			foreach ( $values as $value ) {
				$labels[ $value ] = FormOptions::text( $field['option_labels'][ $value ] ?? $value, 500 );
				if ( ! Schema::meaningful( $labels[ $value ] ) ) {
					$errors[] = __( 'write each choice in words or numbers, not only symbols.', 'accessible-forms-by-accessible-org' );
				}
			}
			$errors = array_values( array_unique( $errors ) );
		}
		return array( $values, $labels, $errors );
	}
	public static function label( array $field, $value ) {
		return $field['option_labels'][ $value ] ?? $value;
	}
	public static function display( array $schema, array $values ) {
		foreach ( $schema['fields'] ?? array() as $field ) {
			$name = $field['name'];
			if ( ! array_key_exists( $name, $values ) || empty( $field['option_labels'] ) ) {
				continue;
			}
			$values[ $name ] = is_array( $values[ $name ] )
				? array_map(
					static function ( $value ) use ( $field ) {
						return self::label( $field, $value );
					},
					$values[ $name ]
				)
				: self::label( $field, $values[ $name ] );
		}
		return $values;
	}
}
