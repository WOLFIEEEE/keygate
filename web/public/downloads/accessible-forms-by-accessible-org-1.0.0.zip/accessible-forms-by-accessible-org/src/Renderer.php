<?php
/**
 * Accessible markup generation.
 *
 * Every value is escaped where it is written. Markup choices (visible labels,
 * grouped choices, linked error summary, no duplicate announcements) are
 * covered by the plugin's accessibility test suite.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Renders a form as HTML.
 */
class Renderer {
	/**
	 * Shown when a visitor submits to a form that no longer exists.
	 *
	 * Focus moves to the message (it carries no live-region role), and any
	 * unsent answers are listed so they can be copied.
	 *
	 * @param int    $id     Form post ID.
	 * @param string $prefix Instance ID prefix.
	 * @param array  $values Unsent answers.
	 * @return string
	 */
	private static function unavailable( $id, $prefix, array $values ) {
		$message = $values
			? __( 'This form is unavailable. These answers have not been sent. Copy them before leaving this page.', 'accessible-forms-by-accessible-org' )
			: __( 'This form is unavailable. Your message has not been sent.', 'accessible-forms-by-accessible-org' );

		$out =
			'<div class="af-wrap" data-af-instance="' .
			esc_attr( $prefix ) .
			'" data-af-form="' .
			absint( $id ) .
			'"><p class="af-summary" id="' .
			esc_attr( $prefix . '-summary' ) .
			'" tabindex="-1">' .
			esc_html( $message ) .
			'</p>';
		if ( ! $values ) {
			return $out . '</div>';
		}
		$out .= '<dl>';
		foreach ( array_slice( $values, 0, 50, true ) as $key => $value ) {
			$out .=
				'<dt>' .
				esc_html( $key ) .
				'</dt><dd>' .
				esc_html( is_array( $value ) ? implode( ', ', array_filter( $value, 'is_scalar' ) ) : $value ) .
				'</dd>';
		}
		return $out . '</dl></div>';
	}

	/**
	 * Shown instead of the form while it is closed, full or not yet open.
	 *
	 * The message is part of the page, not a change to it, so it needs no
	 * focus move or live region. It keeps the form's heading for context and
	 * its checked colours for contrast.
	 *
	 * @param int   $form_id Form post ID.
	 * @param array $schema  Form schema.
	 * @return string
	 */
	private static function closed( $form_id, array $schema ) {
		$level = $schema['heading_level'] ?? 'h2';
		$out   =
			'<div class="af-wrap af-width-' .
			esc_attr( $schema['layout']['width'] ?? 'comfortable' ) .
			'" style="' .
			esc_attr( Appearance::css( $schema['appearance'] ?? array() ) ) .
			'" data-af-form="' .
			esc_attr( (string) $form_id ) .
			'">';
		if ( 'none' !== $level ) {
			$tag  = in_array( $level, array( 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $level : 'h2';
			$out .= '<' . $tag . ' class="af-heading">' . esc_html( $schema['heading'] ) . '</' . $tag . '>';
		}
		return $out . '<p class="af-unavailable">' . esc_html( $schema['closed_message'] ) . '</p></div>';
	}

	/**
	 * A message for visitors without JavaScript.
	 *
	 * The <noscript> sits in its own block and holds only inline content, so
	 * wpautop() run over the rendered form (by a theme or page builder) finds
	 * nothing to wrap in a stray paragraph.
	 *
	 * @param string $html Escaped inline HTML.
	 * @return string
	 */
	public static function noscript( $html ) {
		return '<div class="af-noscript"><noscript><span class="af-help">' . $html . '</span></noscript></div>';
	}

	/**
	 * Escape a visitor's answer for use inside a <textarea>.
	 *
	 * Content filters may run over the rendered form: wpautop() turns line
	 * breaks into <br> and paragraphs, wptexturize() rewrites "--", "..." and
	 * "3x4", and capital_P_dangit() recapitalises the name WordPress. Inside a textarea
	 * that text is the visitor's own answer, so the characters those filters
	 * look for are written as numeric character references. The browser
	 * decodes them back to exactly what was typed.
	 *
	 * @param string $value Raw answer.
	 * @return string
	 */
	private static function textarea_value( $value ) {
		$value = str_replace( array( "\r\n", "\r" ), "\n", $value );
		return strtr(
			esc_textarea( $value ),
			array(
				"\n" => '&#10;',
				'-'  => '&#45;',
				'.'  => '&#46;',
				'x'  => '&#120;',
				'('  => '&#40;',
				'`'  => '&#96;',
				'W'  => '&#87;',
			)
		);
	}

	/** Render counts ensure repeated embeds never share control IDs. */
	private static $instances = array();

	/**
	 * Render a complete form, including any error or success state.
	 *
	 * @param int        $form_id Form post ID.
	 * @param array|null $state   Optional state override: errors, values, sent.
	 * @return string
	 */
	public static function render( $form_id, $state = null, $preview = false, $preview_schema = null ) {
		$form_id = (int) $form_id;
		if ( ! $preview && class_exists( '\\AccessibleForms\\Admin\\TestPreview' ) && \AccessibleForms\Admin\TestPreview::active() ) { return \AccessibleForms\Admin\TestPreview::render_in_page( $form_id ); }
		if ( null === $state ) {
			$state = Submission::state_for( $form_id );
		}
		$schema = $preview && is_array( $preview_schema ) ? $preview_schema : Schema::get( $form_id, $preview );

		if ( ! $schema ) {
			// After a submit to a deleted form, say so; otherwise render nothing.
			if ( empty( $state['values'] ) && empty( $state['errors'] ) ) {
				return '';
			}
			wp_enqueue_style( 'accessible-forms' );
			return self::unavailable( $form_id, self::next_prefix( $form_id ), (array) ( $state['values'] ?? array() ) );
		}

		wp_enqueue_style( 'accessible-forms' );
		if (
			! $preview &&
			FormOptions::closed( $form_id, $schema ) &&
			empty( $state['errors'] ) &&
			empty( $state['sent'] )
		) {
			return self::closed( $form_id, $schema );
		}
		if ( ! $preview ) {
			wp_enqueue_script( 'accessible-forms' );
		}

		$errors = isset( $state['errors'] ) && is_array( $state['errors'] ) ? $state['errors'] : array();
		$values = isset( $state['values'] ) && is_array( $state['values'] ) ? $state['values'] : array();
		$sent   = ! empty( $state['sent'] );
		// Answers that could not be kept after a failed submit, such as chosen
		// files, which add-ons ask for again. Fields with their own error already
		// say what to do. Only for fields shown with these answers: a hidden field
		// has nothing to answer, and a link to it would lead nowhere.
		$notices = array();
		if ( ! $sent && $errors && ! empty( $state['notices'] ) && is_array( $state['notices'] ) ) {
			$notices = array_intersect_key(
				array_diff_key( $state['notices'], $errors ),
				Validator::active( $schema, $values )
			);
		}

		$prefix       = self::next_prefix( $form_id );
		$title_id     = $prefix . '-title';
		$summary_id   = $prefix . '-summary';
		$status_id    = $prefix . '-status';
		$form_html_id = $prefix . '-form';

		$level    = $schema['heading_level'] ?? 'h2';
		$headless = 'none' === $level;

		$out =
			'<div class="af-wrap af-width-' .
			esc_attr( $schema['layout']['width'] ?? 'comfortable' ) .
			' af-button-' .
			esc_attr( $schema['layout']['button'] ?? 'start' ) .
			' af-labels-' .
			esc_attr( $schema['layout']['labels'] ?? 'above' ) .
			'" style="' .
			esc_attr( Appearance::css( $schema['appearance'] ?? array() ) ) .
			'" data-af-instance="' .
			esc_attr( $prefix ) .
			'" data-af-form="' .
			esc_attr( (string) $form_id ) .
			'">';

		if ( ! $headless ) {
			$tag  = in_array( $level, array( 'h2', 'h3', 'h4', 'h5', 'h6' ), true ) ? $level : 'h2';
			$out .=
				'<' .
				$tag .
				' class="af-heading" id="' .
				esc_attr( $title_id ) .
				'">' .
				esc_html( $schema['heading'] ) .
				'</' .
				$tag .
				'>';
		}

		if ( $errors ) {
			$out .= self::error_summary( $summary_id, $errors, $schema, $prefix, $notices );
		}

		if ( $sent ) {
			// Focus moves here after sending, so no live-region role is used.
			// The answered form stays hidden until the visitor asks for another.
			$out .=
				'<p class="af-status" id="' .
				esc_attr( $status_id ) .
				'" tabindex="-1">' .
				esc_html( $schema['success_message'] ) .
				'</p><p class="af-another"><a class="af-send-another" href="' .
				esc_url( Submission::current_url() . '#' . $form_html_id ) .
				'">' .
				esc_html__( 'Send another response', 'accessible-forms-by-accessible-org' ) .
				'</a></p>';
		}

		if ( ! empty( $state['previous_values'] ) ) {
			$out .=
				'<details class="af-previous"><summary>' .
				esc_html__( 'Your previous answers', 'accessible-forms-by-accessible-org' ) .
				'</summary><dl>';
			foreach ( $state['previous_values'] as $key => $value ) {
				$out .=
					'<dt>' .
					esc_html( $key ) .
					'</dt><dd>' .
					esc_html( is_array( $value ) ? implode( ', ', array_filter( $value, 'is_scalar' ) ) : $value ) .
					'</dd>';
			}
			$out .= '</dl></details>';
		}
		// The form is named by its heading where one exists, and by an aria-label
		// where the site owner has chosen not to add one to the page outline.
		$naming = $headless
			? ' aria-label="' . esc_attr( $schema['heading'] ) . '"'
			: ' aria-labelledby="' . esc_attr( $title_id ) . '"';

		if ( ! $preview && empty( $state['uncached'] ) ) {
			$out .= self::noscript(
				esc_html__(
					'JavaScript is off. For a form prepared just for you, use this link:',
					'accessible-forms-by-accessible-org'
				) .
				' <a href="' .
				esc_url( Standalone::url( $form_id ) ) .
				'">' .
				esc_html__( 'Open the form without JavaScript', 'accessible-forms-by-accessible-org' ) .
				'</a>.'
			);
		}
		$out .=
			'<form class="af-form" id="' .
			esc_attr( $form_html_id ) .
			'" enctype="multipart/form-data" method="post" action="' .
			esc_url( Submission::current_url() ) .
			'" novalidate' .
			$naming .
			( $sent ? ' hidden' : '' ) .
			'>';

		if ( ! $preview ) {
			// Hidden inputs share one block, so no inline content sits loose
			// between the form's blocks for wpautop() to wrap.
			$out .=
				'<div class="af-hidden-fields" hidden><input type="hidden" name="af_form_id" value="' .
				esc_attr( (string) $form_id ) .
				'"><input type="hidden" name="af_request" value="' .
				esc_attr(
					! empty( $state['errors'] ) || ! empty( $state['uncached'] ) ? bin2hex( random_bytes( 16 ) ) : ''
				) .
				'"><input type="hidden" name="af_version" value="' .
				esc_attr( Revisions::version( $schema ) ) .
				'"></div>';
		}
		// What add-ons render around the fields, such as a progress list.
		$context = array(
			'form_id' => $form_id,
			'prefix'  => $prefix,
			'preview' => (bool) $preview,
		);
		$out    .= (string) Extensions::filter( 'accessible_forms_before_fields', '', $schema, $context );
		$types   = Schema::field_types();
		// A label used by more than one question is only allowed in different
		// sections; those questions take their section's heading into their
		// accessible name, such as "Billing, Street".
		$label_counts = array_count_values(
			array_map(
				array( Schema::class, 'label_key' ),
				array_column(
					array_filter(
						$schema['fields'],
						static function ( $field ) use ( $types ) {
							return 'section' !== $field['type'] && isset( $types[ $field['type'] ] );
						}
					),
					'label'
				)
			)
		);
		$section_id   = '';
		foreach ( $schema['fields'] as $field ) {
			// Fields of an inactive add-on's type are paused.
			if ( ! isset( $types[ $field['type'] ] ) ) {
				continue;
			}
			$name  = $field['name'];
			$value = $values[ $name ] ?? '';
			$error = $errors[ $name ] ?? '';

			$out .= '<div class="af-field-container af-col-' . esc_attr( $field['width'] ?? 'full' ) . '" data-field="' . esc_attr( $name ) . '"';
			// Add-ons add data attributes for their own front-end behavior.
			foreach ( (array) Extensions::filter( 'accessible_forms_field_attributes', array(), $field, $schema ) as $attribute => $attribute_value ) {
				if ( is_string( $attribute ) && preg_match( '/^data-[a-z0-9-]+$/', $attribute ) && is_scalar( $attribute_value ) ) {
					$out .= ' ' . $attribute . '="' . esc_attr( (string) $attribute_value ) . '"';
				}
			}
			$out .= '>';
			if ( 'section' === $field['type'] ) {
				$tag        = 'h' . min( 6, (int) substr( $headless ? 'h2' : $level, 1 ) + 1 );
				$section_id = $prefix . '-section-' . $name;
				$out       .=
					'<' .
					$tag .
					' class="af-section-heading" id="' . esc_attr( $section_id ) . '">' .
					esc_html( $field['label'] ) .
					'</' .
					$tag .
					'>';
				if ( ! empty( $field['help'] ) ) {
					$out .= '<p class="af-help">' . esc_html( $field['help'] ) . '</p>';
				}
			} else {
				if ( $section_id && ( $label_counts[ Schema::label_key( $field['label'] ) ] ?? 0 ) > 1 ) {
					$field['_named_by'] = $section_id;
				}
				$out .= self::field( $field, $prefix, $value, $error, $notices[ $name ] ?? null );
			}
			$out .= (string) Extensions::filter( 'accessible_forms_field_after', '', $field, $schema ) . '</div>';
		}

		$out .= (string) Extensions::filter( 'accessible_forms_after_fields', '', $schema, $context );
		$out .= self::honeypot( $prefix );
		if ( ! $preview ) {
			$provider = Spam::provider();
			// Add-ons render the widget for their own verification methods.
			$out .= 'altcha' === $provider
				? ProofOfWork::widget( $form_id )
				: (string) Extensions::filter( 'accessible_forms_verification_widget', '', $provider, (int) $form_id );
		}

		// Focus moves here when a response is lost, so no live-region role is used.
		$out .=
			'<p class="af-network-error" tabindex="-1" hidden>' .
			esc_html__(
				'We could not confirm whether your message was received. Your answers are still here. Check your connection before trying again.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		$out .=
			'<div class="af-actions">' .
			(string) Extensions::filter( 'accessible_forms_before_submit', '', $schema, $context ) .
			'<button type="submit" class="af-submit"' .
			( $preview ? ' disabled' : '' ) .
			'>' .
			esc_html( $schema['submit_label'] ) .
			'</button><span class="af-submit-status" role="status"></span></div>';

		$out .= (string) Extensions::filter( 'accessible_forms_after_actions', '', $schema, $context );
		$out .= '</form></div>';

		return $out;
	}

	/**
	 * Error summary.
	 *
	 * Focus is moved here on a failed submit, so no live-region role is used.
	 * Combining a role="alert" with a focus move causes screen readers to
	 * announce the content twice.
	 *
	 * @param string $summary_id Element ID.
	 * @param array  $errors     Field name => message.
	 * @param array  $schema     Form schema.
	 * @param string $prefix     Field ID prefix.
	 * @param array  $notices    Field name => `summary` and `inline` words asking for an answer again.
	 * @return string
	 */
	private static function error_summary( $summary_id, array $errors, array $schema, $prefix, array $notices = array() ) {
		// Answers to give again need action too, so they are counted and listed.
		$count = count( $errors ) + count( $notices );

		$heading = sprintf(
			/* translators: %d: number of errors in the form. */
			_n(
				'There is %d problem with this form',
				'There are %d problems with this form',
				$count,
				'accessible-forms-by-accessible-org'
			),
			$count
		);

		// A real heading one level below the form's own, so screen reader users can
		// also reach the summary by heading; a form without a visible heading uses h2.
		$level = (int) substr( (string) ( $schema['heading_level'] ?? 'h2' ), 1 );
		$tag   = 'h' . ( $level >= 2 ? min( 6, $level + 1 ) : 2 );

		$out  = '<div class="af-summary" id="' . esc_attr( $summary_id ) . '" tabindex="-1" autofocus>';
		$out .= '<' . $tag . ' class="af-summary__heading">' . esc_html( $heading ) . '</' . $tag . '>';
		if ( isset( $errors['_form'] ) ) {
			$out .= '<p class="af-summary__message">' . esc_html( $errors['_form'] ) . '</p>';
		}
		$out .= '<ul class="af-summary__list">';

		// Preserve field order rather than error insertion order.
		foreach ( $schema['fields'] as $field ) {
			$name = $field['name'];
			if ( isset( $notices[ $name ] ) ) {
				$out .=
					'<li><a href="#' .
					esc_attr( self::first_input_id( $field, $prefix ) ) .
					'">' .
					esc_html( (string) ( $notices[ $name ]['summary'] ?? '' ) ) .
					'</a></li>';
				continue;
			}
			if ( ! isset( $errors[ $name ] ) ) {
				continue;
			}

			$target = self::first_input_id( $field, $prefix );
			$text   = self::summary_text( $field, $errors[ $name ] );

			$out .= '<li><a href="#' . esc_attr( $target ) . '">' . esc_html( $text ) . '</a></li>';
		}

		$out .= '</ul></div>';

		return $out;
	}

	/**
	 * Words for one link in the error summary. Every link names its question, so
	 * a list of links read out of context still says which answer to fix.
	 *
	 * @param array  $field   Field definition.
	 * @param string $message Error message.
	 * @return string
	 */
	private static function summary_text( array $field, $message ) {
		$label = trim( (string) ( $field['label'] ?? '' ) );
		if ( '' === $label || false !== mb_stripos( $message, $label ) ) {
			return $message;
		}
		return sprintf(
			/* translators: 1: question label, 2: what to correct. */
			__( '%1$s: %2$s', 'accessible-forms-by-accessible-org' ),
			$label,
			$message
		);
	}

	/**
	 * The ID a summary link should point at for a given field.
	 *
	 * @param array  $field  Field definition.
	 * @param string $prefix Field ID prefix.
	 * @return string
	 */
	private static function first_input_id( array $field, $prefix ) {
		$types = Schema::field_types();
		$base  = $prefix . '-' . $field['name'];

		if ( ! empty( $types[ $field['type'] ]['choice'] ) ) {
			return $base . '-0';
		}

		return $base;
	}

	/**
	 * Render one field.
	 *
	 * @param array       $field    Field definition.
	 * @param string      $prefix   Field ID prefix.
	 * @param mixed       $value    Submitted value.
	 * @param string      $error    Error message, empty when valid.
	 * @param array|null  $notice   Words asking for this answer again after a failed submit, null when none.
	 * @return string
	 */
	private static function field( array $field, $prefix, $value, $error, $notice = null ) {
		$types  = Schema::field_types();
		$type   = $field['type'];
		$config = $types[ $type ] ?? null;

		if ( ! $config ) {
			return '';
		}

		$id        = $prefix . '-' . $field['name'];
		$error_id  = $id . '-error';
		$classes   = 'af-field af-field--' . $type . ( $error ? ' af-field--error' : '' );
		$help_id   = $id . '-help';
		$help_html = ! empty( $field['help'] )
			? '<p class="af-help" id="' . esc_attr( $help_id ) . '">' . esc_html( $field['help'] ) . '</p>'
			: '';

		$error_html = $error
			? '<p class="af-error" id="' .
				esc_attr( $error_id ) .
				'"><span class="af-error__prefix">' .
				esc_html__( 'Error:', 'accessible-forms-by-accessible-org' ) .
				'</span> ' .
				esc_html( $error ) .
				'</p>'
			: '';

		if ( ! empty( $config['choice'] ) ) {
			return self::choice_group(
				$field,
				$id,
				$error_id,
				$help_html . $error_html,
				$classes,
				$value,
				$error
			);
		}

		if ( 'consent' === $type ) {
			return self::consent( $field, $id, $error_id, $help_html . $error_html, $classes, $value, $error );
		}

		// The label and the control each sit in their own block (styled with
		// display: contents), so the help and error paragraphs between them never
		// leave inline content loose for wpautop() to wrap or split.
		$out      = '<div class="' . esc_attr( $classes ) . '">';
		$named_by = (string) ( $field['_named_by'] ?? '' );
		$out     .=
			'<div class="af-field__label"><label class="af-label" for="' .
			esc_attr( $id ) .
			'"' . ( $named_by ? ' id="' . esc_attr( $id . '-label' ) . '"' : '' ) . '>' .
			esc_html( $field['label'] ) .
			self::required_hint( $field ) .
			'</label></div>';

		// The error precedes the control so it is encountered first in reading order.
		$out .= $help_html . $error_html;

		$attrs = array(
			'id'   => $id,
			'name' => 'af[' . $field['name'] . ']',
		);
		if ( $named_by ) {
			$attrs['aria-labelledby'] = $named_by . ' ' . $id . '-label';
		}

		if ( ! empty( $field['required'] ) ) {
			$attrs['required'] = 'required';
		}

		if ( 'url' === $field['type'] && 'referrer' === ( $field['prefill'] ?? '' ) ) {
			// form.js fills this with the previous same-site page, path only.
			$attrs['data-af-prefill'] = 'referrer';
		}
		if ( ! empty( $field['autocomplete'] ) ) {
			$attrs['autocomplete'] = trim( ( $field['autofill_section'] ?? '' ) . ' ' . $field['autocomplete'] );
		}

		// aria-invalid is emitted only when the field is invalid. No ARIA is
		// better than redundant ARIA.
		if ( $error ) {
			$attrs['aria-invalid']     = 'true';
			$attrs['aria-describedby'] = $error_id;
		}
		if ( $help_html ) {
			$attrs['aria-describedby'] = trim( ( $attrs['aria-describedby'] ?? '' ) . ' ' . $help_id );
		}

		if (
			! empty( $field['max_length'] ) &&
			in_array( $type, array( 'text', 'textarea', 'email', 'tel', 'url' ), true )
		) {
			$attrs['maxlength']     = $field['max_length'];
			$attrs['data-af-count'] = $field['max_length'];
		}
		if ( 'number' === $type ) {
			foreach ( array( 'min', 'max' ) as $key ) {
				if ( '' !== ( $field[ $key ] ?? '' ) ) {
					$attrs[ $key ] = $field[ $key ];
				}
			}
			$attrs['step'] = $field['increment'] ?? '' ?: 'any';
		}
		if ( ! empty( $config['addon'] ) ) {
			// Add-ons render the control for their own field types. Anything
			// before it (help, notices) is escaped HTML in its own block.
			$addon   = (array) Extensions::filter(
				'accessible_forms_field_control',
				array(),
				$field,
				array(
					'id'     => $id,
					'attrs'  => $attrs,
					'value'  => $value,
					'error'  => $error,
					'notice' => $notice,
				)
			);
			$out    .= (string) ( $addon['before'] ?? '' );
			$control = (string) ( $addon['control'] ?? '' );
		} elseif ( 'textarea' === $config['input'] ) {
			$attrs['rows'] = '6';
			$control       =
				'<textarea class="af-input" ' .
				self::attrs( $attrs ) .
				'>' .
				self::textarea_value( is_string( $value ) ? $value : '' ) .
				'</textarea>';
		} elseif ( 'select' === $config['input'] ) {
			$control  = '<select class="af-input" ' . self::attrs( $attrs ) . '>';
			$control .= '<option value="">' . esc_html__( '— Select —', 'accessible-forms-by-accessible-org' ) . '</option>';
			foreach ( $field['options'] as $option ) {
				$control .=
					'<option value="' .
					esc_attr( $option ) .
					'"' .
					selected( $value, $option, false ) .
					'>' .
					esc_html( Choices::label( $field, $option ) ) .
					'</option>';
			}
			$control .= '</select>';
		} else {
			// No size attribute: width is CSS's job (WCAG 1.4.4).
			$attrs['type']  = $config['input'];
			$attrs['value'] = is_string( $value ) ? $value : '';
			$control        = '<input class="af-input" ' . self::attrs( $attrs ) . '>';
		}

		$out .= '<div class="af-field__control">' . $control . '</div></div>';

		return $out;
	}

	/**
	 * Radio or checkbox group, wrapped in a fieldset with a legend.
	 *
	 * Only choice groups get a fieldset. Wrapping the whole form in one causes
	 * the legend to be re-announced on every control.
	 *
	 * @param array  $field      Field definition.
	 * @param string $id         Base ID.
	 * @param string $error_id   Error element ID.
	 * @param string $error_html Rendered error paragraph.
	 * @param string $classes    Wrapper classes.
	 * @param mixed  $value      Submitted value(s).
	 * @param string $error      Error message.
	 * @return string
	 */
	private static function choice_group(
		array $field,
		$id,
		$error_id,
		$error_html,
		$classes,
		$value,
		$error
	) {
		$is_checkbox = 'checkbox' === $field['type'];
		$selected    = is_array( $value ) ? $value : ( '' === $value ? array() : array( $value ) );

		$named_by = (string) ( $field['_named_by'] ?? '' );
		$out      = '<fieldset class="' . esc_attr( $classes ) . '"' . ( $named_by ? ' aria-labelledby="' . esc_attr( $named_by . ' ' . $id . '-legend' ) . '"' : '' ) . '>';
		$out     .=
			'<legend class="af-legend"' . ( $named_by ? ' id="' . esc_attr( $id . '-legend' ) . '"' : '' ) . '>' .
			esc_html( $field['label'] ) .
			self::required_hint( $field ) .
			'</legend>';
		$out     .= $error_html;

		foreach ( $field['options'] as $index => $option ) {
			$option_id = $id . '-' . $index;

			$attrs = array(
				'type'  => $is_checkbox ? 'checkbox' : 'radio',
				'id'    => $option_id,
				'name'  => 'af[' . $field['name'] . ']' . ( $is_checkbox ? '[]' : '' ),
				'value' => $option,
			);

			if ( ! empty( $field['required'] ) && ! $is_checkbox ) {
				$attrs['required'] = 'required';
			}

			if ( in_array( (string) $option, array_map( 'strval', $selected ), true ) ) {
				$attrs['checked'] = 'checked';
			}

			if ( $error ) {
				$attrs['aria-invalid']     = 'true';
				$attrs['aria-describedby'] = $error_id;
			}
			if ( ! empty( $field['help'] ) ) {
				$attrs['aria-describedby'] = trim( ( $attrs['aria-describedby'] ?? '' ) . ' ' . $id . '-help' );
			}

			$out .= '<div class="af-choice">';
			$out .= '<input class="af-choice__input" ' . self::attrs( $attrs ) . '>';
			$out .=
				'<label class="af-choice__label" for="' .
				esc_attr( $option_id ) .
				'">' .
				esc_html( Choices::label( $field, $option ) ) .
				'</label>';
			$out .= '</div>';
		}

		$out .= '</fieldset>';

		return $out;
	}

	/**
	 * Single consent checkbox. No fieldset: a lone control needs no group label.
	 *
	 * @param array  $field      Field definition.
	 * @param string $id         Element ID.
	 * @param string $error_id   Error element ID.
	 * @param string $error_html Rendered error paragraph.
	 * @param string $classes    Wrapper classes.
	 * @param mixed  $value      Submitted value.
	 * @param string $error      Error message.
	 * @return string
	 */
	private static function consent( array $field, $id, $error_id, $error_html, $classes, $value, $error ) {
		$attrs = array(
			'type'  => 'checkbox',
			'id'    => $id,
			'name'  => 'af[' . $field['name'] . ']',
			'value' => '1',
		);

		if ( ! empty( $field['required'] ) ) {
			$attrs['required'] = 'required';
		}

		if ( $value ) {
			$attrs['checked'] = 'checked';
		}
		$named_by = (string) ( $field['_named_by'] ?? '' );
		if ( $named_by ) {
			$attrs['aria-labelledby'] = $named_by . ' ' . $id . '-label';
		}

		if ( $error ) {
			$attrs['aria-invalid']     = 'true';
			$attrs['aria-describedby'] = $error_id;
		}
		if ( ! empty( $field['help'] ) ) {
			$attrs['aria-describedby'] = trim( ( $attrs['aria-describedby'] ?? '' ) . ' ' . $id . '-help' );
		}

		$out  = '<div class="' . esc_attr( $classes ) . '">';
		$out .= $error_html;
		$out .= '<div class="af-choice">';
		$out .= '<input class="af-choice__input" ' . self::attrs( $attrs ) . '>';
		$out .=
			'<label class="af-choice__label" for="' .
			esc_attr( $id ) .
			'"' . ( $named_by ? ' id="' . esc_attr( $id . '-label' ) . '"' : '' ) . '>' .
			esc_html( $field['label'] ) .
			self::required_hint( $field ) .
			'</label>';
		$out .= '</div></div>';

		return $out;
	}

	/**
	 * The ID prefix for the next rendering of a form on this page.
	 *
	 * The first embed uses af-{id}; repeats add -2, -3 and so on, so two copies
	 * of one form never share an ID.
	 *
	 * @param int $form_id Form post ID.
	 * @return string
	 */
	private static function next_prefix( $form_id ) {
		self::$instances[ $form_id ] = ( self::$instances[ $form_id ] ?? 0 ) + 1;
		$instance                    = self::$instances[ $form_id ];
		return 'af-' . $form_id . ( $instance > 1 ? '-' . $instance : '' );
	}

	/**
	 * Visible required indicator. Words, never a bare asterisk.
	 *
	 * @param array $field Field definition.
	 * @return string
	 */
	private static function required_hint( array $field ) {
		if ( empty( $field['required'] ) ) {
			return '';
		}

		return ' <span class="af-req">' . esc_html__( '(required)', 'accessible-forms-by-accessible-org' ) . '</span>';
	}

	/**
	 * Honeypot.
	 *
	 * The `hidden` attribute already removes the container from the accessibility
	 * tree, so no aria-hidden is added. A real label is present for the rare case
	 * where `hidden` is overridden by a theme.
	 *
	 * @param string $prefix Field ID prefix.
	 * @return string
	 */
	private static function honeypot( $prefix ) {
		$id = $prefix . '-hp';

		return '<div hidden>' .
			'<label for="' .
			esc_attr( $id ) .
			'">' .
			esc_html__( 'Leave this field empty', 'accessible-forms-by-accessible-org' ) .
			'</label>' .
			'<input type="text" id="' .
			esc_attr( $id ) .
			'" name="af_hp" value="" tabindex="-1" autocomplete="off">' .
			'</div>';
	}

	/**
	 * Tags and attributes a rendered form may contain, for wp_kses() at the
	 * point of output. Everything in render() is already escaped; this keeps
	 * the final echo verifiably safe as well.
	 *
	 * @return array
	 */
	public static function allowed_html() {
		$global = array(
			'class'            => true,
			'id'               => true,
			'hidden'           => true,
			'role'             => true,
			'tabindex'         => true,
			'style'            => true,
			'autofocus'        => true,
			'aria-describedby' => true,
			'aria-labelledby'  => true,
			'aria-label'       => true,
			'aria-invalid'     => true,
			'aria-hidden'      => true,
			'aria-live'        => true,
			'aria-current'     => true,
			'aria-expanded'    => true,
			'aria-controls'    => true,
			'data-*'           => true,
		);
		$field  = array(
			'name'         => true,
			'value'        => true,
			'type'         => true,
			'required'     => true,
			'disabled'     => true,
			'readonly'     => true,
			'autocomplete' => true,
		);
		$tags   = array(
			'div'                     => array(),
			'span'                    => array(),
			'p'                       => array(),
			'strong'                  => array(),
			'ul'                      => array(),
			'ol'                      => array(),
			'li'                      => array(),
			'dl'                      => array(),
			'dt'                      => array(),
			'dd'                      => array(),
			'nav'                     => array(),
			'section'                 => array(),
			'noscript'                => array(),
			'details'                 => array( 'open' => true ),
			'summary'                 => array(),
			'fieldset'                => array(),
			'legend'                  => array(),
			'a'                       => array( 'href' => true ),
			'label'                   => array( 'for' => true ),
			'form'                    => array(
				'action'     => true,
				'method'     => true,
				'enctype'    => true,
				'novalidate' => true,
			),
			'input'                   => $field + array(
				'accept'    => true,
				'checked'   => true,
				'min'       => true,
				'max'       => true,
				'step'      => true,
				'maxlength' => true,
				'minlength' => true,
				'multiple'  => true,
			),
			'select'                  => $field + array( 'multiple' => true ),
			'option'                  => array(
				'value'    => true,
				'selected' => true,
				'disabled' => true,
			),
			'textarea'                => $field + array(
				'rows'      => true,
				'maxlength' => true,
				'minlength' => true,
			),
			'button'                  => $field,
			'accessible-forms-altcha' => array(
				'name'          => true,
				'auto'          => true,
				'workers'       => true,
				'challenge'     => true,
				'configuration' => true,
			),
		);
		foreach ( array( 'h1', 'h2', 'h3', 'h4', 'h5', 'h6' ) as $heading ) {
			$tags[ $heading ] = array();
		}
		foreach ( $tags as $tag => $attributes ) {
			$tags[ $tag ] = $attributes + $global;
		}
		return $tags;
	}

	/**
	 * Build an escaped attribute string.
	 *
	 * @param array $attrs Attribute name => value.
	 * @return string
	 */
	private static function attrs( array $attrs ) {
		$parts = array();

		foreach ( $attrs as $key => $val ) {
			$parts[] = esc_attr( $key ) . '="' . esc_attr( (string) $val ) . '"';
		}

		return implode( ' ', $parts );
	}
}
