<?php
/**
 * Private attachments kept with entries. Accessible Forms Pro receives and
 * stores them; the free plugin still lists them in privacy exports and
 * deletes them with their entry, even while Pro is inactive.
 *
 * @package AccessibleForms
 */
namespace AccessibleForms;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned table; deletion and privacy exports must not use stale object-cache rows.

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
class Files {
	/** @var bool|null Whether the table exists, once checked. */
	private static $exists = null;

	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'accessible_form_files';
	}

	/** Whether any attachments can exist on this site. */
	public static function exists() {
		if ( null === self::$exists ) {
			global $wpdb;
			self::$exists = (bool) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( self::table() ) ) );
		}
		return self::$exists;
	}

	public static function listing( $entry_id ) {
		if ( ! self::exists() ) {
			return array();
		}
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT id, field_key, filename, mime, size, approved FROM %i WHERE entry_id = %d ORDER BY id LIMIT 3',
				self::table(),
				$entry_id
			),
			ARRAY_A
		) ?:
			array();
	}

	public static function forget( $id ) {
		if ( self::exists() ) {
			global $wpdb;
			return false !== $wpdb->delete( self::table(), array( 'entry_id' => $id ), array( '%d' ) );
		}
		return true;
	}
}
