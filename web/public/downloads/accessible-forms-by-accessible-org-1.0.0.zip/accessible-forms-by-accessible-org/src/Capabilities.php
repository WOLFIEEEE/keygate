<?php
/** Purpose-specific access to forms and private submissions. @package AccessibleForms */
namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Capabilities {
	const ACCESS_META = '_accessible_forms_entry_users';
	public static function forms() {
		return array(
			'edit_accessible_forms',
			'edit_others_accessible_forms',
			'edit_private_accessible_forms',
			'edit_published_accessible_forms',
			'publish_accessible_forms',
			'read_private_accessible_forms',
			'delete_accessible_forms',
			'delete_others_accessible_forms',
			'delete_private_accessible_forms',
			'delete_published_accessible_forms',
		);
	}

	public static function labels() {
		return array(
			'read_accessible_form_entries'       => __( 'Read submissions', 'accessible-forms-by-accessible-org' ),
			'manage_accessible_form_entries'     => __( 'Review, assign and annotate submissions', 'accessible-forms-by-accessible-org' ),
			'export_accessible_form_entries'     => __( 'Export submissions', 'accessible-forms-by-accessible-org' ),
			'delete_accessible_form_entries'     => __( 'Delete submissions', 'accessible-forms-by-accessible-org' ),
			'send_accessible_form_notifications' => __( 'Send and retry notifications', 'accessible-forms-by-accessible-org' ),
			'manage_accessible_forms_settings'   => __( 'Manage settings and team access', 'accessible-forms-by-accessible-org' ),
		);
	}

	public static function install() {
		$admin = get_role( 'administrator' );
		if ( $admin ) {
			foreach ( array_merge( self::forms(), array_keys( self::labels() ) ) as $cap ) {
				$admin->add_cap( $cap );
			}
		}
		// Preserve editors' form-building access without granting private-entry access.
		$editor = get_role( 'editor' );
		if ( $editor ) {
			foreach ( self::forms() as $cap ) {
				$editor->add_cap( $cap );
			}
		}
		// Add-ons grant their own roles again after capabilities are reset.
		Extensions::notify( 'accessible_forms_capabilities_installed' );
	}

	/**
	 * Whether a user may act on a form's submissions. Add-ons may narrow this per
	 * form through `accessible_forms_user_can_form`; settings administrators
	 * always keep access.
	 */
	public static function form( $form_id, $cap = 'read_accessible_form_entries', $user_id = 0 ) {
		$user_id = $user_id ?: get_current_user_id();
		if ( ! user_can( $user_id, $cap ) ) {
			return false;
		}
		if ( user_can( $user_id, 'manage_accessible_forms_settings' ) ) {
			return true;
		}
		if ( 'accessible_form' !== get_post_type( $form_id ) ) {
			return false;
		}
		$raw = (string) get_post_meta( $form_id, self::ACCESS_META, true );
		if ( '' !== $raw ) {
			$users = json_decode( $raw, true );
			if ( ! is_array( $users ) || ( $users && ! in_array( (int) $user_id, array_map( 'intval', $users ), true ) ) ) {
				return false;
			}
		}
		return (bool) Extensions::filter( 'accessible_forms_user_can_form', true, (int) $form_id, $cap, (int) $user_id );
	}

	/** Saved restrictions are enforced even when their editing add-on is absent. */
	public static function access_scope( $user_id ) {
		global $wpdb;
		return array(
			array( "NOT EXISTS (SELECT 1 FROM {$wpdb->postmeta} acl WHERE acl.post_id = form_id AND acl.meta_key = '" . self::ACCESS_META . "' AND acl.meta_value NOT IN ('', '[]') AND acl.meta_value NOT LIKE %s)" ),
			array( '%"' . (int) $user_id . '"%' ),
		);
	}

	public static function entry( $entry, $cap = 'read_accessible_form_entries' ) {
		return is_array( $entry ) && self::form( $entry['form_id'], $cap );
	}

	/** Add a SQL-level scope; counts, lists and exports all use the same boundary. */
	public static function query( array $args = array(), $cap = 'read_accessible_form_entries' ) {
		$args['_access_cap'] = $cap;
		return $args;
	}

	public static function remove() {
		foreach ( wp_roles()->role_objects as $role ) {
			foreach ( array_merge( self::forms(), array_keys( self::labels() ) ) as $cap ) {
				$role->remove_cap( $cap );
			}
		}
	}
}
