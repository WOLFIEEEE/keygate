<?php
/**
 * Whether a form meets the accessibility rules, and edits that were saved
 * with problems.
 *
 * Edits that break a rule are kept on the server, so no work is lost, but
 * they never reach visitors: the live and draft versions only ever hold a
 * schema that passed Schema::validate(). A form saved under older rules is
 * checked again against the current ones and flagged until it is fixed.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class FormCheck {
	/** Post meta holding edits saved with problems: raw input, issues, author and time. */
	const PENDING = '_accessible_forms_pending_edits';

	/** @var array<int, array> Issues per form for this request. */
	private static $cache = array();

	/**
	 * Keep edits that break a rule, with the reasons.
	 *
	 * @param int   $form_id Form ID.
	 * @param array $raw     Submitted schema input.
	 * @param array $issues  Structured issues.
	 */
	public static function keep( $form_id, array $raw, array $issues ) {
		update_post_meta(
			$form_id,
			self::PENDING,
			wp_slash(
				array(
					'raw'    => map_deep( $raw, 'sanitize_textarea_field' ),
					'issues' => array_values( $issues ),
					'user'   => get_current_user_id(),
					'at'     => time(),
				)
			)
		);
		unset( self::$cache[ (int) $form_id ] );
	}

	/**
	 * Edits saved with problems, if any.
	 *
	 * @param int $form_id Form ID.
	 * @return array|null Raw input, issues, user and time.
	 */
	public static function pending( $form_id ) {
		$pending = get_post_meta( (int) $form_id, self::PENDING, true );
		return is_array( $pending ) && isset( $pending['raw'], $pending['issues'] ) && is_array( $pending['raw'] ) ? $pending : null;
	}

	/** Forget kept edits, after a clean save or when the owner discards them. */
	public static function forget( $form_id ) {
		delete_post_meta( (int) $form_id, self::PENDING );
		unset( self::$cache[ (int) $form_id ] );
	}

	/**
	 * Why the published version breaks the current rules. Visitors see this version.
	 *
	 * @param int $form_id Form ID.
	 * @return array[] Structured issues; empty when it passes or is not published.
	 */
	public static function live_issues( $form_id ) {
		$form_id = (int) $form_id;
		if ( ! isset( self::$cache[ $form_id ] ) ) {
			$schema                  = 'publish' === get_post_status( $form_id ) ? Schema::get_live( $form_id ) : null;
			self::$cache[ $form_id ] = is_array( $schema ) ? Schema::validate( $schema )[1] : array();
		}
		return self::$cache[ $form_id ];
	}

	/**
	 * Everything the owner must fix before publishing: kept edits' problems,
	 * or else the saved version's under the current rules.
	 *
	 * @param int $form_id Form ID.
	 * @return array[]
	 */
	public static function issues( $form_id ) {
		$pending = self::pending( $form_id );
		if ( $pending ) {
			return array_values( array_filter( (array) $pending['issues'], 'is_array' ) );
		}
		$saved = Schema::get( (int) $form_id, true );
		return is_array( $saved ) ? Schema::validate( $saved )[1] : array();
	}

	/**
	 * Forms that need accessibility fixes, for overview screens.
	 *
	 * @param int $limit Most forms to check.
	 * @return array<int, array{live: int, pending: bool}> Form ID => number of problems in the
	 *                                                     published version, and whether edits were kept with problems.
	 */
	public static function forms( $limit = 200, $page = 1 ) {
		$found = array();
		$ids   = get_posts(
			array(
				'post_type'   => 'accessible_form',
				'post_status' => array( 'publish', 'draft', 'pending', 'private', 'future' ),
				'numberposts' => $limit,
				'offset'      => ( max( 1, (int) $page ) - 1 ) * $limit,
				'orderby'     => 'ID',
				'order'       => 'ASC',
				'fields'      => 'ids',
			)
		);
		foreach ( $ids as $id ) {
			$live    = count( self::live_issues( $id ) );
			$pending = null !== self::pending( $id );
			if ( $live || $pending ) {
				$found[ $id ] = array(
					'live'    => $live,
					'pending' => $pending,
				);
			}
		}
		return $found;
	}
}
