<?php
/**
 * Uncached public form for visitors completing without JavaScript.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Serves a minimal, uncached page containing one form. Used when a cached
 * page cannot show a visitor's validation errors.
 */
class Standalone {

	/**
	 * Address of the uncached completion page for a form.
	 *
	 * @param int $id Form ID.
	 * @return string
	 */
	public static function url( $id ) {
		return add_query_arg(
			array(
				'action'  => 'accessible_forms_complete',
				'form_id' => absint( $id ),
			),
			admin_url( 'admin-post.php' )
		);
	}

	/**
	 * Render the completion page. Anonymous and read-only apart from the public
	 * submission itself, which Submission validates (no nonce by design).
	 */
	public static function render() {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedConstantFound -- Standard cache-plugin interoperability constant.
		}
		nocache_headers();
		header( 'Referrer-Policy: no-referrer' );

		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing -- Public, anonymous form page; values are integers and the submission is validated by Submission.
		$id        = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
		$posted_id = isset( $_POST['af_form_id'] ) ? absint( $_POST['af_form_id'] ) : null;
		// phpcs:enable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing

		if ( null !== $posted_id && $posted_id !== $id ) {
			wp_die(
				esc_html__( 'The form address does not match this submission.', 'accessible-forms-by-accessible-org' ),
				'',
				array( 'response' => 400 )
			);
		}

		Submission::maybe_handle();

		$schema = Schema::get( $id );
		if ( ! $schema && empty( Submission::state_for( $id )['values'] ) ) {
			wp_die(
				esc_html__( 'This form is currently unavailable.', 'accessible-forms-by-accessible-org' ),
				'',
				array( 'response' => 404 )
			);
		}

		register_frontend_assets();
		$state             = Submission::state_for( $id );
		$state['uncached'] = true;
		$title             = $schema['heading'] ?? __( 'Complete the form', 'accessible-forms-by-accessible-org' );
		$privacy           = get_privacy_policy_url();

		header( 'Content-Type: text/html; charset=' . get_bloginfo( 'charset' ) );
		?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php echo esc_attr( get_bloginfo( 'charset' ) ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo esc_html( $title ); ?></title>
	<?php wp_print_styles( array( 'accessible-forms' ) ); ?>
</head>
<body class="af-standalone">
<main>
	<h1><?php esc_html_e( 'Complete the form', 'accessible-forms-by-accessible-org' ); ?></h1>
	<?php echo wp_kses( Renderer::render( $id, $state ), Renderer::allowed_html() ); ?>
	<?php if ( $privacy ) : ?>
		<p><a href="<?php echo esc_url( $privacy ); ?>"><?php esc_html_e( 'Privacy policy', 'accessible-forms-by-accessible-org' ); ?></a></p>
	<?php endif; ?>
</main>
	<?php wp_print_footer_scripts(); ?>
</body>
</html>
		<?php
		exit;
	}
}
