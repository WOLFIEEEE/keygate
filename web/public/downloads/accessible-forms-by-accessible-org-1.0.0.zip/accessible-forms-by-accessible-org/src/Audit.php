<?php
/** Bounded, redacted administrative activity. @package AccessibleForms */
namespace AccessibleForms;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned tables and atomic option leases use prepared SQL; live permissions, deletion and queue state must not use stale object-cache rows.

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Audit {
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'accessible_form_activity';
	}
	public static function install() {
		global $wpdb;
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();
		dbDelta(
			"CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			form_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			entry_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			actor BIGINT UNSIGNED NOT NULL DEFAULT 0,
			action VARCHAR(80) NOT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY entry_created (entry_id, created_at),
			KEY created_at (created_at)
		) {$collate};"
		);
	}
	public static function record( $action, $form_id = 0, $entry_id = 0 ) {
		global $wpdb;
		$wpdb->insert(
			self::table(),
			array(
				'form_id'    => absint( $form_id ),
				'entry_id'   => absint( $entry_id ),
				'actor'      => get_current_user_id(),
				'action'     => substr( sanitize_key( $action ), 0, 80 ),
				'created_at' => current_time( 'mysql', true ),
			),
			array( '%d', '%d', '%d', '%s', '%s' )
		);
	}
	public static function recent( $entry_id = 0 ) {
		global $wpdb;
		return $wpdb->get_results(
			$wpdb->prepare(
				'SELECT * FROM %i WHERE entry_id = %d ORDER BY id DESC LIMIT 50',
				self::table(),
				$entry_id
			),
			ARRAY_A
		) ?:
			array();
	}
	public static function purge() {
		global $wpdb;
		$ids = $wpdb->get_col(
			$wpdb->prepare(
				'SELECT id FROM %i WHERE created_at < %s ORDER BY id LIMIT 500',
				self::table(),
				gmdate( 'Y-m-d H:i:s', time() - 90 * DAY_IN_SECONDS )
			)
		);
		foreach ( $ids as $id ) {
			$wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );
		}
		if ( count( $ids ) === 500 && ! wp_next_scheduled( 'accessible_forms_purge_batch' ) ) {
			wp_schedule_single_event( time() + 60, 'accessible_forms_purge_batch' );
		}
	}
}
