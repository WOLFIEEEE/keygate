<?php
/**
 * Staged form configuration and conflict detection. Publishing fires
 * `accessible_forms_form_published` with the replaced and new configuration,
 * so an add-on can keep a history.
 *
 * @package AccessibleForms
 */
namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Revisions {
	const DRAFT = '_accessible_forms_working_schema';

	public static function token( $id ) {
		return hash(
			'sha256',
			(string) get_post_meta( $id, Schema::META_KEY, true ) .
				'|' .
				(string) get_post_meta( $id, self::DRAFT, true ) .
				'|' .
				// Edits kept with problems are part of what the editor showed: a tab
				// opened before they were kept must not replace them without a warning.
				(string) wp_json_encode( get_post_meta( $id, FormCheck::PENDING, true ) )
		);
	}
	public static function has_draft( $id ) {
		return '' !== (string) get_post_meta( $id, self::DRAFT, true );
	}
	public static function version( array $schema ) {
		return substr( hash( 'sha256', wp_json_encode( $schema ) ), 0, 24 );
	}
	public static function save( $id, array $schema, $expected, $publish = false, $reviewed = false ) {
		$lock = Locks::acquire( 'edit:' . absint( $id ), 60 );
		if ( ! $lock ) {
			return new \WP_Error(
				'busy',
				__(
					'Another save is in progress. Your edits are kept below. Try saving again.',
					'accessible-forms-by-accessible-org'
				)
			);
		}
		try {
			if ( ! is_string( $expected ) || ! hash_equals( self::token( $id ), $expected ) ) {
				return new \WP_Error(
					'conflict',
					__(
						'This form changed after you opened it. Your edits are kept below. Open the latest version in another tab and compare before saving.',
						'accessible-forms-by-accessible-org'
					)
				);
			}
			if ( $publish && ! current_user_can( 'publish_accessible_forms' ) ) {
				return new \WP_Error(
					'forbidden',
					__( 'You do not have permission to publish forms.', 'accessible-forms-by-accessible-org' )
				);
			}
			// Validate at the write boundary too: callers other than the editor must
			// never replace a working draft or a live form with broken configuration.
			$issues = Schema::validate( $schema )[1];
			if ( $issues ) {
				return new \WP_Error( 'invalid_schema', implode( ' ', Schema::messages( $issues ) ), array( 'issues' => $issues ) );
			}
			if ( $publish && true !== $reviewed ) {
				return new \WP_Error( 'accessibility_review', __( 'Before publishing, review the questions and instructions, then confirm the accessibility review in Review & publish.', 'accessible-forms-by-accessible-org' ), array( 'setting' => 'accessibility_review' ) );
			}
			$existing_fields = array_column(
				( Schema::get( $id, true ) ?: array( 'fields' => array() ) )['fields'],
				null,
				'uid'
			);
			foreach ( $schema['fields'] as $field ) {
				if (
					isset( $existing_fields[ $field['uid'] ] ) &&
					$existing_fields[ $field['uid'] ]['name'] !== $field['name']
				) {
					return new \WP_Error(
						'identity',
						__(
							'A saved field’s key cannot change. Edit its visible label, or create an independent field instead.',
							'accessible-forms-by-accessible-org'
						)
					);
				}
			}
			if ( ! $publish && in_array( get_post_status( $id ), array( 'publish', 'future' ), true ) ) {
				if ( ! Persistence::meta( $id, self::DRAFT, wp_json_encode( $schema ) ) ) {
					return self::storage_error();
				}
				Audit::record( 'draft_saved', $id );
				return true;
			}
			$old = Schema::get_live( $id );
			if ( ! Schema::save( $id, $schema ) ) {
				return self::storage_error();
			}
			delete_post_meta( $id, self::DRAFT );
			if ( self::has_draft( $id ) ) {
				return new \WP_Error( 'draft_cleanup', __( 'Your form was saved, but its working copy could not be cleared. Your edits are kept. Reload and try again.', 'accessible-forms-by-accessible-org' ) );
			}
			Audit::record( $publish ? 'form_published' : 'form_saved', $id );
			if ( $old && $old !== $schema ) {
				// Add-ons keep a history of replaced versions.
				Extensions::notify( 'accessible_forms_form_published', (int) $id, $old, $schema );
			}
			return true;
		} finally {
			Locks::release( $lock );
		}
	}
	private static function storage_error() {
		return new \WP_Error( 'storage', __( 'Your changes could not be saved. The saved version and your edits are kept. Please try again.', 'accessible-forms-by-accessible-org' ) );
	}
}
