<?php
/**
 * Mail delivery.
 *
 * wp_mail() runs exactly as the site already has it configured, including any
 * SMTP plugin in use. While one of this plugin's messages is being sent, an
 * add-on may configure PHPMailer through `accessible_forms_mailer_configure`;
 * the shared mailer is restored afterwards so nothing leaks into other mail.
 *
 * Every send result is captured so a failure is recorded against the entry
 * rather than disappearing.
 *
 * @package AccessibleForms;
 */

namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Sends notification email and records the outcome.
 */
class Mailer {
	/**
	 * The last error reported by wp_mail().
	 *
	 * @var string
	 */
	private static $last_error = '';

	/**
	 * Transport conversation captured during a test send.
	 *
	 * @var string[]
	 */
	private static $debug = array();

	/**
	 * Whether the current send is a test that collects transport output.
	 *
	 * @var bool
	 */
	private static $debugging = false;

	/**
	 * Register hooks.
	 *
	 * Deliberately conservative: nothing is registered unless the site owner
	 * turned SMTP on, so other mail plugins keep working untouched.
	 */
	public static function init() {
		// Delivery hooks are attached only while sending an Accessible Forms message.
	}

	/**
	 * Override the From address.
	 *
	 * @param string $from Current address.
	 * @return string
	 */
	public static function filter_from( $from ) {
		$configured = Settings::from_address();

		return '' !== $configured['address'] ? $configured['address'] : $from;
	}

	/**
	 * Override the From name.
	 *
	 * @param string $name Current name.
	 * @return string
	 */
	public static function filter_from_name( $name ) {
		$configured = Settings::from_address();

		return '' !== $configured['name'] ? $configured['name'] : $name;
	}

	/**
	 * Let an add-on configure PHPMailer for this plugin's messages only.
	 *
	 * @param \PHPMailer\PHPMailer\PHPMailer $mailer PHPMailer instance.
	 */
	public static function configure( $mailer ) {
		Extensions::notify( 'accessible_forms_mailer_configure', $mailer, self::$debugging );
	}

	/**
	 * Record one line of transport output during a test send. Add-ons call this
	 * from PHPMailer's debug output. Keep only server replies: client lines can
	 * include message content.
	 *
	 * @param string $line Server reply.
	 */
	public static function debug_line( $line ) {
		if ( self::$debugging && count( self::$debug ) < 200 ) {
			self::$debug[] = trim( (string) $line );
		}
	}

	/**
	 * How this plugin's mail is sent, for the test result and the overview.
	 *
	 * @return string
	 */
	public static function transport() {
		return (string) Extensions::filter( 'accessible_forms_mail_transport', __( 'WordPress default (wp_mail)', 'accessible-forms-by-accessible-org' ) );
	}

	/**
	 * Record a wp_mail() failure.
	 *
	 * @param \WP_Error $error Error from WordPress.
	 */
	public static function capture_failure( $error ) {
		if ( is_wp_error( $error ) ) {
			self::$last_error = $error->get_error_message();
		}
	}

	/**
	 * Send a message and report what happened.
	 *
	 * @param array|string $to      Recipients.
	 * @param string       $subject Subject line.
	 * @param string       $message Body.
	 * @param array        $headers Headers.
	 * @return array{sent: bool, error: string}
	 */
	public static function send( $to, $subject, $message, array $headers = array() ) {
		self::$last_error = '';
		$settings         = Settings::get();
		if ( ! empty( $settings['test_delivery'] ) ) {
			if ( ! is_email( $settings['test_recipient'] ) ) {
				return array(
					'sent'  => false,
					'error' => 'Test recipient is not configured.',
				);
			}
			$to      = array( $settings['test_recipient'] );
			$headers = array_values(
				array_filter(
					$headers,
					static function ( $header ) {
						return ! preg_match( '/^(?:to|cc|bcc|reply-to):/i', trim( $header ) );
					}
				)
			);
			$subject = '[Test] ' . $subject;
		}

		$result = self::attempt( $to, $subject, $message, $headers );
		$routes = array( $result );
		if (
			! $result['sent'] && ! $result['uncertain'] &&
			true === Extensions::filter( 'accessible_forms_mail_fallback', false, $result )
		) {
			// One fallback only, using the same prepared message and WordPress's
			// normal configuration. Never redirect test mail or filter its body twice.
			$result   = self::attempt( $to, $subject, $message, $headers, false );
			$routes[] = $result;
		}
		$result['routes'] = $routes;
		return $result;
	}

	/** One scoped handoff. Add-ons may observe its outcome before a fallback is considered. */
	private static function attempt( $to, $subject, $message, array $headers, $configure = true ) {
		self::$last_error = '';
		$transport       = $configure ? self::transport() : __( 'WordPress default (wp_mail)', 'accessible-forms-by-accessible-org' );
		$uncertain       = false;
		$identity        = wp_generate_uuid4();
		$observe         = static function ( $mailer ) use ( $configure, $identity ) {
			Extensions::notify( 'accessible_forms_mailer_observe', $mailer, $configure, self::$debugging, $identity );
		};
		$previous_mailer =
			isset( $GLOBALS['phpmailer'] ) && is_object( $GLOBALS['phpmailer'] )
				? $GLOBALS['phpmailer']
				: null;
		if ( $previous_mailer ) {
			$GLOBALS['phpmailer'] = clone $previous_mailer; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Work on a scoped copy, preserving the shared mailer and its identity.
		}
		add_action( 'wp_mail_failed', array( self::class, 'capture_failure' ) );
		add_filter( 'wp_mail_from', array( self::class, 'filter_from' ), 20 );
		add_filter( 'wp_mail_from_name', array( self::class, 'filter_from_name' ), 20 );
		if ( $configure ) {
			add_action( 'phpmailer_init', array( self::class, 'configure' ) );
		}
		add_action( 'phpmailer_init', $observe, PHP_INT_MAX );
		try {
			add_action( 'phpmailer_init', array( self::class, 'plain_alternative' ) );
			$sent = wp_mail( $to, $subject, $message, $headers );
		} catch ( \Throwable $error ) {
			$sent             = false;
			$uncertain        = true;
			self::$last_error = 'timeout: transport interrupted; delivery is uncertain.';
		} finally {
			remove_action( 'phpmailer_init', $observe, PHP_INT_MAX );
			remove_action( 'phpmailer_init', array( self::class, 'plain_alternative' ) );
			remove_action( 'wp_mail_failed', array( self::class, 'capture_failure' ) );
			remove_filter( 'wp_mail_from', array( self::class, 'filter_from' ), 20 );
			remove_filter( 'wp_mail_from_name', array( self::class, 'filter_from_name' ), 20 );
			remove_action( 'phpmailer_init', array( self::class, 'configure' ) );
			// Restore the shared mailer so this plugin's SMTP settings and
			// headers never leak into email sent later by other code.
			if ( $previous_mailer ) {
				$GLOBALS['phpmailer'] = $previous_mailer; // phpcs:ignore WordPress.WP.GlobalVariablesOverride.Prohibited -- Restores the object that was there before this send.
			} else {
				unset( $GLOBALS['phpmailer'] );
			}
		}

		$result = array(
			'sent'  => (bool) $sent,
			'error' => $sent
				? ''
				: ( self::$last_error
					? self::$last_error
					: __( 'wp_mail() returned false without an error message.', 'accessible-forms-by-accessible-org' ) ),
		);
		$result['transport'] = $transport;
		$result['attempt_id'] = $identity;
		$result['uncertain'] = ! $sent && ( $uncertain || (bool) preg_match( '/timed?\s*out|timeout/i', $result['error'] ) );
		$observed = Extensions::filter( 'accessible_forms_mail_result', $result, $configure );
		// A result observer must not hide a successful handoff or invent one.
		if ( is_array( $observed ) && isset( $observed['sent'], $observed['error'], $observed['uncertain'] ) && $observed['sent'] === $result['sent'] ) {
			$result = $observed;
		}
		return $result;
	}

	public static function plain_alternative( $mailer ) {
		if ( 'text/html' === $mailer->ContentType ) {
			// Keep each answer on its own line: "Label: value".
			$text            = preg_replace( '#<head\b.*?</head>#is', '', (string) $mailer->Body );
			$text            = str_replace( array( '</th>', '</caption>', '</h1>' ), array( ': ', "\n", "\n\n" ), $text );
			$mailer->AltBody = trim(
				wp_strip_all_tags(
					str_replace( array( '</p>', '</tr>', '<br>', '<br />' ), "\n", $text )
				)
			);
		}
	}

	/**
	 * Send a test message, capturing the transport conversation when an add-on reports one.
	 *
	 * @param string $to Recipient.
	 * @return array{sent: bool, error: string, debug: string[], transport: string}
	 */
	public static function send_test( $to ) {
		self::$debug     = array();
		self::$debugging = true;
		$transport       = self::transport();

		$result = self::send(
			$to,
			sprintf(
				/* translators: %s: site name. */
				__( '[%s] Accessible Forms test email', 'accessible-forms-by-accessible-org' ),
				get_bloginfo( 'name' )
			),
			implode(
				"\n",
				array(
					__( 'This is a test message from the Accessible Forms plugin.', 'accessible-forms-by-accessible-org' ),
					'',
					/* translators: %s: transport description. */
					sprintf( __( 'Preferred mail route: %s', 'accessible-forms-by-accessible-org' ), $transport ),
					/* translators: %s: site URL. */
					sprintf( __( 'Site: %s', 'accessible-forms-by-accessible-org' ), home_url() ),
					/* translators: %s: current time. */
					sprintf( __( 'Time: %s', 'accessible-forms-by-accessible-org' ), current_time( 'mysql' ) ),
					'',
					__(
						'Check that this message reached your inbox. A successful handoff to a mail service does not guarantee inbox delivery. If a fallback was needed, the test result in WordPress shows both attempts.',
						'accessible-forms-by-accessible-org'
					),
				)
			)
		);

		self::$debugging = false;

		return array(
			'sent'      => $result['sent'],
			'error'     => $result['error'],
			'debug'     => self::$debug,
			'transport' => $result['transport'] ?? $transport,
			'uncertain' => $result['uncertain'] ?? false,
			'routes'    => $result['routes'] ?? array(),
		);
	}
}
