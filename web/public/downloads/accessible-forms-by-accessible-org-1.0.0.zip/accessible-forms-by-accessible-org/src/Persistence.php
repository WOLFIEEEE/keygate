<?php
/** Verified configuration writes. @package AccessibleForms */
namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Persistence {
	/** WordPress returns false for both unchanged values and failed writes. */
	private static function same( $actual, $expected ) {
		return is_scalar( $actual ) && is_scalar( $expected )
			? (string) $actual === (string) $expected
			: $actual === $expected;
	}

	public static function meta( $id, $key, $value ) {
		if ( self::same( get_post_meta( $id, $key, true ), $value ) ) {
			return true;
		}
		update_post_meta( $id, $key, wp_slash( $value ) );
		wp_cache_delete( $id, 'post_meta' );
		return self::same( get_post_meta( $id, $key, true ), $value );
	}

	public static function option( $key, $value, $autoload = null ) {
		if ( self::same( get_option( $key, null ), $value ) ) {
			return true;
		}
		update_option( $key, $value, $autoload );
		wp_cache_delete( $key, 'options' );
		wp_cache_delete( 'alloptions', 'options' );
		return self::same( get_option( $key, null ), $value );
	}
}
