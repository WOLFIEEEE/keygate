<?php
/**
 * Public content types a form can be placed in.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ContentTypes {
	/**
	 * Public content types with an editable content area, including custom types.
	 *
	 * @param bool $editable Only types the current user can edit.
	 * @return array<string, \WP_Post_Type>
	 */
	public static function types( $editable = false ) {
		$types = array();
		foreach ( get_post_types( array(), 'objects' ) as $name => $type ) {
			if ( in_array( $name, array( 'attachment', 'accessible_form' ), true ) || ! is_post_type_viewable( $type ) || ! post_type_supports( $name, 'editor' ) ) {
				continue;
			}
			if ( $editable && ! current_user_can( $type->cap->edit_posts ) ) {
				continue;
			}
			$types[ $name ] = $type;
		}
		return $types;
	}
}
