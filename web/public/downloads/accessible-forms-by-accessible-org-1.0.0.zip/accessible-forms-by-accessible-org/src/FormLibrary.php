<?php
/** Built-in, reviewed form templates and form creation. @package AccessibleForms */
namespace AccessibleForms;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
class FormLibrary {
	public static function templates() {
		return array(
			'contact'  => __( 'Contact', 'accessible-forms-by-accessible-org' ),
			'support'  => __( 'Support request', 'accessible-forms-by-accessible-org' ),
			'feedback' => __( 'Feedback', 'accessible-forms-by-accessible-org' ),
			'quote'    => __( 'Quote request', 'accessible-forms-by-accessible-org' ),
			'event'    => __( 'Event enquiry', 'accessible-forms-by-accessible-org' ),
			'barrier'  => __( 'Report an accessibility barrier', 'accessible-forms-by-accessible-org' ),
		);
	}
	public static function template( $key ) {
		if ( ! isset( self::templates()[ $key ] ) ) {
			return null;
		}
		$schema            = Schema::defaults();
		$schema['heading'] = self::templates()[ $key ];
		if ( 'support' === $key ) {
			array_splice(
				$schema['fields'],
				2,
				0,
				array(
					array(
						'name'     => 'topic',
						'label'    => __( 'What do you need help with?', 'accessible-forms-by-accessible-org' ),
						'type'     => 'select',
						'options'  => array(
							__( 'Using the service', 'accessible-forms-by-accessible-org' ),
							__( 'My account', 'accessible-forms-by-accessible-org' ),
							__( 'Something else', 'accessible-forms-by-accessible-org' ),
						),
						'required' => true,
					),
				)
			);
		}
		if ( 'feedback' === $key ) {
			$schema['fields'][0]['required'] = false;
			$schema['fields'][1]['required'] = false;
			$schema['fields'][2]['label']    = __( 'What could we improve?', 'accessible-forms-by-accessible-org' );
		}
		if ( 'quote' === $key ) {
			array_splice(
				$schema['fields'],
				2,
				0,
				array(
					array(
						'name'         => 'company',
						'label'        => __( 'Company', 'accessible-forms-by-accessible-org' ),
						'type'         => 'text',
						'autocomplete' => 'auto',
					),
					array(
						'name'  => 'deadline',
						'label' => __( 'Preferred start date', 'accessible-forms-by-accessible-org' ),
						'type'  => 'date',
					),
				)
			);
		}
		if ( 'event' === $key ) {
			array_splice(
				$schema['fields'],
				2,
				0,
				array(
					array(
						'name'     => 'event_date',
						'label'    => __( 'Event date', 'accessible-forms-by-accessible-org' ),
						'type'     => 'date',
						'required' => true,
					),
					array(
						'name'      => 'guests',
						'label'     => __( 'Number of guests', 'accessible-forms-by-accessible-org' ),
						'type'      => 'number',
						'min'       => '1',
						'max'       => '100000',
						'increment' => '1',
					),
				)
			);
		}
		if ( 'barrier' === $key ) {
			$schema = self::barrier( $schema );
		}
		return Schema::sanitize( $schema )[0];
	}

	/**
	 * Accessibility feedback form for an accessibility statement. Only the
	 * description is required: asking for less makes reporting easier, and
	 * assistive-technology details can reveal health information.
	 *
	 * @param array $schema Default schema.
	 * @return array
	 */
	private static function barrier( array $schema ) {
		$schema['fields']           = array(
			array(
				'name'         => 'name',
				'label'        => __( 'Your name', 'accessible-forms-by-accessible-org' ),
				'type'         => 'text',
				'autocomplete' => 'auto',
			),
			array(
				'name'  => 'email',
				'label' => __( 'Email address', 'accessible-forms-by-accessible-org' ),
				'type'  => 'email',
				'help'  => __( 'Only needed if you would like a reply.', 'accessible-forms-by-accessible-org' ),
			),
			array(
				'name'    => 'page',
				'label'   => __( 'Page or feature with the problem', 'accessible-forms-by-accessible-org' ),
				'type'    => 'url',
				'help'    => __( 'Paste the address, or describe where it is in your message.', 'accessible-forms-by-accessible-org' ),
				'prefill' => 'referrer',
			),
			array(
				'name'     => 'problem',
				'label'    => __( 'What happened?', 'accessible-forms-by-accessible-org' ),
				'type'     => 'textarea',
				'help'     => __( 'What were you trying to do, and what got in the way?', 'accessible-forms-by-accessible-org' ),
				'required' => true,
			),
			array(
				'name'    => 'tools',
				'label'   => __( 'What were you using?', 'accessible-forms-by-accessible-org' ),
				'type'    => 'checkbox',
				'help'    => __( 'Optional. Share only what you are comfortable with.', 'accessible-forms-by-accessible-org' ),
				'options' => array(
					__( 'Screen reader', 'accessible-forms-by-accessible-org' ),
					__( 'Screen magnifier or zoom', 'accessible-forms-by-accessible-org' ),
					__( 'Keyboard only', 'accessible-forms-by-accessible-org' ),
					__( 'Voice control', 'accessible-forms-by-accessible-org' ),
					__( 'Switch device', 'accessible-forms-by-accessible-org' ),
					__( 'Captions or transcripts', 'accessible-forms-by-accessible-org' ),
					__( 'Something else', 'accessible-forms-by-accessible-org' ),
					__( 'Prefer not to say', 'accessible-forms-by-accessible-org' ),
				),
			),
			array(
				'name'  => 'device',
				'label' => __( 'Browser and device', 'accessible-forms-by-accessible-org' ),
				'type'  => 'text',
				'help'  => __( 'For example: Safari on iPhone, or Firefox on Windows.', 'accessible-forms-by-accessible-org' ),
			),
			array(
				'name'    => 'reply',
				'label'   => __( 'Would you like a reply?', 'accessible-forms-by-accessible-org' ),
				'type'    => 'radio',
				'options' => array(
					__( 'Yes, by email', 'accessible-forms-by-accessible-org' ),
					__( 'No reply needed', 'accessible-forms-by-accessible-org' ),
				),
			),
		);
		$schema['submit_label']     = __( 'Send report', 'accessible-forms-by-accessible-org' );
		$schema['subject_template'] = __( 'Accessibility barrier reported on {site}', 'accessible-forms-by-accessible-org' );
		$schema['success_message']  = __( 'Thank you for telling us. We read every report and use it to fix problems.', 'accessible-forms-by-accessible-org' );
		// Keep these reports for a shorter time and store no browser or IP data.
		$schema['privacy'] = array(
			'retention_days'   => 180,
			'minimal_metadata' => true,
		);
		return $schema;
	}
	public static function create( array $schema, $title ) {
		if ( ! current_user_can( 'edit_accessible_forms' ) ) {
			return new \WP_Error( 'forbidden', __( 'You cannot create forms.', 'accessible-forms-by-accessible-org' ) );
		}
		[$schema, $errors] = Schema::sanitize( $schema );
		if ( $errors ) {
			return new \WP_Error( 'invalid', implode( ' ', $errors ) );
		}
		$id = wp_insert_post(
			wp_slash(
				array(
					'post_type'   => 'accessible_form',
					'post_status' => 'draft',
					'post_title'  => FormOptions::text( $title, 200 ) ?: $schema['heading'],
					'post_author' => get_current_user_id(),
				)
			),
			true
		);
		if ( ! is_wp_error( $id ) ) {
			if ( ! Schema::save( $id, $schema ) ) {
				wp_delete_post( $id, true );
				return new \WP_Error( 'storage', __( 'The form could not be saved. Please try again.', 'accessible-forms-by-accessible-org' ) );
			}
			Audit::record( 'form_created', $id );
		}
		return $id;
	}
}
