=== Accessible Forms by Accessible.org ===
Contributors: accessibledotorg
Tags: contact form, accessibility, form builder, forms, wcag
Requires at least: 6.4
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Contact forms with visible labels, linked error summaries, contrast-checked themes and a clear entries screen.

== Description ==

Accessible Forms helps you build contact forms that people can complete with a keyboard, a screen reader, magnification or a phone. Visible labels are required, choice fields use real groups, and validation lists every problem in a linked summary. Create as many forms as your site needs, each with its own fields, recipients and confirmation message.

= Build forms =

* Thirteen field types: text, email, telephone, URL, number, date, time, section heading, message, dropdown, radio group, checkbox group and consent checkbox.
* A guided editor with four steps: Build, Style, Email & confirmation, and Review & publish. Advanced settings stay collapsed until you need them.
* Help text, required fields, answer limits, automatic browser-autofill hints, keyboard field reordering, field search, duplicate field and undo for a removed field.
* Starter templates, including "Report an accessibility barrier" for your accessibility statement, and form duplication.
* Unsaved edits are kept in your browser and offered back after a reload or crash.

= Style with confidence =

* Four built-in themes: Classic light, Ocean blue, Forest green and Midnight. Every theme passes the contrast checks.
* Contrast is checked again when the form is saved and when it is shown, so a form never renders colors that fail.
* The styles that accessibility depends on (focus indicator, readable text sizes, visible labels, real checkboxes and radios, target sizes and reflow) are protected against ordinary theme and page-builder CSS.
* Content suggestions in Review & publish point out vague or duplicate labels, placeholder-style wording, long help text, forms that require everything, a missing email question, and form headings that skip a level on the page where the form is placed. Suggestions never block publishing.

= Publish anywhere =

* An Accessible Form block with a searchable list of published forms and a live preview.
* "Choose where it appears" adds the form to an existing page, post or public custom post type, or creates a new draft with the form included.
* A shortcode for the Classic Editor and page builders.
* Draft changes stay separate from the live form until you publish them.
* Close a form by hand, with your own closed message.

= Manage submissions =

* Entries with search, removable filter summaries, site-date shortcuts, read and unread, spam review and Trash.
* In-place list navigation, clear entry details, contextual empty states and permission-checked bulk Undo.
* A remembered setup checklist and clear feedback for saved, unpublished and recovered edits.
* One notification email per form, to as many recipients as you need, sent through your normal WordPress mail setup, with an email sample, a test email, a staging test inbox and automatic retries.
* A thank-you page or an inline confirmation message.
* Automatic retention, per-form retention, and WordPress personal data export and erasure.
* An activity record of changes and deletions, without answers.

= Spam protection without tracking =

A honeypot, rate limits and link limits run on your own server. You can add self-hosted ALTCHA proof-of-work verification, which contacts no outside service.

= Accessibility =

Forms include associated labels, optional help text, semantic choice groups, visible required indicators, keyboard focus styles and server-side validation. Repeated embeds use separate control IDs. Forms submit without JavaScript; JavaScript adds in-page submission without a reload.

When you view a page with a form while logged in as someone who can edit it, a live check tests that page as your theme actually renders it (labels, focus, contrast, target size, covered controls, text spacing) and shows the results above the form, only to you. Results are listed under Tools → Health.

These features support accessible form design. They do not guarantee WCAG conformance or legal compliance. Your theme, page structure, field wording and assistive technology all affect the final experience. Test the finished page with a keyboard and a screen reader. Automated checks do not replace a manual accessibility review.

= Privacy =

This plugin sends no analytics or telemetry. Entries store the submitted values, submission time, the page path (without query parameters), browser information, a salted IP hash, spam status and notification outcome. Each form can store less of this metadata. The live accessibility check runs only for logged-in editors and stores, on your site, the page path, the time and the problems it found; results expire after 30 days. See the FAQ for retention, exports and uninstall behavior.

= Accessible Forms Pro =

An optional paid add-on, Accessible Forms Pro, adds file uploads, conditional fields, steps, custom styling, more notification options and entry workflow tools. This plugin is complete without it, and accessibility and privacy features are never held back for Pro.

= Source code =

All PHP, CSS and JavaScript is included in human-readable form in the plugin ZIP, and no build step is needed to modify the plugin. The bundled ALTCHA widget and library are unminified; THIRD-PARTY.txt links their original source and build instructions.

== External services ==

This plugin does not connect to outside services.

ALTCHA verification runs entirely on your site. The widget, translations, worker, challenge generation and verification are all served by your WordPress installation. There is no account, API key, tracking collector, verification cookie or call to an ALTCHA-hosted service.

== Installation ==

1. Upload the plugin ZIP under Plugins → Add New Plugin → Upload Plugin, then activate it.
2. Open Accessible Forms → Add New Form. Give the form an internal name, then work through Build, Style, and Email & confirmation. Start with the default contact fields or pick a template.
3. Save a draft at any step. In Review & publish, fix every blocking problem, use Open keyboard test preview with sample answers, review the questions and instructions, and confirm the required author review before publishing.
4. Choose "Choose where it appears" on the published form, or "Place form" in the forms list, and pick a page or post, or follow the block and shortcode instructions. The form is only added to your site when you choose a placement.
5. On the page using your theme, repeat keyboard, zoom and screen-reader checks before sharing it. Submit a sample message and check Accessible Forms → Entries and your mailbox.
6. Review Email delivery, Spam protection and Privacy under Settings.

== Frequently Asked Questions ==

= Can I create multiple forms? =

Yes. Each form has its own fields, theme, recipients, subject, button text and confirmation message. Duplicate a form to start from an existing design. The copy is a draft; entries stay with the original form.

= How do I add a form to a page, post or custom post type? =

Publish the form, then choose “Choose where it appears” in Review & publish, or “Place form” in the forms list. Choose a content type, search for an item and choose its initial position. Open its editor, click “Insert form”, review the position and save. Existing content is preserved, and you can move the block between paragraphs using the normal WordPress block controls.

“Create a new page or post instead” starts a draft of the selected content type with the form already included. Sites using the Classic Editor receive a shortcode. Your role's editing, creation and template restrictions still apply. Public custom post types must support the WordPress content editor to appear in this picker.

= Can I add the form as a block or put it in a precise position? =

Yes. Insert the Accessible Form block in a page, post, supported custom content type or template and search for a published form by name. Move the block where you want it. The block previews the published form. Use “Refresh forms” after publishing a new form, or “Refresh preview” after publishing changed settings. Preview controls cannot send a submission.

The block offers wide and full-width alignment when the theme supports them. To place a form in a sidebar, use a block-based widget area or a shortcode-capable widget.

= How do I choose a thank-you page on a site with many pages? =

In Email & confirmation, expand Use a thank-you page. Search by name or load more pages, then choose one under After submission. Only published pages without passwords are offered. If a chosen page later becomes unavailable or password-protected, visitors receive the inline confirmation instead.

= Can I change the colors? =

Choose one of the four built-in themes in the Style step. Each passes the plugin's contrast checks: at least 4.5:1 for text and button labels, and 3:1 for button and field boundaries. Focus indicators, checkbox marks, validation feedback and confirmation text use the same checked palette. Your own colors, text size, spacing and layout are available with Accessible Forms Pro, under the same checks.

These checks cover the plugin's own color surfaces. A site theme, custom CSS or browser autofill styling can affect the completed page, so inspect it after embedding the form.

= Is browser autofill automatic? =

Yes. Email, telephone and URL fields receive the relevant browser hints automatically. Recognizable name, company, job title and address labels receive suitable hints too. Advanced options let you choose a specific purpose. To turn autofill off for a question that looks like the visitor's own details, confirm that it asks about someone else, such as a friend's email.

= Can I save drafts? =

Yes. Save a draft at any setup step. Changes to a published form remain separate until you choose Publish changes. Review & publish previews your current edits; the block and public page use the published version.

If your edits break an accessibility rule, they are still saved, and the editor lists what to fix each time you open it. They cannot be published until the problems are fixed, and visitors keep seeing the last version that passed. You can also discard them. The editor points out most problems as you type.

Before each publication, review the questions and instructions and confirm the required author review in Review & publish. Changes clear that confirmation. Server checks still run without JavaScript, and first publication through Quick Edit or bulk actions requires the form editor's review. Passing checks is not an accessibility certification.

Open keyboard test preview creates a private, working copy of current edits for 30 minutes. Test questions, errors and confirmation with sample answers. It creates no entries or notifications and uploads no files. Without JavaScript file selection is disabled. Test current edits with your site theme lets you choose an editable page for a private snapshot, replacing an existing embed or appending to normal page content without changing the page or live form. Spam verification, save/resume, actual attachments and delivery need a normal staging test.

Accessibility test record saves the tested draft and your reported browser, assistive technology, page and results. Leave unperformed tests as Not tested. Ten recent reports are retained and relevant changes mark them out of date. Recording works without JavaScript and does not publish or certify the form. Covering checks examine all active plugin controls and repeat for states you reach; large or interrupted checks remain incomplete.

= What if a published form does not meet newer checks? =

When an update makes the checks stricter, a published form that no longer passes stays online, so the pages that use it keep working. The forms list, the editor and Tools → Health say which forms need fixing and what to fix.

= Why are visible labels required? =

Labels keep a field's purpose visible while typing and connect the control with its accessible name. Placeholders cannot replace them in this editor. Labels, choices, the heading and the button text must be written in words, not only symbols or emoji, because screen readers announce them as names. Two questions can share a label only under different section headings, and the heading then becomes part of each question's name, such as "Billing address Street".

= Does it work without JavaScript? =

The public form submits and shows validation feedback without JavaScript. Cached embeds may request one additional review before sending; an uncached form link is also available. If ALTCHA verification is enabled, messages without a token go to Needs review without email notifications. Adding and rearranging fields in the admin editor requires JavaScript.

= Do I have to configure SMTP? =

No. Notifications use your existing WordPress mail setup, including any SMTP plugin you already use. A successful test means the mail transport accepted the message; check the recipient's inbox to confirm delivery.

= What happens if saving or email delivery fails? =

A submission is stored before a notification is attempted. If storage fails, the form shows an error and keeps the visitor's answers. If email fails, the stored entry records the failure and the notification is retried. An uncertain network response does not trigger an automatic second submission.

= Are notifications sent immediately? =

Each submission is stored first, then a background task sends its notification. Failed attempts retry; if the outcome is uncertain, the entry is flagged for review instead of being resent automatically. WordPress cron depends on site traffic or a server cron job. Settings include a staging test inbox that replaces the real recipients.

= Who can see submissions? =

Administrators have full access. Editors can build forms but do not automatically see submissions: form editing, reading submissions, exporting, deleting and sending notifications are separate permissions.

= What happens when I delete a form? =

WordPress moves it to Trash first. Its existing entries are retained and remain accessible in Entries. You can delete entries separately or let the retention policy remove them.

= What happens when I uninstall the plugin? =

Completed entries and configuration are retained by default. Enable “Delete all forms and entries when the plugin is deleted” under Privacy to also remove forms, entries and settings. Deactivation keeps data.

= How long are entries kept? =

Received submissions are kept for 365 days by default, and each form can set its own period. A new submission keeps the retention policy in effect when it was received. Setting the period to 0 keeps entries indefinitely. Spam and Needs review entries have a separate 30-day limit. Activity records omit answers and credentials and expire after 90 days. Trash expires after 30 days or the earlier applicable limit. A daily WordPress cron job removes expired records.

= How do privacy exports and erasure work? =

WordPress privacy tools match entries by an exact submitted email address; forms without an email field need manual review. Erasure removes matching entries along with their notification payloads, private notes and any stored attachments. Suggested policy text is available in WordPress's privacy policy guide.

= How does ALTCHA verification behave? =

ALTCHA runs a proof-of-work check automatically when a visitor uses a form. Challenges are bound to the form and site, expire after 20 minutes, and can be accepted only once. If JavaScript is off or a token is missing, invalid, expired or reused, the message is held in Needs review without an email notification, so review that list regularly. The live site must use HTTPS (localhost also works for development). Proof of work raises the cost of automated abuse; it does not catch all spam or replace moderation.

= I used an earlier development build. Where did some features go? =

In the 1.0.0 baseline, file uploads, conditional fields, steps and saved progress, custom colors and layout, brand presets, extra notifications, visitor receipts, webhooks, custom SMTP, Turnstile, revision history, automatic placement, import and export, CSV exports, entry workflow, replies, insights and team roles are part of Accessible Forms Pro. Nothing is deleted: your settings stay with each form and come back when Pro is active. Until then, forms keep working with the free features. An upload field is kept but not shown, conditional questions are always shown, and a multi-step form shows on one page. Saved per-form entry access restrictions remain enforced by the free plugin while Pro is inactive. Editing them requires active Pro.

= Are content suggestions an accessibility audit? =

No. They flag common wording and structure problems that make forms harder to complete. They cannot tell whether your questions make sense to your visitors, and they do not check your theme or page. Test the finished page with a keyboard and a screen reader.

= What does this plugin not do? =

It focuses on contact forms and enquiries. It does not process payments, reserve event inventory, or offer arbitrary custom CSS controls.

== Screenshots ==

1. The guided form editor: Build, Style, Email & confirmation, and Review & publish.
2. Choosing a contrast-checked theme in the Style step.
3. Adding a published form to an existing or new page.
4. An embedded form showing the linked error summary.
5. The Entries screen with filters and spam review.
6. Settings for email delivery, spam protection and privacy.

= How are submission dates stored? =

New submission, reply and resolution times are stored in UTC and shown in the current WordPress site time zone. Date filters use calendar days in that zone, including daylight-saving changes. Follow-up dates remain calendar dates. Exported event times include their UTC offset.

Records from development builds may have dates without a known original time zone. They retain their original values and are labelled unconfirmed. Under Tools → Health, a settings administrator can confirm the original zone for all records or a selected form. Conversion runs in resumable batches and retains the original dates. Repeated daylight-saving hours stay unconfirmed unless an earlier or later occurrence is explicitly chosen. Invalid or nonexistent local times are never guessed. Unconfirmed dates are excluded from response-time statistics and creation-date-based cleanup; an existing UTC expiry or Trash deadline still applies.

== Changelog ==

= 1.0.0 =
* Private previews of unpublished edits inside editable themed pages; revision-linked manual test records with explicit incomplete, problem and stale states.
* Covering checks for all active controls, reached-state rechecks and focus scrolling around fixed overlays.
* Initial release baseline of Accessible Forms.
* Unlimited forms, thirteen field types, starter templates and a guided editor with separate draft and published versions.
* Visible labels, semantic choice groups, linked validation summaries, keyboard focus and contrast-checked themes.
* Required author review before publication, server-enforced publication checks and linked blocking feedback.
* Private keyboard test previews for unpublished edits, with real validation and no entries, uploaded files or notifications.
* Block, shortcode and guided placement for pages, posts and supported custom content types.
* Searchable Forms and Entries screens with in-place navigation, clear filters, contextual empty states and readable entry details.
* Shared admin style roles, readable metadata and rounded small-screen actions; secondary shortcode tools, progressive filters and an actionable Unread view with safe bulk Undo and return focus.
* Visible required publication review, grouped previews and test records, and a clear placement follow-up.
* Accurate bulk-action feedback, permission-checked Undo, browser draft recovery and a remembered setup checklist.
* WordPress email delivery, test messages, a staging inbox, background retries and visible delivery outcomes.
* Local spam filters and optional self-hosted ALTCHA verification without tracking.
* Per-form retention, private access controls, redacted diagnostics, activity records and personal data export and erasure.
* UTC event storage, site-time-zone display and date filters, and resumable conversion of confirmed historical dates with original values preserved.
* Entry pagination loads only the displayed records; indexed list and summary queries support larger collections.

== Upgrade Notice ==

= 1.0.0 =
Initial release baseline. Back up and manually replace earlier development builds; forms and entries are preserved. Confirm historical date zones under Tools → Health. Install this free plugin before Pro 1.0.0.
