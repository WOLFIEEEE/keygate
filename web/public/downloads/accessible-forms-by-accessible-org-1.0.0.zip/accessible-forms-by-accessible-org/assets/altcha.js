/** Register a same-origin worker. No hosted ALTCHA service or tracking collector. */
(function () {
	'use strict';
	if (!window.$accessibleFormsAltcha || !window.AccessibleFormsAltcha) {
		return;
	}
	window.$accessibleFormsAltcha.algorithms.set('PBKDF2/SHA-256', function () {
		return new Worker(window.AccessibleFormsAltcha.workerUrl);
	});
})();
