/** Search adds options to an ordinary select and preserves its current selection. */
(function () {
	'use strict';
	if (!window.AccessibleFormsSearch) { return; }
	var __ = wp.i18n.__, sprintf = wp.i18n.sprintf;
	var ready = new WeakSet();
	function initPickers(scope) {
		scope.querySelectorAll('[data-af-form-picker]').forEach(function (root) {
			if (ready.has(root)) { return; }
			ready.add(root);
			var select = root.querySelector('select'), query = root.querySelector('[type="search"]');
			var search = root.querySelector('[data-af-picker-search]'), more = root.querySelector('[data-af-picker-more]');
			var status = root.querySelector('[role="status"]');
			root.querySelector('[data-af-picker-tools]').hidden = false;
			var load = window.AccessibleFormsSearch({
				url: root.dataset.url, page: Number(root.dataset.page) || 1,
				parameters: { action: 'accessible_forms_admin_forms', nonce: root.dataset.nonce, mode: root.dataset.mode },
				start: function () { select.setAttribute('aria-busy', 'true'); search.disabled = true; more.disabled = true; status.textContent = __('Finding forms…', 'accessible-forms-by-accessible-org'); },
				success: function (data, context) {
					if (!context.append) { Array.from(select.options).forEach(function (option) { if (!option.selected && option.value !== '') { option.remove(); } }); }
					data.items.forEach(function (item) {
						if (!Number.isInteger(item.id) || typeof item.label !== 'string' || Array.from(select.options).some(function (option) { return option.value === String(item.id); })) { return; }
						var option = document.createElement('option'); option.value = String(item.id); option.textContent = item.label; select.appendChild(option);
					});
					more.hidden = context.page >= data.pages;
					/* translators: %d: number of forms found in a batch. */
					status.textContent = sprintf(__('%d matching forms loaded. Choose a form from the list.', 'accessible-forms-by-accessible-org'), data.items.length);
				},
				error: function () { status.textContent = __('Forms could not be loaded. Search again to retry. Your selected form is kept.', 'accessible-forms-by-accessible-org'); },
				end: function () { select.removeAttribute('aria-busy'); search.disabled = false; more.disabled = false; },
			});
			search.addEventListener('click', function () { load(query.value, false); });
			query.addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); load(query.value, false); } });
			more.addEventListener('click', function () { load(query.value, true); });
		});
	}
	initPickers(document);
	document.addEventListener('af:panelready', function (event) { initPickers(event.detail.root); });
})();
