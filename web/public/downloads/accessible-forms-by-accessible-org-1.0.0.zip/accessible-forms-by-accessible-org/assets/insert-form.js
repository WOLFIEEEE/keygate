/** Insert into the current editing session; publishing remains a WordPress action. */
(function (wp) {
	'use strict';
	var config = window.AccessibleFormsPlacement;
	if (!config) {
		return;
	}
	// WordPress localization can serialize scalar IDs as strings.
	config.formId = Number(config.formId);
	config.pageId = Number(config.pageId);
	var __ = wp.i18n.__;
	var shortcode = '[accessible_form id="' + config.formId + '"]';
	function matchingBlock(blocks) {
		for (var i = 0; i < blocks.length; i++) {
			var block = blocks[i];
			if (block.name === 'accessible-forms/form' && Number(block.attributes.formId) === config.formId) {
				return block.clientId;
			}
			if (block.innerBlocks && block.innerBlocks.length) {
				var nested = matchingBlock(block.innerBlocks);
				if (nested) {
					return nested;
				}
			}
		}
		return null;
	}
	function containsShortcode(content) {
		var start = 0,
			match;
		while ((match = wp.shortcode.next('accessible_form', content, start))) {
			if (Number(match.shortcode.attrs.named.id) === config.formId) {
				return true;
			}
			start = match.index + match.content.length;
		}
		return false;
	}
	wp.domReady(function () {
		if (!config.isBlock) {
			var notice = document.getElementById('af-placement-notice');
			var button = document.getElementById('af-insert-shortcode');
			if (!notice || !button) {
				return;
			}
			var alreadyAdded = __(
				'This form is already in this content. No duplicate was added.',
				'accessible-forms-by-accessible-org',
			);
			if (config.created || config.alreadyPresent) {
				if (config.alreadyPresent && !config.created) {
					notice.querySelector('p').textContent = alreadyAdded;
				}
				button.remove();
				return;
			}
			function complete(text) {
				notice.querySelector('p').textContent = text;
				button.disabled = true;
				button.textContent = __('Form added', 'accessible-forms-by-accessible-org');
			}
			button.addEventListener('click', function () {
				var editor = window.tinymce && window.tinymce.get('content');
				var textarea = document.getElementById('content');
				var content =
					editor && !editor.isHidden() ? editor.getContent() : textarea ? textarea.value : '';
				if (containsShortcode(content)) {
					complete(alreadyAdded);
					return;
				}
				if (editor && !editor.isHidden()) {
					editor.setContent(config.position === 'before' ? '<p>' + shortcode + '</p>' + content : content + '<p>' + shortcode + '</p>');
					editor.setDirty(true);
					editor.save();
				} else if (textarea) {
					textarea.value = config.position === 'before' ? shortcode + '\n\n' + content : content + '\n\n' + shortcode;
					textarea.dispatchEvent(new Event('input', { bubbles: true }));
					textarea.dispatchEvent(new Event('change', { bubbles: true }));
				} else {
					return;
				}
				complete(
					__(
						'Form added. Review the content, then save or update to keep this change.',
						'accessible-forms-by-accessible-org',
					),
				);
			});
			return;
		}
		var notices = wp.data.dispatch('core/notices');
		function message(status, text, actions) {
			notices.createNotice(status, text, {
				id: 'accessible-forms-placement',
				isDismissible: true,
				actions: actions || [],
			});
		}
		function insert() {
			var editor = wp.data.select('core/editor');
			var blockEditor = wp.data.select('core/block-editor');
			if (!editor || Number(editor.getCurrentPostId()) !== config.pageId || !blockEditor) {
				message(
					'warning',
					__(
						'The editor is still loading. Try inserting the form again once the editor is ready.',
						'accessible-forms-by-accessible-org',
					),
					[{ label: __('Insert form', 'accessible-forms-by-accessible-org'), onClick: insert }],
				);
				return;
			}
			var existing = matchingBlock(blockEditor.getBlocks());
			if (existing || config.alreadyPresent || containsShortcode(editor.getEditedPostContent())) {
				if (existing) {
					wp.data.dispatch('core/block-editor').selectBlock(existing);
				}
				message(
					'info',
					__('This form is already in this content. No duplicate was added.', 'accessible-forms-by-accessible-org'),
				);
				return;
			}
			if (!blockEditor.canInsertBlockType('accessible-forms/form')) {
				message(
					'warning',
					__(
						'This content’s template or allowed-block settings prevent adding a form here. Choose editable content or ask an administrator to review those settings.',
						'accessible-forms-by-accessible-org',
					),
				);
				return;
			}
			var block = wp.blocks.createBlock('accessible-forms/form', { formId: config.formId });
			wp.data.dispatch('core/block-editor').insertBlocks([block], config.position === 'before' ? 0 : blockEditor.getBlockCount());
			if (!wp.data.select('core/block-editor').getBlock(block.clientId)) {
				message(
					'warning',
					__(
						'The form could not be inserted. Check this content’s editing permissions and template settings.',
						'accessible-forms-by-accessible-org',
					),
				);
				return;
			}
			message(
				'success',
				__(
					'Form added. Review its position, then save or update the content to keep this change.',
					'accessible-forms-by-accessible-org',
				),
			);
		}
		if (config.created) {
			message(
				'success',
				__(
					'Draft created with your form. Review the content and publish when ready.',
					'accessible-forms-by-accessible-org',
				),
			);
		} else if (config.alreadyPresent) {
			message(
				'info',
				__('This form is already in this content. No duplicate was added.', 'accessible-forms-by-accessible-org'),
			);
		} else {
			message(
				'info',
				wp.i18n.sprintf(
					/* translators: %s: form title. */ __(
						'Ready to add “%s” at the chosen position in this content.',
						'accessible-forms-by-accessible-org',
					),
					config.title,
				),
				[{ label: __('Insert form', 'accessible-forms-by-accessible-org'), onClick: insert }],
			);
		}
	});
})(window.wp);
