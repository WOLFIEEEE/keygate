/** Progressive list navigation. Server pages, controls and permissions stay authoritative. */
(function () {
	'use strict';
	var __ = wp.i18n.__, sprintf = wp.i18n.sprintf, _n = wp.i18n._n;
	var forms = document.body.classList.contains('af-forms-list');
	var root = forms ? document.querySelector('#wpbody-content .wrap') : document.querySelector('.af-entry-list');
	if (!root) { return; }
	var listForm = root.querySelector(forms ? '#posts-filter' : '#af-entries-form');
	if (!listForm) { return; }
	var key = (window.AccessibleFormsExperience || {}).storageKey;
	var status = document.getElementById('af-list-status');
	if (!status) { status = document.createElement('p'); status.id = 'af-list-status'; status.className = 'screen-reader-text'; status.setAttribute('role', 'status'); status.setAttribute('aria-atomic', 'true'); root.append(status); }
	var recovery = document.createElement('p'); recovery.className = 'af-list-recovery'; recovery.hidden = true;
	var fullPage = document.createElement('a'); fullPage.className = 'button'; fullPage.textContent = __('Open the latest list as a full page', 'accessible-forms-by-accessible-org'); recovery.append(fullPage); root.prepend(recovery);
	var current = null, sequence = 0, displayed = clean(location.href), selection = -1;
	document.documentElement.dataset.afListRevision = '0';
	function say(message) { status.textContent = message; }
	function clean(value) { var url = new URL(value, location.href); ['_wpnonce', '_wp_http_referer', 'action', 'action2', 'entry[]', 'filter_action', 'af_notice'].forEach(function (name) { url.searchParams.delete(name); }); url.hash = ''; Array.from(url.searchParams).forEach(function (item) { if (!item[1] || (item[0] === 'form_id' && item[1] === '0') || (item[0] === 'paged' && item[1] === '1')) { url.searchParams.delete(item[0]); } }); url.searchParams.sort(); return url.href; }
	function store(value) { if (!key) { return; } try { if (value) { sessionStorage.setItem(key, JSON.stringify(value)); } else { return JSON.parse(sessionStorage.getItem(key) || 'null'); } } catch (error) { return null; } }
	function remember(link) {
		var row = link && link.closest('tr'), neighbour = row && (row.nextElementSibling || row.previousElementSibling);
		store({ url: clean(location.href), focus: row ? row.id : '', neighbour: neighbour ? neighbour.id : '', scroll: window.scrollY, time: Date.now() });
	}
	function restore() {
		var saved = store();
		if (!saved || saved.url !== clean(location.href) || Date.now() - saved.time > 30 * 60000) { return; }
		var row = saved.focus && (document.getElementById(saved.focus) || document.getElementById(saved.neighbour)), link = row && row.querySelector('a.row-title');
		// Opening an unread entry removes it from this view. Keep a useful keyboard position.
		if (saved.focus && !link) { link = root.querySelector('#the-list a.row-title, #af-result-summary'); if (link && link.tagName !== 'A') { link.tabIndex = -1; } }
		if (link) { link.focus({ preventScroll: true }); }
		window.scrollTo(0, saved.scroll);
		if (link && link.id === 'af-result-summary') { link.scrollIntoView({ block: 'nearest' }); }
	}
	function selected() {
		var count = root.querySelectorAll('#the-list input[name="entry[]"]:checked').length;
		var output = root.querySelector('#af-selection-status');
		if (output && count !== selection) {
			output.hidden = count === 0;
			/* translators: %d: number of selected entries. */
			output.textContent = count ? sprintf(_n('%d entry selected', '%d entries selected', count, 'accessible-forms-by-accessible-org'), count) : ''; selection = count; }
	}
	root.addEventListener('change', selected);
	// WordPress updates Select all after the native change listener returns.
	root.addEventListener('click', function (event) { if (event.target.matches('input[type="checkbox"]')) { window.setTimeout(selected, 0); } });
	root.addEventListener('keydown', function (event) {
		var details = event.target.closest('.af-row-more, .af-shortcode-tools, .af-more-filters');
		if (details && event.key === 'Escape') { details.open = false; details.querySelector('summary').focus(); }
	});
	root.addEventListener('click', function (event) {
		var link = event.target.closest('a');
		if (link && /[?&]page=accessible-forms-entry(?:&|$)/.test(link.href) && !event.ctrlKey && !event.metaKey && !event.shiftKey && event.button === 0) { remember(link); }
	});
	function restoreReady() {
		// Native row-action focus handlers must be ready before returning focus to a row.
		if (window.jQuery) { window.jQuery(function () { window.requestAnimationFrame(restore); }); }
		else { window.requestAnimationFrame(restore); }
	}
	window.addEventListener('pageshow', restoreReady);
	restoreReady();
	selected();
	if (!window.fetch || !window.AbortController || !window.DOMParser || !history.pushState) { return; }
	root.dataset.afListEnhanced = 'true';
	function prepared(doc) {
		return [['script[src]', 'src'], ['link[rel="stylesheet"][href]', 'href']].every(function (pair) {
			function asset(element) { var url = new URL(element.getAttribute(pair[1]), location.href); return element.id + '|' + url.origin + url.pathname + '|' + (url.searchParams.get('ver') || ''); }
			var existing = new Set(Array.from(document.querySelectorAll(pair[0]), asset));
			return Array.from(doc.querySelectorAll(pair[0])).every(function (element) { return existing.has(asset(element)); });
		});
	}
	function replace(selector, incoming) {
		var old = root.querySelector(selector), next = incoming.querySelector(selector);
		if (old && next) { old.replaceWith(document.importNode(next, true)); }
	}
	function update(doc, incoming) {
		// Keep the table and tbody nodes: native WordPress mobile and Quick Edit listeners use them.
		var body = root.querySelector('#the-list'), nextBody = incoming.querySelector('#the-list');
		root.querySelectorAll('thead th:not(.check-column), tfoot th:not(.check-column)').forEach(function (cell, index) { var next = incoming.querySelectorAll('thead th:not(.check-column), tfoot th:not(.check-column)')[index]; if (next) { cell.className = next.className; cell.innerHTML = next.innerHTML; } });
		body.replaceChildren.apply(body, Array.from(nextBody.childNodes, function (node) { return document.importNode(node, true); }));
		Array.from(root.querySelectorAll('.tablenav')).forEach(function (node, index) {
			var next = incoming.querySelectorAll('.tablenav')[index]; if (!next) { return; }
			var bulk = node.querySelector('.bulkactions'), nextBulk = next.querySelector('.bulkactions');
			if (bulk && nextBulk) {
				// WordPress binds the two bulk selectors and buttons directly. Keep those nodes.
				var select = bulk.querySelector('select'), nextSelect = nextBulk.querySelector('select');
				if (select && nextSelect) { select.innerHTML = nextSelect.innerHTML; select.value = '-1'; }
			}
			var page = node.querySelector('#current-page-selector'), nextPage = next.querySelector('#current-page-selector');
			node.replaceChildren.apply(node, Array.from(next.childNodes, function (child) { return document.importNode(child, true); }));
			if (bulk && nextBulk) { node.querySelector('.bulkactions').replaceWith(bulk); }
			if (page && nextPage) { page.value = nextPage.value; page.defaultValue = nextPage.defaultValue; node.querySelector('#current-page-selector').replaceWith(page); }
		});
		if (forms) { replace('.subsubsub', incoming); replace('.search-box', incoming); }
		else {
			var oldFilters = root.querySelector('#af-entry-more-filters'), nextFilters = incoming.querySelector('#af-entry-more-filters');
			if (oldFilters && oldFilters.open && nextFilters) { nextFilters.open = true; }
			replace('.af-list-views', incoming); replace('.af-list-toolbar', incoming); replace('.af-filter-summary', incoming);
			var oldTools = root.querySelector('.af-inbox-tools'), oldName = oldTools && oldTools.querySelector('input[name="name"]');
			var nextTools = incoming.querySelector('.af-inbox-tools'); if (oldTools && oldTools.open && nextTools) { nextTools.open = true; }
			var viewName = oldName ? oldName.value : '';
			replace('.af-inbox-tools', incoming);
			var newName = root.querySelector('.af-inbox-tools input[name="name"]'); if (newName) { newName.value = viewName; }
			root.querySelectorAll(':scope > .notice').forEach(function (node) { node.remove(); });
			var before = root.querySelector('.af-inbox-tools') || root.querySelector('.af-list-views');
			incoming.querySelectorAll(':scope > .notice').forEach(function (node) { var clone = document.importNode(node, true); if (clone.classList.contains('af-bulk-result')) { clone.removeAttribute('role'); } root.insertBefore(clone, before); });
			var oldStatus = listForm.querySelector('input[name="status"]'), newStatus = incoming.querySelector('#af-entries-form input[name="status"]');
			if (oldStatus) { oldStatus.remove(); } if (newStatus) { listForm.prepend(document.importNode(newStatus, true)); }
		}
		var oldNonce = listForm.querySelector('input[name="_wpnonce"]'), newNonce = incoming.querySelector(forms ? '#posts-filter input[name="_wpnonce"]' : '#af-entries-form input[name="_wpnonce"]');
		if (oldNonce && newNonce) { oldNonce.value = newNonce.value; }
		// Attention counts describe the latest server state after read, unread and Trash actions.
		document.querySelectorAll('#menu-posts-accessible_form .wp-menu-name, #menu-posts-accessible_form .wp-submenu a').forEach(function (label) {
			var next = label.classList.contains('wp-menu-name') ? doc.querySelector('#menu-posts-accessible_form .wp-menu-name') : Array.from(doc.querySelectorAll('#menu-posts-accessible_form .wp-submenu a')).find(function (link) { return link.getAttribute('href') === label.getAttribute('href'); });
			if (!next) { return; }
			var badge = label.querySelector('.awaiting-mod'), nextBadge = next.querySelector('.awaiting-mod');
			if (badge) { if (nextBadge) { badge.replaceWith(document.importNode(nextBadge, true)); } else { badge.remove(); } }
			else if (nextBadge) { label.append(document.importNode(nextBadge, true)); }
		});
		document.title = doc.title;
		selection = -1; selected();
		root.querySelectorAll('.toggle-row').forEach(function (button) { button.setAttribute('aria-expanded', 'false'); });
		document.dispatchEvent(new CustomEvent('af:panelready', { detail: { root: root } }));
	}
	async function navigate(url, options) {
		options = options || {};
		if (new URL(url, location.href).origin !== location.origin) { return; }
		if (current && current.mutation) { say(__('Wait for the current action to finish before changing the list.', 'accessible-forms-by-accessible-org')); return; }
		if (current) { current.controller.abort(); clearTimeout(current.timer); }
		var request = { controller: new AbortController(), mutation: !!options.mutation }; current = request;
		var active = document.activeElement, focusId = active && active.id, focusHref = active && root.contains(active) && active.tagName === 'A' ? clean(active.href) : '', scroll = window.scrollY;
		var focusSelector = active && active.matches('.af-filter-chip') ? '.af-filter-chip' : 'a[href]';
		recovery.hidden = true; listForm.setAttribute('aria-busy', 'true');
		say(options.mutation ? __('Updating entries…', 'accessible-forms-by-accessible-org') : __('Loading the list…', 'accessible-forms-by-accessible-org'));
		try {
			request.timer = window.setTimeout(function () { request.controller.abort(); }, 15000);
			var response = await fetch(url, { method: options.method || 'GET', body: options.body, credentials: 'same-origin', cache: 'no-store', signal: request.controller.signal });
			if (!response.ok || !/text\/html/i.test(response.headers.get('content-type') || '')) { throw new Error('response'); }
			var doc = new DOMParser().parseFromString(await response.text(), 'text/html');
			var incoming = doc.querySelector(forms ? 'body.af-forms-list #wpbody-content .wrap' : '.af-entry-list');
			if (!incoming || !incoming.querySelector('#the-list') || incoming.querySelector('script, style, link[rel="stylesheet"]') || !prepared(doc)) { throw new Error('screen'); }
			if (current !== request) { return; }
			update(doc, incoming);
			var destination = clean(response.url);
			if (!options.history && destination !== displayed) { history.pushState({ accessibleFormsList: true }, '', destination); }
			displayed = destination;
			if (options.history) { restore(); }
			else {
				var focus = focusId && document.getElementById(focusId);
				if (!focus && focusHref) { focus = Array.from(root.querySelectorAll(focusSelector)).find(function (link) { return clean(link.href) === focusHref; }); }
				if (focus && root.contains(focus)) { focus.focus({ preventScroll: true }); }
				else if (options.mutation || focusHref) { var summary = root.querySelector('.af-bulk-result button, #af-result-summary'); if (summary) { if (summary.tagName !== 'BUTTON') { summary.tabIndex = -1; } summary.focus({ preventScroll: true }); } }
				window.scrollTo(0, scroll);
			}
			var result = root.querySelector('#af-result-summary'), notice = root.querySelector('.af-bulk-result p');
			say([notice ? notice.textContent : '', result ? result.textContent : __('Forms list updated.', 'accessible-forms-by-accessible-org')].filter(Boolean).join(' '));
			document.documentElement.dataset.afListRevision = String(++sequence);
		} catch (error) {
			if (current !== request) { return; }
			say(request.mutation ? __('The result of this action could not be confirmed. Open the latest list to check its state before trying again.', 'accessible-forms-by-accessible-org') : __('The list could not be loaded. Your current list is kept. Open it as a full page to try again.', 'accessible-forms-by-accessible-org'));
			fullPage.href = request.mutation ? clean(displayed) : clean(url); recovery.hidden = false;
			if (options.history) { history.replaceState(history.state, '', displayed); }
		} finally { clearTimeout(request.timer); if (current === request) { current = null; listForm.removeAttribute('aria-busy'); } }
	}
	root.addEventListener('click', function (event) {
		if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) { return; }
		var link = event.target.closest('.subsubsub a, .tablenav-pages a, .manage-column a, .af-filter-chip, .af-clear-filters, .af-date-shortcuts a, .af-inbox-tools a');
		if (!link || link.target || link.hasAttribute('download') || link.getAttribute('aria-disabled') === 'true') { return; }
		var destination = new URL(link.href, location.href);
		if (destination.origin !== location.origin || destination.pathname !== location.pathname || destination.searchParams.get('page') !== new URL(displayed).searchParams.get('page')) { return; }
		if (root.querySelector('tr.inline-editor')) { return; }
		event.preventDefault(); remember(link); navigate(link.href);
	});
	root.addEventListener('submit', function (event) {
		if (event.defaultPrevented) { return; }
		var form = event.target;
		if (form !== listForm && !form.matches('[data-af-list-action]')) { return; }
		if (root.querySelector('tr.inline-editor')) { return; }
		var button = event.submitter, data = new FormData(form);
		// Native form publishing, trash and Quick Edit retain WordPress's action handling.
		if (forms && button && (button.id === 'doaction' || button.id === 'doaction2')) { return; }
		if (button && button.name) { data.set(button.name, button.value); }
		// Named controls can shadow native form properties (Undo has name="action").
		var method = (form.getAttribute('method') || 'GET').toUpperCase(), mutation = method === 'POST';
		var action = form.getAttribute('action') || location.href;
		if (method === 'GET') {
			mutation = !forms && button && (button.id === 'doaction' || button.id === 'doaction2');
			if (!mutation) {
				['action', 'action2', 'entry[]', '_wpnonce', '_wp_http_referer'].forEach(function (name) { data.delete(name); });
				if (!document.activeElement || document.activeElement.id !== 'current-page-selector') { data.delete('paged'); }
			}
			if (mutation && button.id === 'doaction2') { data.set('action', data.get('action2')); }
			if (mutation && (!data.get('entry[]') || data.get('action') === '-1')) { return; }
		}
		event.preventDefault();
		if (method === 'POST') { navigate(action, { method: method, body: data, mutation: true }); }
		else { var url = new URL(action, location.href); url.search = new URLSearchParams(data).toString(); navigate(url.href, { mutation: mutation }); }
	});
	history.replaceState(Object.assign({}, history.state, { accessibleFormsList: true }), '', displayed);
	window.addEventListener('popstate', function () { if (clean(location.href) !== displayed) { navigate(location.href, { history: true }); } });
})();
