/**
 * Live page check.
 *
 * Loaded only for logged-in people who can edit a form shown on this page
 * (see src/LiveCheck.php). Visitors never receive this file.
 *
 * The plugin renders accessible markup, but a theme, page builder or another
 * plugin can still undo that on the published page: hide the focus outline,
 * shrink checkboxes, lower contrast, cover the submit button with a banner.
 * This script measures the real page after everything has loaded, shows the
 * editor a short notice above each form, and saves a compact result (issue
 * codes and control labels only) to this site's own admin-ajax endpoint.
 * Nothing is sent to any other site.
 *
 * All measurements run before the notice is inserted (or with the notice
 * excluded), and every temporary change is undone: focus, scroll position,
 * the text-spacing class and the transition override.
 */
(function () {
	'use strict';

	var config = window.AccessibleFormsLiveCheck;
	if (!config || !Array.isArray(config.forms) || !config.forms.length) {
		return;
	}

	var i18n = window.wp && window.wp.i18n;
	var __ = i18n
		? i18n.__
		: function (text) {
				return text;
			};
	var _n = i18n
		? i18n._n
		: function (single, plural, count) {
				return 1 === count ? single : plural;
			};
	var sprintf = i18n
		? i18n.sprintf
		: function (format) {
				var args = Array.prototype.slice.call(arguments, 1);
				var index = 0;
				return format.replace(/%(\d+\$)?[sd]/g, function (match, position) {
					if (position) {
						return String(args[parseInt(position, 10) - 1]);
					}
					return String(args[index++]);
				});
			};

	var allowed = config.forms.map(String);
	var NOTICE_CLASS = 'af-live-check';
	var CONTROL_SELECTOR = 'input:not([type="hidden"]), select, textarea, button';
	var TEXT_SELECTOR =
		'.af-heading, .af-section-heading, .af-label, .af-legend, .af-choice__label, .af-help, .af-error, .af-req, .af-submit';
	var counter = 0;

	/* ------------------------------------------------------------------ */
	/* Small helpers                                                       */
	/* ------------------------------------------------------------------ */

	function frame() {
		return new Promise(function (resolve) {
			window.requestAnimationFrame(function () {
				window.requestAnimationFrame(resolve);
			});
		});
	}

	function wait(ms) {
		return new Promise(function (resolve) {
			window.setTimeout(resolve, ms);
		});
	}

	function clean(text) {
		return String(text || '')
			.replace(/\s+/g, ' ')
			.trim();
	}

	/** Comparable form of a name: lower case letters and digits only. */
	function comparable(text) {
		return clean(text)
			.toLowerCase()
			.replace(/[^\p{L}\p{N}]+/gu, ' ')
			.trim();
	}

	function short(text) {
		text = clean(text);
		return text.length > 60 ? text.slice(0, 57) + '…' : text;
	}

	function style(el, pseudo) {
		return window.getComputedStyle(el, pseudo || null);
	}

	/** Text a person can see: skips display:none, visibility:hidden and .af-req. */
	function visibleText(node, skipRequired) {
		var out = '';
		node.childNodes.forEach(function (child) {
			if (3 === child.nodeType) {
				out += child.nodeValue;
				return;
			}
			if (1 !== child.nodeType) {
				return;
			}
			if (skipRequired && child.classList.contains('af-req')) {
				return;
			}
			var cs = style(child);
			if ('none' === cs.display || 'visible' !== cs.visibility) {
				return;
			}
			out += visibleText(child, skipRequired);
		});
		return clean(out);
	}

	/** Text used for the accessible name: skips hidden and aria-hidden nodes. */
	function nameText(node) {
		var out = '';
		node.childNodes.forEach(function (child) {
			if (3 === child.nodeType) {
				out += child.nodeValue;
				return;
			}
			if (1 !== child.nodeType || 'true' === child.getAttribute('aria-hidden')) {
				return;
			}
			var cs = style(child);
			if ('none' === cs.display || 'hidden' === cs.visibility) {
				return;
			}
			if (child.matches('input, select, textarea')) {
				return;
			}
			out += ' ' + nameText(child) + ' ';
		});
		return clean(out);
	}

	/** Plain-text label of an element, without the "(required)" hint. */
	function plainLabel(el) {
		if (!el) {
			return '';
		}
		var copy = el.cloneNode(true);
		copy.querySelectorAll('.af-req').forEach(function (req) {
			req.remove();
		});
		return clean(copy.textContent);
	}

	function describe(el) {
		if (!el || 1 !== el.nodeType) {
			return '';
		}
		var text = el.tagName.toLowerCase();
		if (el.id) {
			text += '#' + el.id;
		} else if ('string' === typeof el.className && clean(el.className)) {
			text += '.' + clean(el.className).split(' ')[0];
		}
		return text;
	}

	/* ------------------------------------------------------------------ */
	/* Colour                                                              */
	/* ------------------------------------------------------------------ */

	var canvasContext = null;

	/** Parse any computed CSS colour into sRGB 0-255 plus alpha 0-1. */
	function parseColor(value) {
		value = clean(value);
		if (!value) {
			return null;
		}
		if ('transparent' === value) {
			return { r: 0, g: 0, b: 0, a: 0 };
		}
		var match = /^rgba?\(\s*([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:\s*[,/]\s*([\d.]+)(%?))?\s*\)$/.exec(value);
		if (match) {
			var alpha = undefined === match[4] ? 1 : parseFloat(match[4]);
			if ('%' === match[5]) {
				alpha = alpha / 100;
			}
			return { r: +match[1], g: +match[2], b: +match[3], a: alpha };
		}
		// Other colour spaces (color(), oklch() …): let the browser convert to sRGB.
		try {
			if (!canvasContext) {
				var canvas = document.createElement('canvas');
				canvas.width = 1;
				canvas.height = 1;
				canvasContext = canvas.getContext('2d', { willReadFrequently: true });
			}
			canvasContext.clearRect(0, 0, 1, 1);
			canvasContext.fillStyle = '#000';
			canvasContext.fillStyle = value;
			canvasContext.fillRect(0, 0, 1, 1);
			var data = canvasContext.getImageData(0, 0, 1, 1).data;
			return { r: data[0], g: data[1], b: data[2], a: data[3] / 255 };
		} catch (e) {
			return null;
		}
	}

	/** Paint a translucent colour over an opaque one. */
	function blend(top, bottom) {
		var a = top.a;
		return {
			r: top.r * a + bottom.r * (1 - a),
			g: top.g * a + bottom.g * (1 - a),
			b: top.b * a + bottom.b * (1 - a),
			a: 1,
		};
	}

	function luminance(c) {
		var channels = [c.r, c.g, c.b].map(function (v) {
			v = v / 255;
			return v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
		});
		return 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
	}

	function contrast(a, b) {
		var l1 = luminance(a);
		var l2 = luminance(b);
		return (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
	}

	function ratio(value) {
		return (Math.floor(value * 10) / 10).toFixed(1);
	}

	/**
	 * The colour behind an element: the first opaque ancestor background,
	 * with any translucent layers above it blended in. A background image or
	 * gradient on the way makes the answer unknowable, so it is reported as
	 * "could not verify" rather than guessed.
	 */
	function backgroundOf(el) {
		var layers = [];
		for (var node = el; node && 1 === node.nodeType; node = node.parentElement) {
			var cs = style(node);
			if (cs.backgroundImage && 'none' !== cs.backgroundImage) {
				return { unknown: true };
			}
			var color = parseColor(cs.backgroundColor);
			if (!color) {
				return { unknown: true };
			}
			if (color.a > 0) {
				layers.push(color);
				if (color.a >= 1) {
					break;
				}
			}
		}
		var base = { r: 255, g: 255, b: 255, a: 1 };
		if (layers.length && layers[layers.length - 1].a >= 1) {
			base = layers.pop();
		}
		for (var i = layers.length - 1; i >= 0; i--) {
			base = blend(layers[i], base);
		}
		return { color: base };
	}

	function opacityOf(el) {
		var value = 1;
		for (var node = el; node && 1 === node.nodeType; node = node.parentElement) {
			value *= parseFloat(style(node).opacity) || 0;
		}
		return value;
	}

	/* ------------------------------------------------------------------ */
	/* Visibility                                                          */
	/* ------------------------------------------------------------------ */

	function isRendered(el) {
		if (!el || !el.isConnected) {
			return false;
		}
		if (el.checkVisibility) {
			return el.checkVisibility({ checkVisibilityCSS: true, visibilityProperty: true });
		}
		var cs = style(el);
		return 'none' !== cs.display && 'visible' === cs.visibility && el.getClientRects().length > 0;
	}

	/** The box of an element's text, which catches text-indent tricks. */
	function textRect(el) {
		var range = document.createRange();
		range.selectNodeContents(el);
		var rect = range.getBoundingClientRect();
		if (rect.width || rect.height) {
			return rect;
		}
		return el.getBoundingClientRect();
	}

	/**
	 * Why a person cannot see this text, or '' when they can.
	 * Covering by other elements is checked later, while scrolling.
	 */
	function hiddenReason(el) {
		if (!isRendered(el)) {
			return 'hidden';
		}
		var cs = style(el);
		if (opacityOf(el) < 0.1) {
			return 'transparent';
		}
		var color = parseColor(cs.color);
		if (color && color.a < 0.1) {
			return 'transparent';
		}
		var box = el.getBoundingClientRect();
		var rect = textRect(el);
		if (box.width < 2 || box.height < 2 || rect.width < 2 || rect.height < 2) {
			return 'tiny';
		}
		for (var node = el; node && node !== document.body; node = node.parentElement) {
			var ncs = style(node);
			if (('absolute' === ncs.position || 'fixed' === ncs.position) && ncs.clip && 'auto' !== ncs.clip) {
				return 'clipped';
			}
			if (ncs.clipPath && 'none' !== ncs.clipPath) {
				return 'clipped';
			}
			if (node !== el && /hidden|clip/.test(ncs.overflowX + ncs.overflowY)) {
				var outer = node.getBoundingClientRect();
				if (
					rect.right <= outer.left ||
					rect.left >= outer.right ||
					rect.bottom <= outer.top ||
					rect.top >= outer.bottom
				) {
					return 'clipped';
				}
			}
		}
		var docWidth = document.documentElement.scrollWidth;
		if (
			rect.right + window.scrollX <= 0 ||
			rect.bottom + window.scrollY <= 0 ||
			rect.left + window.scrollX >= docWidth
		) {
			return 'offscreen';
		}
		if (parseFloat(cs.fontSize) < 12) {
			return 'small';
		}
		return '';
	}

	function reasonText(reason, el) {
		switch (reason) {
			case 'hidden':
				return __('it is hidden', 'accessible-forms-by-accessible-org');
			case 'transparent':
				return __('it is transparent', 'accessible-forms-by-accessible-org');
			case 'tiny':
				return __('it has almost no size', 'accessible-forms-by-accessible-org');
			case 'clipped':
				return __('it is clipped out of view', 'accessible-forms-by-accessible-org');
			case 'offscreen':
				return __('it is moved off the screen', 'accessible-forms-by-accessible-org');
			case 'small':
				return sprintf(
					/* translators: %s: font size in pixels. */
					__('its text is only %spx', 'accessible-forms-by-accessible-org'),
					Math.round(parseFloat(style(el).fontSize) * 10) / 10
				);
			case 'covered':
				return __('another element covers it', 'accessible-forms-by-accessible-org');
		}
		return '';
	}

	/* ------------------------------------------------------------------ */
	/* Form model                                                          */
	/* ------------------------------------------------------------------ */

	function isChoice(el) {
		return el.matches('input[type="checkbox"], input[type="radio"]');
	}

	/** Controls a visitor can see and use, excluding third-party widgets. */
	function controlsOf(wrap) {
		return Array.from(wrap.querySelectorAll(CONTROL_SELECTOR)).filter(function (el) {
			if (el.closest('.af-turnstile, accessible-forms-altcha, [hidden]')) {
				return false;
			}
			if (el.disabled || 'af_hp' === el.name) {
				return false;
			}
			if (isChoice(el)) {
				var label = el.labels && el.labels[0];
				return isRendered(el) || (label && isRendered(label));
			}
			return isRendered(el);
		});
	}

	/** The visible label element of a control, if it has one. */
	function labelElement(el) {
		if ('BUTTON' === el.tagName) {
			return el;
		}
		if (el.labels && el.labels.length) {
			return el.labels[0];
		}
		return null;
	}

	function fieldLabel(el) {
		var box = el.closest('.af-field-container');
		if (!box) {
			return '';
		}
		var main = box.querySelector('.af-label, .af-legend');
		if (main) {
			return plainLabel(main);
		}
		var consent = box.querySelector('.af-choice__label');
		return consent ? plainLabel(consent) : '';
	}

	/** Words used for a control in the notice and the stored result. */
	function controlName(el) {
		if ('BUTTON' === el.tagName) {
			return short(plainLabel(el));
		}
		var own = plainLabel(labelElement(el));
		if (isChoice(el) && el.closest('fieldset')) {
			var group = fieldLabel(el);
			return short(group ? group + ': ' + own : own);
		}
		return short(own || fieldLabel(el) || el.name || el.id);
	}

	/** Group key so choice options of one question merge into one problem. */
	function groupOf(el) {
		if (isChoice(el) && el.closest('fieldset')) {
			var box = el.closest('.af-field-container');
			return box ? 'field:' + box.getAttribute('data-field') : '';
		}
		return '';
	}

	/** A simplified accessible name computation for form controls. */
	function accessibleName(el) {
		var labelledby = clean(el.getAttribute('aria-labelledby'));
		if (labelledby) {
			return clean(
				labelledby
					.split(' ')
					.map(function (id) {
						var target = document.getElementById(id);
						return target ? clean(target.textContent) : '';
					})
					.join(' ')
			);
		}
		var aria = clean(el.getAttribute('aria-label'));
		if (aria) {
			return aria;
		}
		if ('BUTTON' === el.tagName) {
			return nameText(el) || clean(el.getAttribute('title'));
		}
		if (el.labels && el.labels.length) {
			var text = Array.from(el.labels)
				.map(function (label) {
					return nameText(label);
				})
				.join(' ');
			if (clean(text)) {
				return clean(text);
			}
		}
		return clean(el.getAttribute('title') || el.getAttribute('placeholder'));
	}

	function ariaHidden(el) {
		for (var node = el; node && 1 === node.nodeType; node = node.parentElement) {
			if ('true' === node.getAttribute('aria-hidden')) {
				return true;
			}
		}
		return false;
	}

	/* ------------------------------------------------------------------ */
	/* Checks                                                              */
	/* ------------------------------------------------------------------ */

	function Result() {
		this.issues = [];
		this.unverified = [];
	}
	Result.prototype.add = function (code, label, detail, group) {
		this.issues.push({ code: code, label: label || '', detail: detail || {}, group: group || '' });
	};
	Result.prototype.later = function (code, label, detail) {
		this.unverified.push({ code: code, label: label || '', detail: detail || {} });
	};

	/** Names and visible labels (WCAG 1.3.1, 2.5.3, 4.1.2). */
	function checkNames(wrap, controls, result) {
		controls.forEach(function (el) {
			var name = controlName(el);
			var group = groupOf(el);
			if (ariaHidden(el)) {
				result.add('name_missing', name, { reason: 'aria-hidden' }, group);
				return;
			}
			var accessible = accessibleName(el);
			if (!accessible) {
				result.add('name_missing', name, {}, group);
				return;
			}
			var label = labelElement(el);
			if (!label) {
				return;
			}
			var visible = visibleText(label, false);
			if (visible && -1 === (' ' + comparable(accessible) + ' ').indexOf(' ' + comparable(visible) + ' ')) {
				result.add('name_mismatch', name, { name: short(accessible), visible: short(visible) }, group);
			}
			if (label === el) {
				return;
			}
			var reason = hiddenReason(label);
			if (reason) {
				result.add('label_hidden', name, { reason: reason, why: reasonText(reason, label) }, group);
			}
		});
		// Group labels (legends) must be visible too.
		wrap.querySelectorAll('.af-legend').forEach(function (legend) {
			var fieldset = legend.closest('fieldset');
			if (!fieldset || !isRendered(fieldset) || fieldset.closest('[hidden]')) {
				return;
			}
			var reason = hiddenReason(legend);
			if (reason) {
				result.add('label_hidden', short(plainLabel(legend)), { reason: reason, why: reasonText(reason, legend) });
			}
		});
	}

	/** Required markers, references, duplicate IDs, injected tags, heading. */
	function checkStructure(wrap, controls, result) {
		var seenRequired = {};
		controls.forEach(function (el) {
			if (!el.required) {
				return;
			}
			var box = el.closest('.af-field-container');
			var key = box ? box.getAttribute('data-field') : el.id;
			if (seenRequired[key]) {
				return;
			}
			seenRequired[key] = true;
			var holder =
				(box && box.querySelector('.af-legend')) ||
				(el.labels && el.labels[0]) ||
				(box && box.querySelector('.af-label'));
			var marker = holder ? holder.querySelector('.af-req') : null;
			if (!marker || hiddenReason(marker)) {
				result.add('required_marker', short(fieldLabel(el) || controlName(el)));
			}
		});

		var references = [];
		wrap.querySelectorAll('[aria-describedby], [aria-labelledby], label[for]').forEach(function (el) {
			['aria-describedby', 'aria-labelledby', 'for'].forEach(function (attribute) {
				clean(el.getAttribute(attribute))
					.split(' ')
					.filter(Boolean)
					.forEach(function (id) {
						if (!document.getElementById(id)) {
							references.push({ el: el, id: id });
						}
					});
			});
		});
		references.forEach(function (item) {
			var control = item.el.matches('label') ? null : item.el;
			var name = control && control.matches(CONTROL_SELECTOR) ? controlName(control) : short(item.el.textContent);
			result.add('ref_missing', name, { id: item.id });
		});

		var seen = {};
		wrap.querySelectorAll('[id]').forEach(function (el) {
			var id = el.id;
			if (seen[id]) {
				return;
			}
			seen[id] = true;
			var escaped = window.CSS && CSS.escape ? CSS.escape(id) : id.replace(/"/g, '\\"');
			if (document.querySelectorAll('[id="' + escaped + '"]').length > 1) {
				result.add('duplicate_id', id, { id: id });
			}
		});

		var injected = Array.from(wrap.querySelectorAll('br, p:not([class])')).filter(function (el) {
			return !el.closest('.af-save-progress, noscript, .af-summary, dl, .' + NOTICE_CLASS);
		});
		if (injected.length) {
			result.add('injected_markup', '', { count: injected.length });
		}

		var form = wrap.querySelector('form.af-form');
		if (form && !form.hidden) {
			var headingId = clean(form.getAttribute('aria-labelledby'));
			if (headingId) {
				var heading = document.getElementById(headingId.split(' ')[0]);
				var why = heading ? hiddenReason(heading) : 'hidden';
				if (!heading || why) {
					result.add('heading_missing', heading ? short(heading.textContent) : '', { why: reasonText(why, heading) });
				}
			} else if (!clean(form.getAttribute('aria-label'))) {
				result.add('heading_missing', '', {});
			}
		}
	}

	/** Text contrast (1.4.3) and field boundaries (1.4.11). */
	function checkContrast(wrap, controls, result) {
		wrap.querySelectorAll(TEXT_SELECTOR).forEach(function (el) {
			if (el.closest('[hidden]') || hiddenReason(el)) {
				return;
			}
			var hasText = Array.from(el.childNodes).some(function (child) {
				return 3 === child.nodeType && clean(child.nodeValue);
			});
			if (!hasText) {
				return;
			}
			var cs = style(el);
			var color = parseColor(cs.color);
			var back = backgroundOf(el);
			var label = textLabel(el);
			if (!color || back.unknown) {
				result.later('contrast_text', label, {});
				return;
			}
			var opacity = opacityOf(el);
			var fg = blend({ r: color.r, g: color.g, b: color.b, a: color.a * opacity }, back.color);
			var size = parseFloat(cs.fontSize);
			var weight = parseInt(cs.fontWeight, 10) || 400;
			var large = size >= 24 || (size >= 18.66 && weight >= 700);
			var needed = large ? 3 : 4.5;
			var value = contrast(fg, back.color);
			if (value < needed) {
				var group = el.matches('.af-choice__label') && el.control ? groupOf(el.control) : '';
				result.add('contrast_text', label, { ratio: ratio(value), needed: needed }, group);
			}
		});

		controls.forEach(function (el) {
			if ('BUTTON' === el.tagName) {
				return;
			}
			var cs = style(el);
			if (isChoice(el) && 'none' !== cs.appearance && 'none' !== cs.webkitAppearance) {
				return; // Native checkboxes and radios are drawn by the browser.
			}
			if (!isRendered(el)) {
				return;
			}
			var outside = backgroundOf(el.parentElement);
			var name = controlName(el);
			if (outside.unknown) {
				result.later('contrast_border', name, {});
				return;
			}
			var best = 0;
			['Top', 'Right', 'Bottom', 'Left'].forEach(function (side) {
				var width = parseFloat(cs['border' + side + 'Width']) || 0;
				var borderColor = parseColor(cs['border' + side + 'Color']);
				if (width >= 1 && 'none' !== cs['border' + side + 'Style'] && borderColor && borderColor.a > 0) {
					best = Math.max(best, contrast(blend(borderColor, outside.color), outside.color));
				}
			});
			var own = backgroundOf(el);
			if (!own.unknown) {
				best = Math.max(best, contrast(own.color, outside.color));
			}
			if (best < 3) {
				if (!best && cs.boxShadow && 'none' !== cs.boxShadow) {
					result.later('contrast_border', name, {});
					return;
				}
				result.add('contrast_border', name, { ratio: ratio(best) }, groupOf(el));
			}
		});
	}

	function textLabel(el) {
		if (el.matches('.af-submit')) {
			return short(plainLabel(el));
		}
		if (el.matches('.af-heading, .af-section-heading')) {
			return short(el.textContent);
		}
		var field = fieldLabel(el);
		if (el.matches('.af-help')) {
			return field
				? sprintf(
						/* translators: %s: field label. */
						__('help text for %s', 'accessible-forms-by-accessible-org'),
						field
					)
				: __('help text', 'accessible-forms-by-accessible-org');
		}
		if (el.matches('.af-error')) {
			return sprintf(
				/* translators: %s: field label. */
				__('error message for %s', 'accessible-forms-by-accessible-org'),
				field
			);
		}
		if (el.matches('.af-req')) {
			return sprintf(
				/* translators: %s: field label. */
				__('"(required)" for %s', 'accessible-forms-by-accessible-org'),
				field
			);
		}
		if (el.matches('.af-choice__label')) {
			var input = el.control;
			return input ? controlName(input) : short(plainLabel(el));
		}
		return short(plainLabel(el));
	}

	/** Target size (2.5.8): 24 by 24 CSS pixels, or enough spacing. */
	function checkTargets(controls, result) {
		var targets = controls.map(function (el) {
			var rect = el.getBoundingClientRect();
			var box = { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom };
			if (isChoice(el)) {
				// The label is part of the click target.
				Array.from(el.labels || []).forEach(function (label) {
					if (!isRendered(label)) {
						return;
					}
					var lr = label.getBoundingClientRect();
					box.left = Math.min(box.left, lr.left);
					box.top = Math.min(box.top, lr.top);
					box.right = Math.max(box.right, lr.right);
					box.bottom = Math.max(box.bottom, lr.bottom);
				});
			}
			box.width = box.right - box.left;
			box.height = box.bottom - box.top;
			box.cx = box.left + box.width / 2;
			box.cy = box.top + box.height / 2;
			return { el: el, box: box };
		});

		function rectMeetsCircle(box, cx, cy) {
			var nx = Math.max(box.left, Math.min(cx, box.right));
			var ny = Math.max(box.top, Math.min(cy, box.bottom));
			return Math.hypot(nx - cx, ny - cy) < 12;
		}

		targets.forEach(function (target) {
			var box = target.box;
			if (box.width >= 23.5 && box.height >= 23.5) {
				return;
			}
			// Spacing exception: a 24px circle on the target must not touch another target.
			var crowded = targets.some(function (other) {
				if (other === target) {
					return false;
				}
				var small = other.box.width < 23.5 || other.box.height < 23.5;
				if (small && Math.hypot(other.box.cx - box.cx, other.box.cy - box.cy) < 24) {
					return true;
				}
				return rectMeetsCircle(other.box, box.cx, box.cy);
			});
			if (crowded) {
				result.add(
					'target_small',
					controlName(target.el),
					{ width: Math.round(box.width), height: Math.round(box.height) },
					groupOf(target.el)
				);
			}
		});
	}

	var FOCUS_PROPS = [
		'outlineStyle',
		'outlineWidth',
		'outlineColor',
		'outlineOffset',
		'boxShadow',
		'borderTopColor',
		'borderRightColor',
		'borderBottomColor',
		'borderLeftColor',
		'borderTopWidth',
		'borderRightWidth',
		'borderBottomWidth',
		'borderLeftWidth',
		'backgroundColor',
		'color',
		'textDecorationLine',
	];

	function focusParts(el) {
		var parts = [el];
		if (isChoice(el)) {
			Array.from(el.labels || []).forEach(function (label) {
				parts.push(label);
			});
			var choice = el.closest('.af-choice');
			if (choice) {
				parts.push(choice);
			}
		}
		return parts;
	}

	function focusSnapshot(el) {
		var snap = [];
		focusParts(el).forEach(function (part) {
			[null, '::before', '::after'].forEach(function (pseudo) {
				var cs = style(part, pseudo);
				var values = {};
				FOCUS_PROPS.forEach(function (prop) {
					values[prop] = cs[prop];
				});
				values.content = cs.content;
				snap.push({ part: part, pseudo: pseudo, values: values });
			});
		});
		return snap;
	}

	function shadowVisible(value) {
		if (!value || 'none' === value) {
			return false;
		}
		var colors = value.match(/rgba?\([^)]*\)|color\([^)]*\)|oklch\([^)]*\)|#[0-9a-f]{3,8}/gi) || [];
		if (!colors.length) {
			return true;
		}
		return colors.some(function (c) {
			var parsed = parseColor(c);
			return !parsed || parsed.a > 0.1;
		});
	}

	/**
	 * Compare before/after focus styles. Returns
	 * { visible: bool, outlineOnly: bool, outline: {color, offset, part} }.
	 */
	function focusDifference(before, after) {
		var visible = false;
		var other = false;
		var outline = null;
		for (var i = 0; i < before.length; i++) {
			var a = before[i].values;
			var b = after[i].values;
			if ('none' === b.content && null !== before[i].pseudo && 'none' === a.content) {
				continue; // A pseudo-element that does not exist either way.
			}
			var outlineShown =
				'none' !== b.outlineStyle && parseFloat(b.outlineWidth) >= 1 && (parseColor(b.outlineColor) || { a: 1 }).a > 0.1;
			var outlineChanged =
				a.outlineStyle !== b.outlineStyle || a.outlineWidth !== b.outlineWidth || a.outlineColor !== b.outlineColor;
			if (outlineShown && outlineChanged) {
				visible = true;
				if (!outline) {
					outline = { color: b.outlineColor, offset: parseFloat(b.outlineOffset) || 0, part: before[i].part };
				}
			}
			if (a.boxShadow !== b.boxShadow && (shadowVisible(b.boxShadow) || shadowVisible(a.boxShadow))) {
				visible = true;
				other = true;
			}
			['Top', 'Right', 'Bottom', 'Left'].forEach(function (side) {
				var wa = parseFloat(a['border' + side + 'Width']) || 0;
				var wb = parseFloat(b['border' + side + 'Width']) || 0;
				if (Math.abs(wa - wb) >= 1) {
					visible = true;
					other = true;
				}
				var ca = parseColor(a['border' + side + 'Color']);
				var cb = parseColor(b['border' + side + 'Color']);
				if (wb >= 1 && ca && cb && contrast(blend(ca, WHITE), blend(cb, WHITE)) >= 1.3) {
					visible = true;
					other = true;
				}
			});
			var ba = parseColor(a.backgroundColor);
			var bb = parseColor(b.backgroundColor);
			if (ba && bb && contrast(blend(ba, WHITE), blend(bb, WHITE)) >= 1.3) {
				visible = true;
				other = true;
			}
			if (a.color !== b.color || a.textDecorationLine !== b.textDecorationLine) {
				var fa = parseColor(a.color);
				var fb = parseColor(b.color);
				if (a.textDecorationLine !== b.textDecorationLine || (fa && fb && contrast(blend(fa, WHITE), blend(fb, WHITE)) >= 1.3)) {
					visible = true;
					other = true;
				}
			}
			if (a.content !== b.content) {
				visible = true;
				other = true;
			}
		}
		return { visible: visible, outlineOnly: visible && !other, outline: outline };
	}

	var WHITE = { r: 255, g: 255, b: 255, a: 1 };

	/**
	 * Focus indicators (2.4.7). Each control is focused the way a keyboard
	 * user would focus it: focus({ focusVisible: true }) where supported, and
	 * otherwise the browser's :focus-visible heuristic, primed by first
	 * focusing a text field (text fields always match :focus-visible, and
	 * browsers keep showing focus rings when script moves focus onwards from
	 * an element that showed one). If a control still does not match
	 * :focus-visible, it is listed as "could not verify" rather than flagged.
	 */
	function checkFocus(controls, result) {
		var primer = document.createElement('input');
		primer.type = 'text';
		primer.setAttribute('aria-hidden', 'true');
		primer.tabIndex = -1;
		primer.className = 'af-live-check__primer';
		document.body.appendChild(primer);
		primer.focus({ preventScroll: true });

		controls.forEach(function (el) {
			if (!isRendered(el) && !(isChoice(el) && el.labels && el.labels[0])) {
				return;
			}
			primer.focus({ preventScroll: true });
			var before = focusSnapshot(el);
			try {
				el.focus({ preventScroll: true, focusVisible: true });
			} catch (e) {
				el.focus();
			}
			var name = controlName(el);
			if (document.activeElement !== el) {
				result.later('focus_none', name, {});
				return;
			}
			var matches = true;
			try {
				matches = el.matches(':focus-visible');
			} catch (e) {
				matches = true;
			}
			if (!matches) {
				result.later('focus_none', name, {});
				return;
			}
			var after = focusSnapshot(el);
			var diff = focusDifference(before, after);
			if (!diff.visible) {
				result.add('focus_none', name, {}, groupOf(el));
				return;
			}
			if (diff.outlineOnly && diff.outline) {
				var host = diff.outline.offset >= 0 ? diff.outline.part.parentElement : diff.outline.part;
				var back = backgroundOf(host);
				var ring = parseColor(diff.outline.color);
				if (!back.unknown && ring) {
					var value = contrast(blend(ring, back.color), back.color);
					if (value < 3) {
						result.add('focus_low_contrast', name, { ratio: ratio(value) }, groupOf(el));
					}
				}
			}
		});
		primer.blur();
		primer.remove();
	}

	/** Elements whose text box clips its content. */
	function clippedTexts(wrap) {
		var found = [];
		wrap.querySelectorAll(TEXT_SELECTOR).forEach(function (el) {
			// Text that is already hidden on purpose is reported as hidden, not clipped.
			if (el.closest('[hidden]') || hiddenReason(el)) {
				return;
			}
			for (var node = el; node && node !== wrap.parentElement; node = node.parentElement) {
				var cs = style(node);
				var clipsY = /hidden|clip/.test(cs.overflowY);
				var clipsX = /hidden|clip/.test(cs.overflowX);
				if (
					(clipsY && node.scrollHeight > node.clientHeight + 1) ||
					(clipsX && node.scrollWidth > node.clientWidth + 1)
				) {
					if (node === el || node.contains(el)) {
						// Only when the element itself sticks out of the clipping box.
						var inner = el.getBoundingClientRect();
						var outer = node.getBoundingClientRect();
						if (
							node === el ||
							inner.bottom > outer.bottom + 1 ||
							inner.right > outer.right + 1 ||
							inner.top < outer.top - 1
						) {
							found.push(el);
							break;
						}
					}
				}
			}
		});
		return found;
	}

	/** Text spacing (1.4.12) and a quick reflow check. */
	function checkSpacing(wrap, result) {
		var before = clippedTexts(wrap);
		var overflowBefore = wrap.scrollWidth > wrap.clientWidth + 1;
		before.forEach(function (el) {
			result.add('text_clipped', textLabel(el));
		});
		wrap.classList.add('af-live-spacing');
		try {
			clippedTexts(wrap).forEach(function (el) {
				if (-1 === before.indexOf(el)) {
					result.add('spacing_clip', textLabel(el));
				}
			});
			if (!overflowBefore && wrap.scrollWidth > wrap.clientWidth + 1) {
				result.add('form_overflow', '');
			}
		} finally {
			wrap.classList.remove('af-live-spacing');
		}
	}

	/** Whether a point shows the element (or something that belongs to it). */
	function pointShows(x, y, el, owner) {
		if (x < 0 || y < 0 || x >= window.innerWidth || y >= window.innerHeight) {
			return { ok: true };
		}
		var hit = document.elementFromPoint(x, y);
		if (!hit) {
			return { ok: true };
		}
		if (hit === el || el.contains(hit) || owner.contains(hit) || hit.contains(owner) || hit.closest('.' + NOTICE_CLASS)) {
			return { ok: true };
		}
		if (el.labels && Array.from(el.labels).some(function (label) {
			return label.contains(hit);
		})) {
			return { ok: true };
		}
		return { ok: false, by: hit };
	}

	function samplePoints(rect) {
		var points = [[rect.left + rect.width / 2, rect.top + rect.height / 2]];
		[0.2, 0.8].forEach(function (fx) {
			[0.2, 0.8].forEach(function (fy) {
				points.push([rect.left + rect.width * fx, rect.top + rect.height * fy]);
			});
		});
		return points;
	}

	function scrollTo(el, block) {
		try {
			el.scrollIntoView({ block: block, inline: 'nearest', behavior: 'instant' });
		} catch (e) {
			el.scrollIntoView('start' === block);
		}
	}

	/**
	 * Covered labels and obscured controls (2.4.11). Active controls are
	 * scrolled to the top, middle and bottom of the window,
	 * where a sticky header, a cookie banner or a chat button usually sits,
	 * and hit-tested. A control counts as obscured only when every sample
	 * point is covered (the AA "entirely hidden" rule).
	 */
	async function checkCovered(wrap, controls, result, interrupted) {
		var deadline = performance.now() + 8000;
		function stop() {
			if (interrupted()) { return true; }
			if (performance.now() > deadline) { result.later('obscured', '', { reason: 'budget' }); return true; }
			return false;
		}
		var labels = [];
		controls.forEach(function (el) {
			var label = labelElement(el);
			if (label && label !== el && !hiddenReason(label) && -1 === labels.indexOf(label)) {
				labels.push(label);
			}
		});
		for (var i = 0; i < labels.length; i++) {
			if (stop()) { return; }
			var label = labels[i];
			scrollTo(label, 'center');
			await frame();
			var rect = textRect(label);
			var owner = label.closest('.af-field-container') || label.parentElement;
			var hit = pointShows(rect.left + rect.width / 2, rect.top + rect.height / 2, label, owner);
			if (!hit.ok) {
				var control = label.control;
				result.add(
					'label_hidden',
					control ? controlName(control) : short(plainLabel(label)),
					{ reason: 'covered', why: reasonText('covered'), by: describe(hit.by) },
					control ? groupOf(control) : ''
				);
			}
		}

		var targets = controls.filter(function (el) { return !el.disabled && !hiddenReason(el); });
		for (var t = 0; t < targets.length; t++) {
			var el = targets[t];
			var place = isChoice(el) && el.labels && el.labels[0] ? el.labels[0] : el;
			var owner2 = el.closest('.af-field-container, .af-actions') || el.parentElement;
			var positions = ['center', 'start', 'end'];
			for (var p = 0; p < positions.length; p++) {
				if (stop()) { return; }
				scrollTo(place, positions[p]);
				await frame();
				var box = place.getBoundingClientRect();
				var misses = samplePoints(box).map(function (point) {
					return pointShows(point[0], point[1], el, owner2);
				});
				var covered = misses.filter(function (m) {
					return !m.ok;
				});
				if (covered.length === misses.length) {
					result.add('obscured', controlName(el), { position: positions[p], by: describe(covered[0].by) });
					break;
				}
			}
		}
	}

	/* ------------------------------------------------------------------ */
	/* Running                                                             */
	/* ------------------------------------------------------------------ */

	/** Merge repeated problems for one question (for example every option). */
	function merge(issues) {
		var out = [];
		var index = {};
		issues.forEach(function (issue) {
			var key = issue.group ? issue.code + '|' + issue.group : '';
			if (key && index[key] !== undefined) {
				out[index[key]].count++;
				return;
			}
			var copy = Object.assign({ count: 1 }, issue);
			if (key) {
				var parts = issue.label.split(': ');
				copy.label = parts.length > 1 ? parts.slice(0, -1).join(': ') : issue.label;
				index[key] = out.length;
			}
			out.push(copy);
		});
		// Exact duplicates (same code and label) add nothing.
		var seen = {};
		return out.filter(function (issue) {
			var key = issue.code + '|' + issue.label + '|' + (issue.detail.id || '');
			if (seen[key]) {
				return false;
			}
			seen[key] = true;
			return true;
		});
	}

	/** Problems that block people most come first. */
	var PRIORITY = [
		'obscured',
		'focus_none',
		'name_missing',
		'label_hidden',
		'name_mismatch',
		'contrast_text',
		'focus_low_contrast',
		'contrast_border',
		'target_small',
		'spacing_clip',
		'text_clipped',
		'form_overflow',
		'required_marker',
		'heading_missing',
		'ref_missing',
		'duplicate_id',
		'injected_markup',
	];

	function byPriority(issues) {
		return issues
			.map(function (issue, index) {
				return { issue: issue, index: index };
			})
			.sort(function (a, b) {
				return PRIORITY.indexOf(a.issue.code) - PRIORITY.indexOf(b.issue.code) || a.index - b.index;
			})
			.map(function (item) {
				return item.issue;
			});
	}

	async function checkWrap(wrap) {
		var result = new Result();
		var controls = controlsOf(wrap);
		var form = wrap.querySelector('form.af-form');
		if (!form || form.hidden) {
			return { issues: [], unverified: [], skipped: true };
		}
		var active = document.activeElement;
		var scrollX = window.scrollX;
		var scrollY = window.scrollY;
		// The page (or the person) may move focus while the check waits for frames,
		// for example to an error summary after a submit. Never undo that.
		var ownFocus = false;
		var focusMovedElsewhere = false;
		function noteFocus() {
			if (!ownFocus) {
				focusMovedElsewhere = true;
			}
		}
		document.addEventListener('focusin', noteFocus, true);
		function noteInteraction() { focusMovedElsewhere = true; }
		['keydown', 'pointermove', 'pointerdown', 'wheel', 'touchstart', 'af:statechange'].forEach(function (name) { document.addEventListener(name, noteInteraction, { capture: true, passive: true }); });
		wrap.classList.add('af-live-checking');
		try {
			checkStructure(wrap, controls, result);
			checkNames(wrap, controls, result);
			checkContrast(wrap, controls, result);
			checkTargets(controls, result);
			checkSpacing(wrap, result);
			// The focus probe runs synchronously and hands focus straight back.
			ownFocus = true;
			try {
				checkFocus(controls, result);
			} finally {
				if (active && active !== document.body && active.focus && active.isConnected) {
					active.focus({ preventScroll: true });
				} else if (document.activeElement && document.activeElement.blur) {
					document.activeElement.blur();
				}
				ownFocus = false;
			}
			await checkCovered(wrap, controls, result, function () { return focusMovedElsewhere || !wrap.isConnected; });
			if (focusMovedElsewhere) { result.later('obscured', '', { reason: 'interaction' }); }
		} finally {
			wrap.classList.remove('af-live-checking');
			document.removeEventListener('focusin', noteFocus, true);
			['keydown', 'pointermove', 'pointerdown', 'wheel', 'touchstart', 'af:statechange'].forEach(function (name) { document.removeEventListener(name, noteInteraction, true); });
			if (!focusMovedElsewhere) {
				try {
					window.scrollTo({ left: scrollX, top: scrollY, behavior: 'instant' });
				} catch (e) {
					window.scrollTo(scrollX, scrollY);
				}
			}
		}
		return { issues: byPriority(merge(result.issues)), unverified: merge(result.unverified) };
	}

	/* ------------------------------------------------------------------ */
	/* Plain-language messages                                             */
	/* ------------------------------------------------------------------ */

	var FOCUS_CSS = '.af-wrap :focus-visible { outline: 3px solid currentColor !important; outline-offset: 3px !important; }';

	function quoteName(label) {
		return label
			? sprintf(
					/* translators: %s: control or field label. */
					__('“%s”', 'accessible-forms-by-accessible-org'),
					label
				)
			: __('a control', 'accessible-forms-by-accessible-org');
	}

	function more(issue) {
		return issue.count > 1
			? ' ' +
					sprintf(
						/* translators: %d: number of options affected. */
						_n('(%d option)', '(all %d options)', issue.count, 'accessible-forms-by-accessible-org'),
						issue.count
					)
			: '';
	}

	/** { what, fix, css } for one problem. */
	function explain(issue) {
		var d = issue.detail || {};
		var name = quoteName(issue.label);
		switch (issue.code) {
			case 'name_missing':
				return {
					what:
						'aria-hidden' === d.reason
							? sprintf(/* translators: %s: the field’s name in quotes. */ __('%s is hidden from screen readers by the page.', 'accessible-forms-by-accessible-org'), name)
							: sprintf(/* translators: %s: the field’s name in quotes. */ __('%s has no name for screen readers.', 'accessible-forms-by-accessible-org'), name),
					fix: __(
						'A theme, page builder or plugin script changed the form field. Turn off recently added plugins one at a time, or remove custom code that edits the form.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'name_mismatch':
				return {
					what: sprintf(
						/* translators: 1: the field’s name in quotes, 2: the name screen readers hear, 3: the visible label. */ __('Screen readers call %1$s “%2$s”, which does not include its visible label “%3$s”.', 'accessible-forms-by-accessible-org'),
						name,
						d.name,
						d.visible
					),
					fix: __(
						'Something added an aria-label that replaces the visible label. Remove it so voice control users can say what they see.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'label_hidden':
				return {
					what:
						sprintf(/* translators: 1: the field’s name in quotes, 2: why it cannot be seen. */ __('The label for %1$s cannot be seen: %2$s.', 'accessible-forms-by-accessible-org'), name, d.why || '') +
						(d.by ? ' (' + d.by + ')' : ''),
					fix:
						'covered' === d.reason
							? __('Move or resize the element that covers it, or change where it is fixed on the screen.', 'accessible-forms-by-accessible-org')
							: __(
									'Your theme or a plugin hides or shrinks form labels. Remove that CSS, or choose “Labels above fields” in the form’s layout settings.',
									'accessible-forms-by-accessible-org'
								),
				};
			case 'focus_none':
				return {
					what:
						sprintf(
							/* translators: %s: the field’s name in quotes. */ __('Your theme hides the focus outline on %s. Keyboard users cannot see where they are.', 'accessible-forms-by-accessible-org'),
							name
						) + more(issue),
					fix: __(
						'Remove “outline: none” from your theme’s CSS, or add this CSS in your theme’s Additional CSS, or choose a different theme style:',
						'accessible-forms-by-accessible-org'
					),
					css: FOCUS_CSS,
				};
			case 'focus_low_contrast':
				return {
					what:
						sprintf(
							/* translators: 1: the field’s name in quotes, 2: measured contrast ratio. */ __('The focus outline on %1$s is hard to see (contrast %2$s:1, needs 3:1).', 'accessible-forms-by-accessible-org'),
							name,
							d.ratio
						) + more(issue),
					fix: __('Use a darker or stronger focus colour. For example, add this to your theme’s Additional CSS:', 'accessible-forms-by-accessible-org'),
					css: FOCUS_CSS,
				};
			case 'contrast_text':
				return {
					what: sprintf(
						/* translators: 1: the field’s name in quotes, 2: measured contrast ratio, 3: required contrast ratio. */ __('The text of %1$s has low contrast (%2$s:1, needs %3$s:1).', 'accessible-forms-by-accessible-org'),
						name,
						d.ratio,
						d.needed
					),
					fix: __(
						'Choose darker text or a lighter background in the form’s Appearance settings. If they are already fine, your theme’s CSS overrides them; remove that CSS.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'contrast_border':
				return {
					what:
						sprintf(
							/* translators: 1: the field’s name in quotes, 2: measured contrast ratio. */ __('The border of %1$s is hard to see against the background (%2$s:1, needs 3:1).', 'accessible-forms-by-accessible-org'),
							name,
							d.ratio
						) + more(issue),
					fix: __(
						'Choose a darker field border in the form’s Appearance settings, or remove theme CSS that lightens form field borders.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'target_small':
				return {
					what:
						sprintf(
							/* translators: 1: the field’s name in quotes, 2: width in pixels, 3: height in pixels. */ __('%1$s is only %2$d × %3$d pixels to click or tap (needs at least 24 × 24).', 'accessible-forms-by-accessible-org'),
							name,
							d.width,
							d.height
						) + more(issue),
					fix: __(
						'Your theme or a plugin shrinks checkboxes, radio buttons or buttons. Remove that CSS, or add padding so the target is larger.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'obscured':
				return {
					what: sprintf(
						/* translators: 1: the field’s name in quotes, 2: the covering element, 3: top, middle or bottom. */ __('%1$s is completely covered by another element (%2$s) when it is scrolled to the %3$s of the window.', 'accessible-forms-by-accessible-org'),
						name,
						d.by,
						'start' === d.position
							? __('top', 'accessible-forms-by-accessible-org')
							: 'end' === d.position
								? __('bottom', 'accessible-forms-by-accessible-org')
								: __('middle', 'accessible-forms-by-accessible-org')
					),
					fix: __(
						'A sticky header, cookie banner or chat button covers it. Make the banner smaller, let people close it, or add scroll-padding to your theme so focused fields stay visible.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'required_marker':
				return {
					what: sprintf(/* translators: %s: the field’s name in quotes. */ __('%s is required, but its “(required)” marker is missing or hidden.', 'accessible-forms-by-accessible-org'), name),
					fix: __('Remove theme or plugin CSS that hides .af-req.', 'accessible-forms-by-accessible-org'),
				};
			case 'ref_missing':
				return {
					what: sprintf(
						/* translators: 1: the field’s name in quotes, 2: the missing element id. */ __('%1$s points to a label or description that is not on the page (id “%2$s”).', 'accessible-forms-by-accessible-org'),
						name,
						d.id
					),
					fix: __(
						'A script or page builder removed or renamed part of the form. Place the form with the Accessible Form block or shortcode instead of copying its HTML.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'duplicate_id':
				return {
					what: sprintf(
						/* translators: %s: the repeated element id. */ __('The id “%s” is used more than once on this page, so assistive technology may read the wrong label.', 'accessible-forms-by-accessible-org'),
						d.id
					),
					fix: __(
						'This usually happens when a page builder copies the form HTML. Embed each form with the block or shortcode, not as copied HTML.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'injected_markup':
				return {
					what: sprintf(
						/* translators: %d: number of added tags. */ _n(
							'%d extra paragraph or line-break tag was added inside the form.',
							'%d extra paragraph or line-break tags were added inside the form.',
							d.count,
							'accessible-forms-by-accessible-org'
						),
						d.count
					),
					fix: __(
						'A content filter (often automatic paragraphs in a classic or page-builder text block) changed the form. Put the shortcode in a Shortcode block, or use the Accessible Form block.',
						'accessible-forms-by-accessible-org'
					),
				};
			case 'heading_missing':
				return {
					what: issue.label
						? sprintf(/* translators: 1: the form heading in quotes, 2: why it cannot be seen. */ __('The form heading %1$s cannot be seen: %2$s.', 'accessible-forms-by-accessible-org'), name, d.why || '')
						: __('The form has no heading or name.', 'accessible-forms-by-accessible-org'),
					fix: __('Remove theme CSS that hides the form heading, or choose a heading level in the form’s settings.', 'accessible-forms-by-accessible-org'),
				};
			case 'text_clipped':
				return {
					what: sprintf(/* translators: %s: the element whose text is cut off. */ __('Text in %s is cut off.', 'accessible-forms-by-accessible-org'), name),
					fix: __('Remove a fixed height or “overflow: hidden” from your theme’s CSS for this part of the form.', 'accessible-forms-by-accessible-org'),
				};
			case 'spacing_clip':
				return {
					what: sprintf(
						/* translators: %s: the element whose text is cut off. */ __('Text in %s is cut off when people increase letter, word or line spacing.', 'accessible-forms-by-accessible-org'),
						name
					),
					fix: __('Remove a fixed height or “overflow: hidden” from your theme’s CSS for this part of the form.', 'accessible-forms-by-accessible-org'),
				};
			case 'form_overflow':
				return {
					what: __('The form becomes wider than its space when people increase text spacing.', 'accessible-forms-by-accessible-org'),
					fix: __('Remove fixed widths from form fields and buttons in your theme’s CSS.', 'accessible-forms-by-accessible-org'),
				};
		}
		return { what: issue.code, fix: '' };
	}

	function explainLater(item) {
		if (item.code === 'obscured' && item.detail.reason === 'interaction') { return __('The page changed or you interacted during the covering check. Check this state again when ready.', 'accessible-forms-by-accessible-org'); }
		if (item.code === 'obscured' && item.detail.reason === 'budget') { return __('This form has many controls; the covering check could not finish in one pass. Check each section by keyboard.', 'accessible-forms-by-accessible-org'); }
		var name = quoteName(item.label);
		switch (item.code) {
			case 'contrast_text':
				return sprintf(
					/* translators: %s: the field’s name in quotes. */ __('Contrast of %s: it sits on a background image or gradient. Check by eye that it is easy to read.', 'accessible-forms-by-accessible-org'),
					name
				);
			case 'contrast_border':
				return sprintf(/* translators: %s: the field’s name in quotes. */ __('Border of %s: check by eye that the field edge is easy to see.', 'accessible-forms-by-accessible-org'), name);
			case 'focus_none':
				return sprintf(
					/* translators: %s: the field’s name in quotes. */ __('Focus on %s: press Tab to reach it and check that you can see where you are.', 'accessible-forms-by-accessible-org'),
					name
				);
		}
		return name;
	}

	/* ------------------------------------------------------------------ */
	/* Notice                                                              */
	/* ------------------------------------------------------------------ */

	function el(tag, className, text) {
		var node = document.createElement(tag);
		if (className) {
			node.className = className;
		}
		if (undefined !== text) {
			node.textContent = text;
		}
		return node;
	}

	function formTitle(wrap) {
		var heading = wrap.querySelector('.af-heading');
		if (heading) {
			return clean(heading.textContent);
		}
		var form = wrap.querySelector('form.af-form');
		return form ? clean(form.getAttribute('aria-label')) : '';
	}

	function buildNotice(wrap, formId) {
		counter++;
		var id = 'af-live-check-' + counter;
		var notice = el('div', NOTICE_CLASS);
		notice.id = id;
		notice.setAttribute('role', 'region');
		notice.setAttribute('data-af-live-check', formId);
		var title = formTitle(wrap);
		notice.setAttribute(
			'aria-label',
			title
				? sprintf(
						/* translators: %s: form heading. */
						__('Accessibility check: %s', 'accessible-forms-by-accessible-org'),
						title
					)
				: __('Accessibility check', 'accessible-forms-by-accessible-org')
		);

		var heading = el('p', NOTICE_CLASS + '__title');
		heading.appendChild(el('strong', '', __('Accessibility check for this page (only you can see this)', 'accessible-forms-by-accessible-org')));
		notice.appendChild(heading);

		var status = el('p', NOTICE_CLASS + '__summary');
		status.setAttribute('role', 'status');
		notice.appendChild(status);

		notice.appendChild(el('div', NOTICE_CLASS + '__body'));

		var actions = el('p', NOTICE_CLASS + '__actions');
		var again = el('button', NOTICE_CLASS + '__again', __('Check again', 'accessible-forms-by-accessible-org'));
		again.type = 'button';
		again.addEventListener('click', function () {
			if ('true' === again.getAttribute('aria-disabled')) {
				return;
			}
			// Validation can replace the form while retaining this notice.
			var current = notice.nextElementSibling;
			run(current && current.matches('.af-wrap[data-af-form]') ? [current] : wrapsToCheck());
		});
		actions.appendChild(again);
		var edit = config.editLinks && config.editLinks[formId];
		if (edit) {
			var link = el('a', NOTICE_CLASS + '__link', __('Edit this form', 'accessible-forms-by-accessible-org'));
			link.href = edit;
			actions.appendChild(link);
		}
		if (config.healthUrl) {
			var health = el('a', NOTICE_CLASS + '__link', __('All page checks', 'accessible-forms-by-accessible-org'));
			health.href = config.healthUrl + '#af-live-checks';
			actions.appendChild(health);
		}
		notice.appendChild(actions);

		notice.appendChild(
			el(
				'p',
				NOTICE_CLASS + '__note',
				config.privateTest ? __('Private snapshot check: results describe this test state and do not replace the checks for your published page.', 'accessible-forms-by-accessible-org') : __(
					'Visitors do not see this notice. It appears only to people who can edit this form, and results are saved only on this site.', 'accessible-forms-by-accessible-org')
			)
		);
		wrap.parentNode.insertBefore(notice, wrap);
		return notice;
	}

	function renderResult(notice, outcome) {
		var count = outcome.issues.length;
		var status = notice.querySelector('.' + NOTICE_CLASS + '__summary');
		var body = notice.querySelector('.' + NOTICE_CLASS + '__body');
		var summary = count
			? sprintf(
					/* translators: %d: number of problems. */
					_n('%d problem found.', '%d problems found.', count, 'accessible-forms-by-accessible-org'),
					count
				)
			: __('All checks passed.', 'accessible-forms-by-accessible-org');
		if (outcome.unverified.length) {
			summary +=
				' ' +
				sprintf(
					/* translators: %d: number of things to check by eye. */
					_n('%d thing to check by eye.', '%d things to check by eye.', outcome.unverified.length, 'accessible-forms-by-accessible-org'),
					outcome.unverified.length
				);
		}

		body.textContent = '';
		if (count || outcome.unverified.length) {
			var details = el('details', NOTICE_CLASS + '__details');
			details.appendChild(
				el(
					'summary',
					'',
					count
						? __('Show the problems and what to do', 'accessible-forms-by-accessible-org')
						: __('Show what to check by eye', 'accessible-forms-by-accessible-org')
				)
			);
			if (count) {
				var list = el('ol', NOTICE_CLASS + '__list');
				outcome.issues.slice(0, 30).forEach(function (issue) {
					var text = explain(issue);
					var item = el('li', NOTICE_CLASS + '__item');
					item.setAttribute('data-code', issue.code);
					item.appendChild(el('p', NOTICE_CLASS + '__what', text.what));
					if (text.fix) {
						item.appendChild(el('p', NOTICE_CLASS + '__fix', text.fix));
					}
					if (text.css) {
						var pre = el('pre', NOTICE_CLASS + '__css');
						pre.appendChild(el('code', '', text.css));
						item.appendChild(pre);
					}
					list.appendChild(item);
				});
				details.appendChild(list);
			}
			if (outcome.unverified.length) {
				details.appendChild(el('p', NOTICE_CLASS + '__subhead', __('Could not verify automatically:', 'accessible-forms-by-accessible-org')));
				var later = el('ul', NOTICE_CLASS + '__list');
				outcome.unverified.slice(0, 20).forEach(function (item) {
					var li = el('li', NOTICE_CLASS + '__item', explainLater(item));
					li.setAttribute('data-code', item.code);
					later.appendChild(li);
				});
				details.appendChild(later);
			}
			body.appendChild(details);
		}

		notice.setAttribute('data-state', 'done');
		notice.setAttribute('data-problems', String(count));
		notice.classList.toggle(NOTICE_CLASS + '--problems', count > 0);
		// Clear first so assistive technology announces a repeated result too.
		status.textContent = '';
		window.setTimeout(function () {
			status.textContent = summary;
		}, 100);
	}

	function report(formId, outcome) {
		if (!config.report || !window.fetch || !window.FormData) {
			return Promise.resolve();
		}
		var body = new FormData();
		body.append('action', config.action);
		body.append('nonce', config.nonce);
		body.append('form_id', formId);
		body.append('path', window.location.pathname);
		body.append('object_id', String(config.objectId || 0));
		body.append(
			'issues',
			JSON.stringify(
				outcome.issues.slice(0, 30).map(function (issue) {
					return { code: issue.code, label: issue.label };
				})
			)
		);
		body.append('unverified', String(outcome.unverified.length));
		return fetch(config.ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body }).catch(function () {
			// Saving the result is a convenience; the notice already shows it.
		});
	}

	function wrapsToCheck() {
		return Array.from(document.querySelectorAll('.af-wrap[data-af-form]')).filter(function (wrap) {
			return -1 !== allowed.indexOf(String(wrap.getAttribute('data-af-form')));
		});
	}

	var running = false, requestedAgain = false, stateTimer = 0;

	async function run(wraps) {
		if (running) {
			requestedAgain = true;
			return;
		}
		running = true;
		var pending = [];
		var replaced = false;
		wraps.forEach(function (wrap) {
			var notice = wrap.previousElementSibling;
			if (notice && notice.classList.contains(NOTICE_CLASS)) {
				notice.setAttribute('data-state', 'running');
				notice.querySelector('.' + NOTICE_CLASS + '__summary').textContent = __('Checking…', 'accessible-forms-by-accessible-org');
				notice.querySelector('.' + NOTICE_CLASS + '__again').setAttribute('aria-disabled', 'true');
			}
		});
		try {
			// Measure every form first, then insert any new notices.
			for (var i = 0; i < wraps.length; i++) {
				var outcome = await checkWrap(wraps[i]);
				pending.push({ wrap: wraps[i], outcome: outcome });
			}
			pending.forEach(function (item) {
				// The form was replaced while it was being measured (for example by an
				// in-page submit). Its results no longer describe the page.
				if (!item.wrap.isConnected) {
					replaced = true;
					return;
				}
				var formId = item.wrap.getAttribute('data-af-form');
				var notice = item.wrap.previousElementSibling;
				if (item.outcome.skipped) {
					// A confirmation or closed form has no active controls to measure.
					if (notice && notice.classList.contains(NOTICE_CLASS)) { notice.remove(); }
					return;
				}
				if (!notice || !notice.classList.contains(NOTICE_CLASS)) {
					notice = buildNotice(item.wrap, formId);
				}
				notice.querySelector('.' + NOTICE_CLASS + '__again').removeAttribute('aria-disabled');
				renderResult(notice, item.outcome);
				report(formId, item.outcome);
			});
		} finally {
			running = false;
		}
		if (requestedAgain) { replaced = true; requestedAgain = false; }
		if (replaced) {
			// Check the forms now on the page instead.
			window.setTimeout(function () {
				run(wrapsToCheck());
			}, 600);
			return;
		}
		document.dispatchEvent(new CustomEvent('accessible-forms-live-check', { detail: { count: pending.length } }));
	}

	function start() {
		var ready = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
		ready
			.then(function () {
				// Let late banners, lazy styles and page-builder scripts settle.
				return wait(600);
			})
			.then(frame)
			.then(function () {
				var wraps = wrapsToCheck();
				if (wraps.length) {
					run(wraps);
				}
			});
	}
	// Recheck only the state the author actually reaches. Never invent answers or advance steps.
	['af:statechange', 'af:rendered'].forEach(function (name) {
		document.addEventListener(name, function () {
			window.clearTimeout(stateTimer);
			stateTimer = window.setTimeout(function () { run(wrapsToCheck()); }, 800);
		});
	});

	if ('complete' === document.readyState) {
		start();
	} else {
		window.addEventListener('load', start);
	}
})();
