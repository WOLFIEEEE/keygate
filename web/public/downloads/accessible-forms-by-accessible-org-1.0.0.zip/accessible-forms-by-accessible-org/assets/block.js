/** Published-form picker and a non-interactive preview in the native editor. */
(function (wp) {
	'use strict';
	var el = wp.element.createElement;
	var useState = wp.element.useState;
	var useEffect = wp.element.useEffect;
	var __ = wp.i18n.__;
	var config = window.AccessibleFormsBlock || {};
	var C = wp.components;
	function Edit(props) {
		var formId = props.attributes.formId || 0;
		var queryState = useState(''),
			query = queryState[0],
			setQuery = queryState[1];
		var pageState = useState(1),
			page = pageState[0],
			setPage = pageState[1];
		var listState = useState([]),
			forms = listState[0],
			setForms = listState[1];
		var pagesState = useState(1),
			pages = pagesState[0],
			setPages = pagesState[1];
		var loadingState = useState(true),
			loading = loadingState[0],
			setLoading = loadingState[1];
		var listErrorState = useState(''),
			listError = listErrorState[0],
			setListError = listErrorState[1];
		var selectedState = useState(null),
			selected = selectedState[0],
			setSelected = selectedState[1];
		var htmlState = useState(''),
			html = htmlState[0],
			setHtml = htmlState[1];
		var errorState = useState(''),
			error = errorState[0],
			setError = errorState[1];
		var previewState = useState(false),
			previewLoading = previewState[0],
			setPreviewLoading = previewState[1];
		var revisionState = useState(0),
			revision = revisionState[0],
			setRevision = revisionState[1];
		var chooseState = useState(false),
			choosing = chooseState[0],
			setChoosing = chooseState[1];

		useEffect(
			function () {
				var active = true;
				setLoading(true);
				setListError('');
				var timer = window.setTimeout(
					function () {
						wp.apiFetch({
							path:
								'/accessible-forms/v1/forms?search=' +
								encodeURIComponent(query) +
								'&page=' +
								page,
						})
							.then(function (result) {
								if (!active) {
									return;
								}
								setForms(function (previous) {
									var items = page === 1 ? result.items : previous.concat(result.items);
									return items.filter(function (item, index) {
										return (
											items.findIndex(function (candidate) {
												return candidate.id === item.id;
											}) === index
										);
									});
								});
								setPages(result.pages);
								setLoading(false);
							})
							.catch(function () {
								if (active) {
									setListError(
										__(
											'Could not load forms. Check your connection and refresh the list.',
											'accessible-forms-by-accessible-org',
										),
									);
									setLoading(false);
								}
							});
					},
					query ? 250 : 0,
				);
				return function () {
					active = false;
					window.clearTimeout(timer);
				};
			},
			[query, page, revision],
		);

		useEffect(
			function () {
				var active = true;
				setSelected(null);
				setHtml('');
				setError('');
				if (!formId) {
					setPreviewLoading(false);
					return;
				}
				setPreviewLoading(true);
				Promise.all([
					wp.apiFetch({ path: '/accessible-forms/v1/forms/' + formId }),
					wp.apiFetch({ path: '/accessible-forms/v1/forms/' + formId + '/preview' }),
				])
					.then(function (result) {
						if (active) {
							setSelected(result[0]);
							setHtml(result[1].html);
							setPreviewLoading(false);
						}
					})
					.catch(function (failure) {
						if (!active) {
							return;
						}
						setError(
							failure.code === 'accessible_forms_unavailable'
								? __(
										'This form has been unpublished or deleted. Choose another published form.',
										'accessible-forms-by-accessible-org',
									)
								: __(
										'The form preview could not load. Refresh forms to try again.',
										'accessible-forms-by-accessible-org',
									),
						);
						setPreviewLoading(false);
					});
				return function () {
					active = false;
				};
			},
			[formId, revision],
		);

		function refresh() {
			setPage(1);
			setRevision(revision + 1);
		}
		function choose(value) {
			props.setAttributes({ formId: parseInt(value, 10) || 0 });
			setChoosing(false);
		}
		var options = forms.map(function (form) {
			return { label: form.title, value: String(form.id) };
		});
		if (
			selected &&
			!forms.some(function (form) {
				return form.id === selected.id;
			})
		) {
			options.unshift({ label: selected.title, value: String(selected.id) });
		}
		function picker() {
			return el(
				'div',
				{ className: 'af-block-picker' },
				el(C.ComboboxControl, {
					label: __('Choose a published form', 'accessible-forms-by-accessible-org'),
					value: formId ? String(formId) : null,
					options: options,
					onChange: choose,
					onFilterValueChange: function (value) {
						setQuery(value || '');
						setPage(1);
					},
					help: __('Type to search by form name.', 'accessible-forms-by-accessible-org'),
				}),
				loading ? el('p', { role: 'status' }, __('Loading forms…', 'accessible-forms-by-accessible-org')) : null,
				listError ? el(C.Notice, { status: 'error', isDismissible: false }, listError) : null,
				!loading && !forms.length && !listError
					? el(
							'p',
							null,
							query
								? __('No matching published forms. Try another name.', 'accessible-forms-by-accessible-org')
								: __(
										'No published forms yet. Create a form and publish it, then refresh this list.',
										'accessible-forms-by-accessible-org',
									),
						)
					: null,
				page < pages
					? el(
							C.Button,
							{
								variant: 'secondary',
								onClick: function () {
									setPage(page + 1);
								},
								disabled: loading,
							},
							__('Load more forms', 'accessible-forms-by-accessible-org'),
						)
					: null,
				el(
					'div',
					{ className: 'af-block-links' },
					el(
						C.Button,
						{ variant: 'secondary', onClick: refresh, disabled: loading },
						__('Refresh forms', 'accessible-forms-by-accessible-org'),
					),
					config.createUrl
						? el(
								C.Button,
								{
									variant: 'link',
									href: config.createUrl,
									target: '_blank',
									rel: 'noopener',
								},
								__('Create a form (new tab)', 'accessible-forms-by-accessible-org'),
							)
						: null,
				),
			);
		}
		var inspector = el(
			wp.blockEditor.InspectorControls,
			null,
			el(
				C.PanelBody,
				{ title: __('Form', 'accessible-forms-by-accessible-org') },
				picker(),
				el(
					'p',
					null,
					__(
						'Manage fields, colors, recipients, and confirmation text in the form settings. Changes there apply everywhere this form is used.',
						'accessible-forms-by-accessible-org',
					),
				),
				selected && selected.edit_url
					? el(
							C.Button,
							{ variant: 'link', href: selected.edit_url, target: '_blank', rel: 'noopener' },
							__('Edit form settings (new tab)', 'accessible-forms-by-accessible-org'),
						)
					: null,
			),
		);
		var header = el(
			'div',
			{ className: 'af-block-header' },
			el('strong', null, selected ? selected.title : __('Accessible Form', 'accessible-forms-by-accessible-org')),
			formId && !choosing
				? el(
						C.Button,
						{
							variant: 'secondary',
							onClick: function () {
								setChoosing(true);
							},
						},
						__('Change form', 'accessible-forms-by-accessible-org'),
					)
				: null,
			selected
				? el(
						C.Button,
						{ variant: 'tertiary', onClick: refresh },
						__('Refresh preview', 'accessible-forms-by-accessible-org'),
					)
				: null,
		);
		return el(
			'div',
			wp.blockEditor.useBlockProps({ className: 'af-editor-block' }),
			inspector,
			header,
			!formId || choosing || error ? picker() : null,
			error ? el(C.Notice, { status: 'warning', isDismissible: false }, error) : null,
			previewLoading
				? el('p', { role: 'status' }, __('Loading form preview…', 'accessible-forms-by-accessible-org'))
				: null,
			html
				? el(
						'div',
						null,
						el(
							'p',
							{ className: 'af-block-caption' },
							__(
								'Form preview. Visitors can fill this out on the published page.',
								'accessible-forms-by-accessible-org',
							),
						),
						el('div', {
							className: 'af-block-preview',
							inert: '',
							dangerouslySetInnerHTML: { __html: html },
						}),
					)
				: null,
		);
	}
	wp.blocks.registerBlockType('accessible-forms/form', {
		apiVersion: 3,
		title: __('Accessible Form', 'accessible-forms-by-accessible-org'),
		icon: 'feedback',
		category: 'widgets',
		description: __(
			'Add a published form with accessible labels, validation, and a checked color theme.',
			'accessible-forms-by-accessible-org',
		),
		keywords: [__('contact', 'accessible-forms-by-accessible-org'), __('enquiry', 'accessible-forms-by-accessible-org')],
		attributes: { formId: { type: 'number', default: 0 } },
		supports: { html: false, customClassName: false, align: ['wide', 'full'] },
		edit: Edit,
		save: function () {
			return null;
		},
	});
})(window.wp);
