/** Shared lifecycle for explicit, paginated admin searches. */
(function () {
	'use strict';
	/** The deadline includes reading JSON, so a stalled body cannot strand the UI. */
	window.AccessibleFormsRequest = async function (url, options, controller) {
		controller = controller || new AbortController();
		var timer;
		var deadline = new Promise(function (resolve, reject) {
			timer = window.setTimeout(function () { controller.abort(); reject(new Error('Request timed out')); }, 15000);
		});
		try {
			return await Promise.race([
				fetch(url, Object.assign({}, options, { signal: controller.signal })).then(async function (response) {
					return { response: response, data: await response.json() };
				}), deadline,
			]);
		} finally {
			window.clearTimeout(timer);
		}
	};
	window.AccessibleFormsSearch = function (options) {
		var page = options.page || 0, query = '', current;
		return async function (term, loadMore) {
			term = term.trim();
			if (current) { current.abort(); }
			var request = new AbortController();
			current = request;
			var context = { append: !!loadMore && query === term && page > 0, query: term };
			context.page = context.append ? page + 1 : 1;
			// A failed new search must not resume the previous query's pagination.
			if (!context.append) { page = 0; query = term; }
			options.start(context);
			var data = new FormData();
			Object.keys(options.parameters).forEach(function (key) { data.set(key, options.parameters[key]); });
			data.set('search', term);
			data.set('page', String(context.page));
			try {
				var fetched = await window.AccessibleFormsRequest(options.url, { method: 'POST', body: data, credentials: 'same-origin' }, request);
				var response = fetched.response, result = fetched.data;
				if (current !== request) { return; }
				if (request.signal.aborted || !response.ok || !result.success || !Array.isArray(result.data.items)) { throw new Error(); }
				page = context.page;
				options.success(result.data, context);
			} catch (error) {
				if (current === request) { options.error(context); }
			} finally {
				if (current === request) { current = null; options.end(context); }
			}
		};
	};
})();
