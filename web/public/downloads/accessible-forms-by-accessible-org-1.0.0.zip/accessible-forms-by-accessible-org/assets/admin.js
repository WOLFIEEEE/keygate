/** Accessible form builder. No drag gesture is required to arrange fields. */
(function () {
	'use strict';
	var entriesForm = document.getElementById('af-entries-form');
	if (entriesForm) {
		entriesForm.addEventListener('submit', function (event) {
			var action = entriesForm.querySelector('[name=action]');
			var second = entriesForm.querySelector('[name=action2]');
			var value = action && action.value !== '-1' ? action.value : second ? second.value : '';
			if (
				value === 'delete' &&
				entriesForm.querySelector('input[name="entry[]"]:checked') &&
				!window.confirm(
					window.wp.i18n.__(
						'Permanently delete the selected entries? This cannot be undone.',
						'accessible-forms-by-accessible-org',
					),
				)
			) {
				event.preventDefault();
			}
		});
	}
	var __ = window.wp.i18n.__;
	var sprintf = window.wp.i18n.sprintf;
	var config = window.AccessibleFormsEditor || { types: {}, maxFields: 50 };
	var container = document.getElementById('af-fields');
	var template = document.getElementById('af-field-template');
	var addButton = document.getElementById('af-add-field');
	var undoButton = document.getElementById('af-undo-field');
	var status = document.getElementById('af-builder-status');
	var listRoot = document.querySelector('.af-entry-list') ||
		(document.body.classList.contains('af-forms-list') ? document.getElementById('posts-filter') : null);
	if (listRoot) {
		function syncRowDisclosure(button) {
			button.setAttribute('aria-expanded', button.closest('tr').classList.contains('is-expanded') ? 'true' : 'false');
		}
		listRoot.querySelectorAll('.toggle-row').forEach(syncRowDisclosure);
		// WordPress changes the row at tbody; bubbling reaches this wrapper afterwards.
		function updateRowDisclosure(event) {
			var button = event.target.closest && event.target.closest('.toggle-row');
			if (button && listRoot.contains(button)) { syncRowDisclosure(button); }
		}
		listRoot.addEventListener('click', updateRowDisclosure);
		// Native Quick Edit can replace rows. Refresh their state when focused too.
		listRoot.addEventListener('focusin', updateRowDisclosure);
	}
	if (!status && document.body.classList.contains('af-forms-list')) {
		status = document.createElement('p');
		status.id = 'af-list-status';
		status.className = 'screen-reader-text';
		status.setAttribute('role', 'status');
		status.setAttribute('aria-atomic', 'true');
		document.getElementById('wpbody-content').appendChild(status);
	}
	var removed = null;
	var protectionReady = new WeakSet();
	function initProtection(root) {
		root.querySelectorAll('[name="af_settings[spam_provider]"]').forEach(function (radio) {
			if (protectionReady.has(radio)) { return; }
			protectionReady.add(radio);
			function updateProtection() {
				var selected = root.querySelector('[name="af_settings[spam_provider]"]:checked');
				root.querySelectorAll('[data-af-spam-panel]').forEach(function (panel) {
					panel.hidden = !selected || panel.dataset.afSpamPanel !== selected.value;
				});
			}
			radio.addEventListener('change', updateProtection);
			updateProtection();
		});
	}
	initProtection(document);
	document.addEventListener('af:panelready', function (event) { initProtection(event.detail.root); });

	function announce(message) {
		if (status) {
			status.textContent = message;
		}
	}

	document.addEventListener('click', async function (event) {
		var button = event.target.closest('.af-copy');
		if (!button) { return; }
		var copyLabel = button.dataset.afCopyLabel || button.getAttribute('aria-label');
		if (copyLabel) { button.dataset.afCopyLabel = copyLabel; }
			var code = document.getElementById(button.dataset.copyTarget);
			try {
				await navigator.clipboard.writeText(code.textContent);
				button.textContent = __('Copied', 'accessible-forms-by-accessible-org');
				if (copyLabel) {
					button.setAttribute('aria-label', __('Copied', 'accessible-forms-by-accessible-org') + '. ' + copyLabel);
				}
				announce(__('Shortcode copied to clipboard.', 'accessible-forms-by-accessible-org'));
			} catch (error) {
				var selection = window.getSelection();
				var range = document.createRange();
				range.selectNodeContents(code);
				selection.removeAllRanges();
				selection.addRange(range);
				announce(__('Select and copy the shortcode using your keyboard.', 'accessible-forms-by-accessible-org'));
			}
	});

	var recipients = document.getElementById('af-recipients');
	var recipientTemplate = document.getElementById('af-recipient-template');
	var recipientAdd = document.getElementById('af-add-recipient');
	function numberRecipients() {
		var rows = Array.from(recipients.children);
		rows.forEach(function (row, index) {
			var input = row.querySelector('input');
			input.id = 'af-recipient-' + index;
			row.querySelector('label').htmlFor = input.id;
			row.querySelector('.af-recipient-number').textContent = index + 1;
			var remove = row.querySelector('button');
			remove.hidden = rows.length === 1;
			/* translators: %d: notification recipient position. */
			remove.setAttribute(
				'aria-label',
				/* translators: %d: position of the email address in the list. */
				sprintf(__('Remove email address %d', 'accessible-forms-by-accessible-org'), index + 1),
			);
		});
	}
	if (recipients && recipientTemplate && recipientAdd) {
		numberRecipients();
		recipientAdd.addEventListener('click', function () {
			if (recipients.children.length >= 20) {
				announce(__('Use no more than 20 email addresses.', 'accessible-forms-by-accessible-org'));
				return;
			}
			var holder = document.createElement('div');
			holder.innerHTML = recipientTemplate.innerHTML.replace(
				/__INDEX__/g,
				String(recipients.children.length),
			);
			var row = holder.firstElementChild;
			recipients.appendChild(row);
			numberRecipients();
			row.querySelector('input').focus();
			announce(
				__('Email address added. Everyone listed will receive each submission.', 'accessible-forms-by-accessible-org'),
			);
		});
		recipients.addEventListener('click', function (event) {
			var remove = event.target.closest('.af-remove-recipient');
			if (!remove || recipients.children.length <= 1) {
				return;
			}
			var row = remove.closest('.af-recipient-row');
			var next = row.nextElementSibling || row.previousElementSibling;
			row.remove();
			numberRecipients();
			next.querySelector('input').focus();
			announce(__('Email address removed.', 'accessible-forms-by-accessible-org'));
		});
	}
	var confirmation = document.getElementById('af-success_message');
	if (confirmation) {
		confirmation.addEventListener('input', function () {
			document.getElementById('af-confirmation-text').textContent =
				confirmation.value || __('Your confirmation message will appear here.', 'accessible-forms-by-accessible-org');
		});
	}

	document.querySelectorAll('.af-editor-nav a').forEach(function (link) {
		link.addEventListener('click', function () {
			var target = document.getElementById(link.hash.slice(1));
			if (target) {
				var detail = target.closest('details');
				if (detail) {
					detail.open = true;
				}
				target.tabIndex = -1;
				target.focus();
			}
		});
	});
	if (!container || !template || !addButton) {
		return;
	}
	// For add-ons with their own conditional settings.
	window.AccessibleFormsBuilder = { announce: announce, refreshConditions: refreshConditions };
	// "Asks about someone else" only matters once autofill is turned off.
	container.addEventListener('change', function (event) {
		if (event.target.matches('select[name$="[autocomplete]"]')) {
			var other = event.target.closest('.af-field-row').querySelector('.af-about-other');
			if (other) {
				other.hidden = event.target.value !== '';
			}
		}
	});

	function updateRow(row, refreshAutofill) {
		var type = row.querySelector('.af-type').value;
		var fieldType = config.types[type] || {};
		var label =
			row.querySelector('.af-label-input').value.trim() || __('Untitled field', 'accessible-forms-by-accessible-org');
		row.querySelector('.af-field-title').textContent = label;
		row.querySelector('.af-field-kind').textContent = fieldType.label || type;
		row.querySelector('.af-field-required').hidden = !row.querySelector('.af-required-input').checked;
		row.querySelector('.af-options-row').hidden = !fieldType.options;
		var numeric = row.querySelector('.af-number-options');
		if (numeric) {
			numeric.hidden = type !== 'number';
		}
		var urls = row.querySelector('.af-url-options');
		if (urls) {
			urls.hidden = type !== 'url';
		}
		// Panels for particular types, such as an add-on's, name them: data-af-types="file,url".
		row.querySelectorAll('[data-af-types]').forEach(function (panel) {
			panel.hidden = panel.dataset.afTypes.split(',').indexOf(type) === -1;
		});
		var limits = row.querySelector('.af-validation-options');
		if (limits) {
			// Answer limits are for typed answers; add-on types bring their own rules.
			limits.hidden =
				!!(config.types[type] || {}).addon || ['section', 'date', 'time', 'number', 'consent'].indexOf(type) !== -1;
		}
		row.querySelector('.af-required-control').hidden = type === 'section';
		// Add-on field settings show or hide themselves for the chosen type.
		row.dispatchEvent(new CustomEvent('af:rowupdate', { bubbles: true, detail: { type: type } }));
		row.querySelectorAll('.af-choice-label').forEach(function (input) {
			input.required = !!fieldType.options;
		});
		var tokens = fieldType.autocomplete || [];
		var autofill = row.querySelector('.af-autocomplete-row select');
		row.querySelector('.af-autocomplete-row').hidden = tokens.length === 0;
		if (refreshAutofill) {
			var previous = autofill.value;
			autofill.replaceChildren(
				new Option(__('Automatic (recommended)', 'accessible-forms-by-accessible-org'), 'auto'),
				new Option(__('Do not suggest autofill', 'accessible-forms-by-accessible-org'), ''),
			);
			tokens.forEach(function (token) {
				autofill.add(new Option(token, token));
			});
			autofill.value =
				previous === '' || previous === 'auto' || tokens.indexOf(previous) >= 0 ? previous : 'auto';
		}
		var inferred = autofill.value;
		if (inferred === 'auto') {
			inferred = { email: 'email', tel: 'tel', url: 'url' }[type] || '';
			if (type === 'text') {
				var candidates = [label, row.querySelector('input[name$="[name]"]').value];
				candidates.some(function (candidate) {
					candidate = candidate
						.toLowerCase()
						.replace(/[^\p{L}\p{N}]+/gu, ' ')
						.trim()
						.replace(/^(your|enter your|enter|please enter your) /, '');
					return Object.keys(config.autofillHints || {}).some(function (token) {
						if (
							config.autofillHints[token].some(function (hint) {
								return hint.toLowerCase() === candidate;
							})
						) {
							inferred = token;
							return true;
						}
						return false;
					});
				});
			}
		}
		var hint = row.querySelector('.af-autofill-hint');
		hint.hidden = tokens.length === 0;
		var autofillMessage;
		if (inferred) {
			/* translators: %s: browser autocomplete token, for example email or given-name. */
			autofillMessage = sprintf(
				/* translators: %s: name of the autofill purpose, such as Email. */
				__('Browser autofill: %s. You can change this in Advanced options.', 'accessible-forms-by-accessible-org'),
				inferred,
			);
		} else {
			autofillMessage =
				autofill.value === ''
					? __(
							'No autofill purpose is assigned. Change this in Advanced options.',
							'accessible-forms-by-accessible-org',
						)
					: __(
							'Autofill will be suggested when this field has a recognized personal-information label.',
							'accessible-forms-by-accessible-org',
						);
		}
		hint.textContent = autofillMessage;
	}

	// Extra per-field controls exist only with scripts, like the move buttons they sit beside.
	function addRowButtons(row) {
		var reorder = row.querySelector('.af-reorder');
		if (!row.querySelector('.af-move-top')) {
			var top = document.createElement('button');
			top.type = 'button';
			top.className = 'button af-move-top';
			top.textContent = __('Move to top', 'accessible-forms-by-accessible-org');
			reorder.insertBefore(top, reorder.firstChild);
		}
		if (!row.querySelector('.af-move-bottom')) {
			var bottom = document.createElement('button');
			bottom.type = 'button';
			bottom.className = 'button af-move-bottom';
			bottom.textContent = __('Move to bottom', 'accessible-forms-by-accessible-org');
			row.querySelector('.af-move-down').insertAdjacentElement('afterend', bottom);
		}
		if (!row.querySelector('.af-duplicate-field')) {
			var copy = document.createElement('button');
			copy.type = 'button';
			copy.className = 'button af-duplicate-field';
			copy.textContent = __('Duplicate field', 'accessible-forms-by-accessible-org');
			reorder.appendChild(copy);
		}
	}

	function fieldLabel(row) {
		return row.querySelector('.af-label-input').value.trim() || __('Untitled field', 'accessible-forms-by-accessible-org');
	}

	// Each button's name starts with its visible text, then says which field and where.
	function labelRowControls(row, index, total) {
		var label = fieldLabel(row);
		var filtering = isFiltering();
		[
			['.af-move-top', index === 0],
			['.af-move-up', index === 0],
			['.af-move-down', index === total - 1],
			['.af-move-bottom', index === total - 1],
			['.af-duplicate-field', false],
			['.af-remove-field', false],
		].forEach(function (item) {
			var button = row.querySelector(item[0]);
			if (!button) {
				return;
			}
			var isMove = item[0].indexOf('.af-move-') === 0;
			button.setAttribute(
				'aria-label',
				sprintf(
					/* translators: 1: visible button text, such as Move up, 2: field label, 3: field position, 4: number of fields. */
					__('%1$s: “%2$s”, field %3$d of %4$d', 'accessible-forms-by-accessible-org'),
					button.textContent,
					label,
					index + 1,
					total,
				),
			);
			// aria-disabled leaves the focused move button in the tab order at the boundary.
			button.setAttribute('aria-disabled', String(item[1] || (isMove && filtering)));
			if (isMove && filtering) {
				button.setAttribute('aria-describedby', 'af-find-field-note');
			} else {
				button.removeAttribute('aria-describedby');
			}
		});
	}

	function labelAllRows() {
		var rows = Array.from(container.children);
		rows.forEach(function (row, index) {
			labelRowControls(row, index, rows.length);
		});
	}

	function isFiltering() {
		return !!(search && search.value.trim());
	}

	function reindex() {
		var rows = Array.from(container.children);
		rows.forEach(function (row, index) {
			row.querySelectorAll('[name]').forEach(function (control) {
				var oldId = control.id;
				control.name = control.name.replace(
					/af_schema\[fields\]\[[^\]]*\]/,
					'af_schema[fields][' + index + ']',
				);
				if (oldId.indexOf('af-opt-') === 0) {
					control.id = 'af-opt-' + control.name.replace(/\[/g, '-').replace(/\]/g, '');
					row.querySelectorAll('label').forEach(function (label) {
						if (label.htmlFor === oldId) {
							label.htmlFor = control.id;
						}
					});
				}
			});
			row.querySelectorAll('[id], [for], [aria-describedby]').forEach(function (element) {
				['id', 'for', 'aria-describedby'].forEach(function (attribute) {
					if (element.hasAttribute(attribute)) {
						element.setAttribute(
							attribute,
							element
								.getAttribute(attribute)
								.replace(/af-field-[^-]*-/g, 'af-field-' + index + '-'),
						);
					}
				});
			});
			row.querySelector('.af-field-number').textContent = index + 1;
			addRowButtons(row);
			labelRowControls(row, index, rows.length);
			indexChoices(row);
			updateRow(row, false);
		});
		refreshConditions();
		addButton.disabled = rows.length >= config.maxFields;
		if (toolbar) {
			toolbar.hidden = rows.length < 7;
		}
	}

	addButton.addEventListener('click', function () {
		if (container.children.length >= config.maxFields) {
			return;
		}
		var holder = document.createElement('div');
		holder.innerHTML = template.innerHTML.replace(/__INDEX__/g, String(container.children.length));
		var row = holder.firstElementChild;
		container.appendChild(row);
		row.querySelector('[name$="[name]"]').value = 'field_' + identity().slice(2);
		reindex();
		row.open = true;
		row.querySelector('.af-label-input').focus();
		announce(__('Field added. Enter its label.', 'accessible-forms-by-accessible-org'));
	});

	container.addEventListener('input', function (event) {
		var row = event.target.closest('.af-field-row');
		if (row) {
			updateRow(row, event.target.matches('.af-type'));
			if (event.target.matches('.af-label-input')) {
				labelRowControls(row, Array.from(container.children).indexOf(row), container.children.length);
			}
		}
	});

	container.addEventListener('click', function (event) {
		var button = event.target.closest('button');
		if (!button || button.getAttribute('aria-disabled') === 'true') {
			return;
		}
		var row = button.closest('.af-field-row');
		if (!row) {
			return;
		}
		if (button.matches('.af-add-choice')) {
			addChoice(row, '');
			reindex();
			row.querySelector('.af-choice-rows').lastElementChild.querySelector('.af-choice-label').focus();
			return;
		}
		if (button.matches('.af-remove-choice')) {
			var choice = button.closest('.af-choice-row');
			if (choice.parentNode.children.length <= 2) {
				return;
			}
			var neighbor = choice.nextElementSibling || choice.previousElementSibling;
			choice.remove();
			reindex();
			neighbor.querySelector('.af-choice-label').focus();
			return;
		}
		if (button.matches('.af-paste-choice-list')) {
			var paste = row.querySelector('.af-options-row textarea');
			var labels = paste.value
				.split(/\r?\n/)
				.map(function (value) {
					return value.trim();
				})
				.filter(Boolean);
			row.querySelectorAll('.af-choice-row').forEach(function (choice) {
				if (
					!choice.querySelector('.af-choice-label').value.trim() &&
					row.querySelectorAll('.af-choice-row').length > 1
				) {
					choice.remove();
				}
			});
			labels.forEach(function (label) {
				var empty = Array.from(row.querySelectorAll('.af-choice-label')).find(function (input) {
					return !input.value.trim();
				});
				if (empty) {
					empty.value = label;
				} else {
					addChoice(row, label);
				}
			});
			paste.value = '';
			reindex();
			return;
		}
		if (button.matches('.af-duplicate-field')) {
			if (container.children.length >= config.maxFields) {
				return;
			}
			var clone = row.cloneNode(true);
			var originals = row.querySelectorAll('input,select,textarea');
			clone.querySelectorAll('input,select,textarea').forEach(function (input, index) {
				input.value = originals[index].value;
				input.checked = originals[index].checked;
			});
			clone.querySelector('[name$="[uid]"]').value = '';
			clone.querySelector('[name$="[name]"]').readOnly = false;
			clone.querySelector('[name$="[name]"]').value =
				(row.querySelector('[name$="[name]"]').value || 'field').slice(0, 44) +
				'_copy_' +
				Date.now().toString(36);
			clone.querySelector('.af-label-input').value += ' ' + __('(copy)', 'accessible-forms-by-accessible-org');
			row.insertAdjacentElement('afterend', clone);
			clone.open = true;
			reindex();
			clone.querySelector('.af-label-input').focus();
			announce(__('Independent field copy added.', 'accessible-forms-by-accessible-org'));
		} else if (button.matches('.af-remove-field')) {
			removed = { row: row, index: Array.from(container.children).indexOf(row) };
			var next = row.nextElementSibling || row.previousElementSibling;
			row.remove();
			undoButton.hidden = false;
			reindex();
			(next ? next.querySelector('summary') : addButton).focus();
			announce(__('Field removed. Use Undo removal to restore it.', 'accessible-forms-by-accessible-org'));
		} else if (button.matches('.af-move-up, .af-move-down, .af-move-top, .af-move-bottom')) {
			if (isFiltering()) {
				announce(__('Clear the field search to reorder fields.', 'accessible-forms-by-accessible-org'));
				return;
			}
			if (button.matches('.af-move-up') && row.previousElementSibling) {
				container.insertBefore(row, row.previousElementSibling);
			} else if (button.matches('.af-move-down') && row.nextElementSibling) {
				container.insertBefore(row.nextElementSibling, row);
			} else if (button.matches('.af-move-top')) {
				container.insertBefore(row, container.firstElementChild);
			} else if (button.matches('.af-move-bottom')) {
				container.appendChild(row);
			}
			reindex();
			// The row keeps its place in the DOM order it moved to; focus stays on the same control.
			button.focus();
			announce(
				sprintf(
					/* translators: 1: field label, 2: new position of the field, 3: number of fields. */
					__('“%1$s” moved to position %2$d of %3$d.', 'accessible-forms-by-accessible-org'),
					fieldLabel(row),
					Array.from(container.children).indexOf(row) + 1,
					container.children.length,
				),
			);
		}
	});

	undoButton.addEventListener('click', function () {
		if (!removed || container.children.length >= config.maxFields) {
			return;
		}
		container.insertBefore(removed.row, container.children[removed.index] || null);
		removed.row.open = true;
		reindex();
		removed.row.querySelector('.af-label-input').focus();
		removed = null;
		undoButton.hidden = true;
		announce(__('Field restored.', 'accessible-forms-by-accessible-org'));
	});

	function identity() {
		var bytes = new Uint8Array(8);
		if (window.crypto && crypto.getRandomValues) {
			crypto.getRandomValues(bytes);
			return (
				'o_' +
				Array.from(bytes, function (value) {
					return value.toString(16).padStart(2, '0');
				}).join('')
			);
		}
		return 'o_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
	}
	function indexChoices(row) {
		var base = row.querySelector('.af-label-input').name.replace(/\[label\]$/, '');
		row.querySelectorAll('.af-choice-row').forEach(function (choice, index) {
			var label = choice.querySelector('.af-choice-label'),
				value = choice.querySelector('.af-choice-value');
			label.name = base + '[choices][' + index + '][label]';
			value.name = base + '[choices][' + index + '][value]';
			if (!value.value) {
				value.value = identity();
			}
			label.id = row.querySelector('.af-label-input').id + '-choice-' + index;
			choice.querySelector('label').htmlFor = label.id;
			choice.querySelector('button').disabled = row.querySelectorAll('.af-choice-row').length <= 2;
		});
	}
	function addChoice(row, text) {
		var list = row.querySelector('.af-choice-rows');
		if (list.children.length >= 100) {
			announce(__('Use no more than 100 choices.', 'accessible-forms-by-accessible-org'));
			return;
		}
		var clone = list.firstElementChild.cloneNode(true);
		clone.querySelector('.af-choice-label').value = text;
		clone.querySelector('.af-choice-value').value = identity();
		list.appendChild(clone);
	}
	function refreshConditions() {
		var fields = Array.from(container.children).map(function (row) {
			return {
				row: row,
				key: row.querySelector('[name$="[name]"]').value,
				label: row.querySelector('.af-label-input').value,
				type: row.querySelector('.af-type').value,
			};
		});
		document
			.querySelectorAll('select[data-af-email-fields]')
			.forEach(function (select) {
				var selected = select.value,
					first = select.options[0].cloneNode(true);
				select.replaceChildren(first);
				fields
					.filter(function (field) {
						return field.type === 'email';
					})
					.forEach(function (field) {
						select.add(new Option(field.label, field.key));
					});
				if (
					selected &&
					!fields.some(function (field) {
						return field.type === 'email' && field.key === selected;
					})
				) {
					select.add(
						new Option(
							__('Removed email field — update this setting', 'accessible-forms-by-accessible-org'),
							selected,
						),
					);
				}
				select.value = selected;
			});
		document.querySelectorAll('[data-af-field-checks]').forEach(function (group) {
			var name = group.dataset.afFieldChecks,
				selected = Array.from(group.querySelectorAll('input:checked'), function (input) {
					return input.value;
				});
			group.replaceChildren();
			fields
				.filter(function (field) {
					return field.type !== 'section';
				})
				.forEach(function (field) {
					var label = document.createElement('label');
					label.className = 'af-inline-choice';
					var input = document.createElement('input');
					input.type = 'checkbox';
					input.name = name;
					input.value = field.key;
					input.checked = selected.indexOf(field.key) !== -1;
					label.appendChild(input);
					label.appendChild(document.createTextNode(' ' + field.label));
					group.appendChild(label);
				});
			selected
				.filter(function (key) {
					return !fields.some(function (field) {
						return field.key === key;
					});
				})
				.forEach(function (key) {
					var label = document.createElement('label');
					label.className = 'af-inline-choice';
					var input = document.createElement('input');
					input.type = 'checkbox';
					input.name = name;
					input.value = key;
					input.checked = true;
					label.appendChild(input);
					label.appendChild(
						document.createTextNode(
							' ' + __('Removed field — review this selection', 'accessible-forms-by-accessible-org'),
						),
					);
					group.appendChild(label);
				});
		});
		// Add-ons keep their own field lists, such as conditions, in step.
		document.dispatchEvent(new CustomEvent('af:fieldschange', { detail: { fields: fields } }));
	}
	document.querySelector('.af-builder').addEventListener('change', function (event) {
		if (event.target.closest('#af-fields')) {
			refreshConditions();
		}
	});

	// Reuse the same field controls for an independent starter template.
	document.querySelector('.af-builder').addEventListener('af:template', function (event) {
		container.replaceChildren();
		removed = null;
		undoButton.hidden = true;
		var schema = event.detail;
		schema.fields.forEach(function (field, index) {
			var holder = document.createElement('div');
			holder.innerHTML = template.innerHTML.replace(/__INDEX__/g, String(index));
			var row = holder.firstElementChild;
			Object.keys(field).forEach(function (key) {
				var input = row.querySelector('[name="af_schema[fields][' + index + '][' + key + ']"]');
				if (!input) {
					return;
				}
				if (input.type === 'checkbox') {
					input.checked = !!field[key];
				} else if (key === 'options') {
					input.value = field.options.join('\n');
				} else if (typeof field[key] !== 'object') {
					input.value = key === 'uid' ? '' : String(field[key]);
				}
			});
			row.querySelector('[name$="[autocomplete]"]').value = 'auto';
			row.open = false;
			container.appendChild(row);
			if (field.options && field.options.length) {
				var choices = row.querySelector('.af-choice-rows');
				while (choices.children.length < field.options.length) {
					addChoice(row, '');
				}
				Array.from(choices.children).forEach(function (choice, number) {
					choice.querySelector('.af-choice-label').value =
						(field.option_labels || {})[field.options[number]] || field.options[number] || '';
					choice.querySelector('.af-choice-value').value = field.options[number] || identity();
				});
			}
		});
		document.getElementById('af-heading').value = schema.heading;
		reindex();
		container.querySelectorAll('.af-field-row').forEach(function (row) {
			updateRow(row, false);
		});
		announce(__('Template fields added. Review them before publishing.', 'accessible-forms-by-accessible-org'));
	});

	// Browser validation must reveal a collapsed panel before focusing its input.
	document.getElementById('post').addEventListener(
		'invalid',
		function (event) {
			var parent = event.target.parentElement;
			while (parent) {
				if (parent.tagName === 'DETAILS') {
					parent.open = true;
				}
				parent = parent.parentElement;
			}
		},
		true,
	);
	var toolbar = document.createElement('div');
	toolbar.className = 'af-fields-toolbar';
	var searchLabel = document.createElement('label');
	searchLabel.htmlFor = 'af-find-field';
	searchLabel.textContent = __('Find a field', 'accessible-forms-by-accessible-org');
	var search = document.createElement('input');
	search.type = 'search';
	search.id = 'af-find-field';
	search.setAttribute('aria-describedby', 'af-find-field-note');
	var searchNote = document.createElement('p');
	searchNote.id = 'af-find-field-note';
	searchNote.className = 'description af-find-field-note';
	searchNote.textContent = __('Reordering is off while a search is active. Clear the search to move fields.', 'accessible-forms-by-accessible-org');
	searchNote.hidden = true;
	toolbar.appendChild(searchLabel);
	toolbar.appendChild(search);
	var searchTimer = 0;
	search.addEventListener('input', function () {
		var shown = 0;
		var query = search.value.trim().toLowerCase();
		Array.from(container.children).forEach(function (row) {
			row.hidden = row.querySelector('.af-label-input').value.toLowerCase().indexOf(query) === -1;
			if (!row.hidden) {
				shown++;
			}
		});
		searchNote.hidden = !query;
		labelAllRows();
		// Wait for a pause in typing so each keystroke does not interrupt.
		window.clearTimeout(searchTimer);
		searchTimer = window.setTimeout(function () {
			if (!query) {
				announce(__('Search cleared. All fields shown; reordering is on.', 'accessible-forms-by-accessible-org'));
				return;
			}
			announce(
				sprintf(
					/* translators: 1: number of fields matching the search, 2: total number of fields. */
					__('%1$d of %2$d fields shown. Reordering is off while searching.', 'accessible-forms-by-accessible-org'),
					shown,
					container.children.length,
				),
			);
		}, 500);
	});
	[true, false].forEach(function (open) {
		var button = document.createElement('button');
		button.type = 'button';
		button.className = 'button';
		button.textContent = open
			? __('Expand fields', 'accessible-forms-by-accessible-org')
			: __('Collapse fields', 'accessible-forms-by-accessible-org');
		button.addEventListener('click', function () {
			Array.from(container.children).forEach(function (row) {
				row.open = open;
			});
		});
		toolbar.appendChild(button);
	});
	toolbar.appendChild(searchNote);
	container.parentNode.insertBefore(toolbar, container);
	reindex();
})();
