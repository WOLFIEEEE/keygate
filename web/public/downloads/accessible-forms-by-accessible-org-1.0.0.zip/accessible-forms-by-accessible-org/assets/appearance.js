/* Live checks mirror Appearance.php; the server always validates saved colors. */
(function () {
	'use strict';
	var root = document.querySelector('.af-appearance');
	if (!root || !window.AccessibleFormsAppearance) {
		return;
	}
	var config = window.AccessibleFormsAppearance;
	var __ = window.wp.i18n.__;
	var sprintf = window.wp.i18n.sprintf;
	var hexFields = Array.from(root.querySelectorAll('.af-color-hex'));
	var themeCards = document.getElementById('af-theme-cards');
	// The theme cards are a radio group. Custom colors match no card, so none is checked.
	var preset = {
		get value() {
			var checked = themeCards.querySelector('.af-theme-radio:checked');
			return checked ? checked.value : 'custom';
		},
		set value(key) {
			themeCards.querySelectorAll('.af-theme-radio').forEach(function (radio) {
				radio.checked = radio.value === key;
			});
		},
	};
	// A setting is either a hidden input (the free editor) or a radio group an add-on renders.
	function control(name) {
		return (
			document.querySelector('input[type="radio"][name="' + name + '"]:checked') ||
			document.querySelector('[name="' + name + '"]:not([type="radio"])')
		);
	}
	function styleValues() {
		var values = {};
		['font_size', 'spacing', 'radius'].forEach(function (key) {
			var input = control('af_schema[appearance][' + key + ']');
			if (input) {
				values[key] = input.value;
			}
		});
		return values;
	}
	function setStyle(key, value) {
		var name = 'af_schema[appearance][' + key + ']';
		var radios = document.querySelectorAll('input[type="radio"][name="' + name + '"]');
		if (radios.length) {
			radios.forEach(function (radio) {
				radio.checked = radio.value === String(value);
			});
			return;
		}
		var input = control(name);
		if (input) {
			input.value = String(value);
		}
	}
	var preview = document.getElementById('af-appearance-preview');
	var status = document.getElementById('af-contrast-status');
	var results = document.getElementById('af-contrast-results');
	var hexPattern = /^#[a-fA-F0-9]{6}$/;
	root.querySelector('#af-preset-control').hidden = false;
	root.querySelector('.af-contrast-panel').hidden = false;

	function luminance(hex) {
		var channels = [1, 3, 5].map(function (offset) {
			var value = parseInt(hex.slice(offset, offset + 2), 16) / 255;
			return value <= 0.04045 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4);
		});
		return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
	}
	function contrast(first, second) {
		var a = luminance(first);
		var b = luminance(second);
		return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
	}
	function markChanged() {
		document.querySelector('.af-builder').dispatchEvent(new CustomEvent('af:change'));
	}
	function refresh() {
		// The guided editor promotes this group to a section after initialization.
		root = document.querySelector('.af-appearance');
		var colors = {};
		var errors = {};
		hexFields.forEach(function (input) {
			colors[input.dataset.color] = input.value;
			if (!hexPattern.test(input.value)) {
				errors[input.dataset.color] = __(
					'Enter a six-digit hex color, such as #ffffff.',
					'accessible-forms-by-accessible-org',
				);
			}
		});
		results.replaceChildren();
		config.rules.forEach(function (rule) {
			var item = document.createElement('li');
			var validHex =
				hexPattern.test(colors[rule.foreground]) && hexPattern.test(colors[rule.background]);
			if (validHex) {
				var ratio = contrast(colors[rule.foreground], colors[rule.background]);
				var passes = ratio >= rule.minimum;
				var ratioText = (Math.floor(ratio * 100) / 100).toFixed(2);
				/* translators: 1: color pair, 2: contrast ratio, 3: minimum contrast ratio. */
				var detail = sprintf(
					/* translators: 1: color pair, 2: measured contrast ratio, 3: minimum contrast ratio. */
					__('%1$s: %2$s:1 (minimum %3$s:1).', 'accessible-forms-by-accessible-org'),
					rule.label,
					ratioText,
					String(rule.minimum),
				);
				item.textContent =
					(passes ? __('Pass — ', 'accessible-forms-by-accessible-org') : __('Adjust — ', 'accessible-forms-by-accessible-org')) +
					detail;
				item.className = passes ? 'af-contrast-pass' : 'af-contrast-fail';
				if (!passes) {
					errors[rule.foreground] =
						detail +
						' ' +
						__('Choose a darker or lighter color before saving.', 'accessible-forms-by-accessible-org');
				}
			} else {
				/* translators: %s: color pair. */
				item.textContent = sprintf(
					/* translators: %s: color pair being checked. */
					__('%s: enter valid hex colors to check contrast.', 'accessible-forms-by-accessible-org'),
					rule.label,
				);
			}
			results.appendChild(item);
		});
		hexFields.forEach(function (input) {
			var error = errors[input.dataset.color] || '';
			input.setCustomValidity(error);
			if (error) {
				input.setAttribute('aria-invalid', 'true');
			} else {
				input.removeAttribute('aria-invalid');
			}
		});
		var valid = Object.keys(errors).length === 0;
		var message = valid
			? __('All color contrast checks pass.', 'accessible-forms-by-accessible-org')
			: __(
					'Adjust your colors before saving. The preview keeps the last passing palette.',
					'accessible-forms-by-accessible-org',
				);
		if (status.textContent !== message) {
			status.textContent = message;
		}
		if (!valid) {
			root.querySelector('.af-contrast-details').open = true;
		}
		// Add-ons with colour controls offer suggestions and keep pickers in step.
		root.dispatchEvent(
			new CustomEvent('af:contrast', {
				bubbles: true,
				detail: { colors: colors, valid: valid, errors: errors },
			}),
		);
		if (valid) {
			Object.keys(colors).forEach(function (key) {
				preview.style.setProperty('--af-' + key.replace(/_/g, '-'), colors[key]);
			});
		}
		var styles = styleValues();
		Object.keys(styles).forEach(function (key) {
			var value = key === 'font_size' ? Number(styles[key]) / 16 + 'rem' : styles[key] + 'px';
			preview.style.setProperty('--af-' + key.replace(/_/g, '-'), value);
		});
	}
	hexFields.forEach(function (input) {
		input.addEventListener('input', function () {
			preset.value = 'custom';
			refresh();
		});
	});
	themeCards.addEventListener('change', function () {
		var theme = config.presets[preset.value];
		if (theme) {
			hexFields.forEach(function (input) {
				input.value = theme.colors[input.dataset.color];
			});
			['font_size', 'spacing', 'radius'].forEach(function (key) {
				if (theme.colors[key]) {
					setStyle(key, theme.colors[key]);
				}
			});
			refresh();
			markChanged();
		}
	});
	// Width and button alignment live with the other Style controls; mirror
	// them in the preview so every layout choice is visible before saving.
	function layoutValue(key, fallback) {
		var input = control('af_schema[layout][' + key + ']');
		return input ? input.value : fallback;
	}
	function syncLayout() {
		preview.className = preview.className.replace(/\baf-(width|button|labels)-[a-z]+\b/g, '').trim();
		preview.classList.add('af-width-' + layoutValue('width', 'comfortable'));
		preview.classList.add('af-button-' + layoutValue('button', 'start'));
		preview.classList.add('af-labels-' + layoutValue('labels', 'above'));
	}
	document.addEventListener('change', function (event) {
		var name = event.target.name || '';
		if (name.indexOf('af_schema[appearance][') === 0 && event.target.type === 'radio') {
			refresh();
		}
		if (name.indexOf('af_schema[layout][') === 0) {
			syncLayout();
		}
	});
	syncLayout();
	// Fit shrinks the preview until the whole form shows; zooming in scrolls the stage.
	// CSS zoom keeps layout and scrolling honest, where a transform would leave gaps.
	var stage = root.querySelector('.af-preview-stage');
	var zoomBar = root.querySelector('.af-preview-zoom');
	if (stage && zoomBar && window.CSS && CSS.supports('zoom', '0.5') && window.ResizeObserver) {
		var zoomSteps = [0.5, 0.67, 0.75, 0.9, 1, 1.1, 1.25, 1.5, 2];
		var fitButton = zoomBar.querySelector('.af-zoom-fit');
		var zoomOut = zoomBar.querySelector('.af-zoom-out');
		var zoomIn = zoomBar.querySelector('.af-zoom-in');
		var zoomLevel = zoomBar.querySelector('.af-zoom-level');
		var fitting = true,
			zoom = 1,
			zoomFrame = 0;
		zoomBar.hidden = false;
		stage.classList.add('af-preview-stage--zoomable');
		// The stage scrolls when zoomed in, so it must be reachable by keyboard.
		stage.tabIndex = 0;
		stage.setAttribute('role', 'region');
		stage.setAttribute('aria-label', stage.dataset.label);
		function stageBox() {
			var styles = getComputedStyle(stage);
			return {
				width: stage.clientWidth - parseFloat(styles.paddingLeft) - parseFloat(styles.paddingRight),
				height: stage.clientHeight - parseFloat(styles.paddingTop) - parseFloat(styles.paddingBottom),
			};
		}
		function applyZoom() {
			var box = stageBox();
			if (box.width <= 0) {
				return;
			}
			// Lay the form out at the stage's own width at every zoom level, so zooming
			// never reflows it into a different layout than visitors would see.
			preview.style.width = box.width + 'px';
			if (fitting) {
				preview.style.zoom = 1;
				var natural = preview.getBoundingClientRect().height;
				// Scaled controls round to device pixels independently. Leave a small
				// allowance so those rounded heights do not create a scrollbar in Fit.
				var available = Math.max(1, box.height - 4);
				zoom = natural > available ? Math.max(0.3, Math.floor((available / natural) * 100) / 100) : 1;
			}
			preview.style.zoom = zoom;
			if (fitting) {
				// Measure the scaled result too: native controls can add rounding
				// beyond the estimate from the unscaled form. Keep corrections bounded.
				for (var correction = 0; correction < 3 && zoom > 0.3; correction++) {
					var scaled = preview.getBoundingClientRect().height;
					if (scaled <= available) {
						break;
					}
					zoom = Math.max(0.3, Math.floor((zoom * available / scaled) * 100) / 100);
					preview.style.zoom = zoom;
				}
			}
			var label = Math.round(zoom * 100) + '%';
			if (zoomLevel.textContent !== label) {
				zoomLevel.textContent = label;
			}
			fitButton.setAttribute('aria-pressed', fitting ? 'true' : 'false');
			zoomOut.disabled = zoom <= zoomSteps[0];
			zoomIn.disabled = zoom >= zoomSteps[zoomSteps.length - 1];
		}
		// A timer rather than an animation frame: frames can stall in background tabs.
		function scheduleZoom() {
			window.clearTimeout(zoomFrame);
			zoomFrame = window.setTimeout(applyZoom, 30);
		}
		function step(direction) {
			var next =
				direction > 0
					? zoomSteps.find(function (value) {
							return value > zoom + 0.001;
						})
					: zoomSteps
							.slice()
							.reverse()
							.find(function (value) {
								return value < zoom - 0.001;
							});
			if (next) {
				fitting = false;
				zoom = next;
				applyZoom();
			}
		}
		zoomIn.addEventListener('click', function () {
			step(1);
		});
		zoomOut.addEventListener('click', function () {
			step(-1);
		});
		fitButton.addEventListener('click', function () {
			fitting = true;
			stage.scrollTo(0, 0);
			applyZoom();
		});
		// Refit when the stage resizes or the preview's content changes height.
		var observer = new ResizeObserver(function () {
			if (fitting) {
				scheduleZoom();
			}
		});
		observer.observe(stage);
		observer.observe(preview.querySelector('.af-style-preview-body') || preview);
		// The editor swaps in a server-rendered preview of the real fields; refit then too.
		new MutationObserver(function () {
			if (fitting) {
				scheduleZoom();
			}
		}).observe(preview, { childList: true, subtree: true });
		// Colors, text size and layout changes all alter the preview's height.
		root.addEventListener('change', scheduleZoom);
		scheduleZoom();
	}
	// Add-on style controls build on these.
	window.AccessibleFormsStyle = {
		refresh: refresh,
		markChanged: markChanged,
		preset: preset,
		contrast: contrast,
		setStyle: setStyle,
		styleValues: styleValues,
		hexFields: hexFields,
		themeCards: themeCards,
		config: config,
	};
	refresh();
})();
