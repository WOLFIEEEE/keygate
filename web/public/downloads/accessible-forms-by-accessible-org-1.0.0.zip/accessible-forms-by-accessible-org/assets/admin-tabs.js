/** Progressive admin navigation. Links remain usable without scripts. */
(function () {
	'use strict';
	var root = document.querySelector('[data-af-tabs]');
	if (!root || !window.fetch || !window.AbortController || !window.DOMParser || !window.history.pushState) { return; }
	var nav = root.querySelector('.nav-tab-wrapper');
	var panel = root.querySelector('[data-af-tab-content]');
	var active = nav && nav.querySelector('[data-af-tab][aria-current="page"]');
	// An unprepared add-on panel keeps its original page navigation.
	if (!panel || !active) { return; }
	var __ = wp.i18n.__, sprintf = wp.i18n.sprintf;
	var links = Array.from(nav.querySelectorAll('[data-af-tab]'));
	var panes = new Map(), baselines = new WeakMap();
	var current, submitting = false, displayedUrl = window.location.href;
	var status = document.createElement('p');
	status.className = 'af-tab-status';
	status.setAttribute('role', 'status');
	status.setAttribute('aria-atomic', 'true');
	status.hidden = true;
	nav.after(status);
	var recovery = document.createElement('p');
	recovery.hidden = true;
	var retry = document.createElement('button');
	retry.type = 'button'; retry.className = 'button';
	retry.textContent = __('Try again', 'accessible-forms-by-accessible-org');
	var open = document.createElement('a');
	open.className = 'button';
	open.textContent = __('Open this section as a full page', 'accessible-forms-by-accessible-org');
	recovery.append(retry, document.createTextNode(' '), open);
	status.after(recovery);
	var saveStatus = document.createElement('p');
	saveStatus.className = 'af-settings-save-status';
	saveStatus.setAttribute('role', 'status');
	saveStatus.setAttribute('aria-atomic', 'true');
	recovery.after(saveStatus);
	function updatePending() {
		links.forEach(function (link, index) {
			var pane = panes.get(address(link.href)), pending = pane && dirty(pane.node);
			var label = link.querySelector('.af-pending-label');
			if (pending && !label) {
				label = document.createElement('span'); label.className = 'af-pending-label';
				label.id = 'af-tab-pending-' + index; label.setAttribute('aria-hidden', 'true');
				label.textContent = __('Pending changes', 'accessible-forms-by-accessible-org'); link.append(label);
				link.setAttribute('aria-describedby', ((link.getAttribute('aria-describedby') || '') + ' ' + label.id).trim());
			}
			if (!pending && label) {
				var description = (link.getAttribute('aria-describedby') || '').split(/\s+/).filter(function (id) { return id !== label.id; }).join(' ');
				if (description) { link.setAttribute('aria-describedby', description); } else { link.removeAttribute('aria-describedby'); }
				label.remove();
			}
		});
		var message = dirty(panel) ? __('Unsaved changes in this section.', 'accessible-forms-by-accessible-org') : __('No unsaved changes in this section.', 'accessible-forms-by-accessible-org');
		if (otherEdits()) { message += ' ' + __('Another section has unsaved changes.', 'accessible-forms-by-accessible-org'); }
		if (saveStatus.textContent !== message) { saveStatus.textContent = message; }
	}
	root.addEventListener('input', updatePending);
	root.addEventListener('change', updatePending);


	function address(value) {
		var url = new URL(value, window.location.href);
		url.hash = '';
		return url.href;
	}
	function linkFor(url) {
		return links.find(function (link) { return address(link.href) === address(url); });
	}
	function snapshot(form) {
		return JSON.stringify(Array.from(new FormData(form), function (item) {
			return [item[0], typeof item[1] === 'string' ? item[1] : (item[1].name ? [item[1].name, item[1].size, item[1].lastModified] : ['', 0])];
		}));
	}
	function forms(pane) { return Array.from(pane.querySelectorAll('form')).filter(function (form) { return form.method.toLowerCase() === 'post'; }); }
	function remember(pane) { forms(pane).forEach(function (form) { baselines.set(form, snapshot(form)); }); }
	function dirty(pane) { return forms(pane).some(function (form) { return baselines.has(form) && baselines.get(form) !== snapshot(form); }); }
	function otherEdits() { return Array.from(panes.values()).some(function (saved) { return saved.node !== panel && dirty(saved.node); }); }
	function allEdits() { return otherEdits() || dirty(panel); }
	function notify(message) { status.hidden = false; status.textContent = message; }
	function state(url) {
		return Object.assign({}, window.history.state, { accessibleFormsTabs: { screen: root.dataset.afTabs, url: url } });
	}
	function cancel() {
		if (current) { current.controller.abort(); window.clearTimeout(current.timer); current = null; }
		panel.removeAttribute('aria-busy');
	}
	function focusPanel() {
		var heading = panel.querySelector('h2, h3') || panel;
		heading.tabIndex = -1;
		heading.focus();
	}
	function activate(saved, link, url, fromHistory) {
		panel.replaceWith(saved.node);
		panel = saved.node;
		active = link;
		links.forEach(function (item) {
			item.classList.toggle('nav-tab-active', item === link);
			if (item === link) { item.setAttribute('aria-current', 'page'); }
			else { item.removeAttribute('aria-current'); }
		});
		document.title = saved.title;
		if (!fromHistory && address(window.location.href) !== address(url)) { window.history.pushState(state(url), '', url); }
		displayedUrl = url;
		panel.removeAttribute('aria-busy');
		status.textContent = ''; status.hidden = true; recovery.hidden = true;
		updatePending();
		focusPanel();
	}
	function assetKey(element, attribute) {
		var url = new URL(element.getAttribute(attribute), window.location.href);
		return element.id + '|' + url.origin + url.pathname + '|' + (url.searchParams.get('ver') || '');
	}
	function prepared(doc, incoming) {
		// Do not execute new scripts or silently insert panels with missing dependencies.
		if (incoming.querySelector('script, style, link[rel="stylesheet"]')) { return false; }
		return [['script[src]', 'src'], ['link[rel="stylesheet"][href]', 'href']].every(function (kind) {
			var loaded = new Set(Array.from(document.querySelectorAll(kind[0]), function (item) { return assetKey(item, kind[1]); }));
			return Array.from(doc.querySelectorAll(kind[0])).every(function (item) { return loaded.has(assetKey(item, kind[1])); });
		}) && Array.from(doc.querySelectorAll('script[id]:not([src])')).every(function (item) { return !!document.getElementById(item.id); });
	}

	async function navigate(link, url, fromHistory) {
		// WordPress may move an initial save notice above the section on ready.
		document.querySelectorAll('[data-af-tab-notice]').forEach(function (notice) { if (!panel.contains(notice)) { panel.prepend(notice); } });
		cancel(); recovery.hidden = true;
		var cached = panes.get(address(link.href));
		if (link === active && !fromHistory) { status.hidden = true; return; }
		if (cached && (!link.hasAttribute('data-af-tab-refresh') || dirty(cached.node))) { activate(cached, link, url, fromHistory); return; }
		var request = { controller: new AbortController() };
		current = request;
		panel.setAttribute('aria-busy', 'true');
		/* translators: %s: name of an admin section. */
		notify(sprintf(__('Loading %s…', 'accessible-forms-by-accessible-org'), link.textContent.trim()));
		try {
			var deadline = new Promise(function (resolve, reject) {
				request.timer = window.setTimeout(function () { request.controller.abort(); reject(new Error('timeout')); }, 15000);
			});
			var result = await Promise.race([
				fetch(url, { credentials: 'same-origin', cache: 'no-store', signal: request.controller.signal }).then(async function (response) {
					if (!response.ok || !/text\/html/i.test(response.headers.get('content-type') || '') || address(response.url) !== address(url)) { throw new Error('response'); }
					return new DOMParser().parseFromString(await response.text(), 'text/html');
				}), deadline,
			]);
			if (current !== request || request.controller.signal.aborted) { return; }
			var screen = result.querySelector('[data-af-tabs]');
			var incoming = screen && screen.querySelector('[data-af-tab-content]');
			var selected = screen && screen.querySelector('.nav-tab-wrapper [data-af-tab][aria-current="page"]');
			if (!incoming || screen.dataset.afTabs !== root.dataset.afTabs || !selected || address(selected.href) !== address(link.href)) { throw new Error('screen'); }
			if (!prepared(result, incoming)) { throw new Error('dependencies'); }
			var saved = { node: document.importNode(incoming, true), title: result.title };
			// Initializers use scoped nodes and run once; cached panels retain listeners and edits.
			panel.replaceWith(saved.node); panel = saved.node;
			document.dispatchEvent(new CustomEvent('af:panelready', { detail: { root: panel } }));
			remember(panel);
			panes.set(address(link.href), saved);
			activate(saved, link, url, fromHistory);
		} catch (error) {
			if (current !== request) { return; }
			notify(error.message === 'dependencies'
				? __('This section needs a full page load. Your current section and edits are kept.', 'accessible-forms-by-accessible-org')
				: __('This section could not be loaded. Your current section and edits are kept. Try again or open it as a full page.', 'accessible-forms-by-accessible-org'));
			retry.hidden = error.message === 'dependencies';
			open.href = url;
			recovery.hidden = false;
			if (fromHistory) {
				// Keep the address truthful if a Back/Forward request cannot be displayed.
				window.history.replaceState(state(displayedUrl), '', displayedUrl);
			}
		} finally {
			window.clearTimeout(request.timer);
			if (current === request) { current = null; panel.removeAttribute('aria-busy'); }
		}
	}
	remember(panel);
	panes.set(address(active.href), { node: panel, title: document.title });
	// Preserve the original URL (including a saved notice or search) for browser Back.
	panes.set(address(window.location.href), panes.get(address(active.href)));
	window.history.replaceState(state(window.location.href), '', window.location.href);
	root.dataset.afTabsReady = 'true';
	updatePending();
	nav.addEventListener('click', function (event) {
		var link = event.target.closest('a[data-af-tab]');
		if (!link || !nav.contains(link) || event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || (link.target && link.target !== '_self') || link.hasAttribute('download')) { return; }
		if (new URL(link.href).origin !== window.location.origin) { return; }
		event.preventDefault();
		navigate(link, link.href, false);
	});
	retry.addEventListener('click', function () { var link = linkFor(open.href); if (link) { navigate(link, open.href, false); } });
	window.addEventListener('popstate', function (event) {
		var savedState = event.state && event.state.accessibleFormsTabs;
		if (!savedState || savedState.screen !== root.dataset.afTabs) { return; }
		if (address(window.location.href) === address(displayedUrl)) { displayedUrl = window.location.href; return; }
		var link = linkFor(window.location.href);
		if (!link && panes.has(address(window.location.href))) { link = links.find(function (item) { return panes.get(address(item.href)) === panes.get(address(window.location.href)); }); }
		if (link) { navigate(link, window.location.href, true); }
	});
	root.addEventListener('submit', function (event) {
		var form = event.target;
		if (event.defaultPrevented || form.method.toLowerCase() !== 'post' || form.target) { return; }
		var action = form.querySelector('[name="action"]'), operation = form.querySelector('[name="operation"]');
		if (operation && ['diagnostics', 'export'].includes(operation.value)) { return; }
		if (otherEdits() && !window.confirm(__('Other sections have unsaved changes. Continuing will discard those edits. Continue?', 'accessible-forms-by-accessible-org'))) { event.preventDefault(); return; }
		submitting = true;
	});
	window.addEventListener('beforeunload', function (event) { if (!submitting && allEdits()) { event.preventDefault(); event.returnValue = ''; } });
	window.addEventListener('pageshow', function () { submitting = false; });
})();
