/** Placement screen: insert-position links and shortcode copying. */
(function () {
	'use strict';
	var __ = wp.i18n.__;
	var ready = new WeakSet();
	function initPlacement(root) {
		var initialPosition = root.querySelector('#af-insert-position');
		if (initialPosition) {
			if (ready.has(initialPosition)) { return; }
			ready.add(initialPosition);
			initialPosition.addEventListener('change', function () {
				root.querySelectorAll('.af-page-choices a').forEach(function (link) {
					var url = new URL(link.href);
					if (url.searchParams.has('af_insert_form')) { url.searchParams.set('af_position', initialPosition.value); link.href = url.href; }
				});
			});
		}
		var copy = root.querySelector('#af-copy-placement-shortcode');
		if (copy) {
			if (ready.has(copy)) { return; }
			ready.add(copy);
			copy.addEventListener('click', async function () {
				var input = root.querySelector('#af-placement-shortcode');
				var status = root.querySelector('#af-placement-copy-status');
				try { await navigator.clipboard.writeText(input.value); status.textContent = __('Shortcode copied.', 'accessible-forms-by-accessible-org'); }
				catch (error) { input.focus(); input.select(); status.textContent = __('Shortcode selected. Copy it using your keyboard.', 'accessible-forms-by-accessible-org'); }
			});
		}
	}
	initPlacement(document);
	document.addEventListener('af:panelready', function (event) { initPlacement(event.detail.root); });
})();
