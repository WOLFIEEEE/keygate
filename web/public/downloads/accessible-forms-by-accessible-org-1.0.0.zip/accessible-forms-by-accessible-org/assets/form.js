/**
 * Progressive enhancement.
 *
 * The form works without this file: it posts, the page re-renders with errors,
 * and focus moves to the summary. This script removes the page reload so a
 * visitor who submits a footer form is not thrown to the top of the document —
 * a context change that is disorienting for everyone and especially costly for
 * screen reader and screen magnifier users.
 *
 * Focus behaviour is identical on both paths.
 */
(function () {
	'use strict';
	var __ =
		window.wp && window.wp.i18n
			? window.wp.i18n.__
			: function (text) {
					return text;
				};

	function focusTarget(id) {
		var el = document.getElementById(id);

		if (!el) {
			return;
		}

		el.focus({ preventScroll: true });

		if (el.scrollIntoView) {
			el.scrollIntoView({ block: 'center', behavior: 'instant', inline: 'nearest' });
		}
	}

	/** Keep keyboard focus clear of fixed/sticky overlays without changing focus or the theme. */
	function uncoverFocus(el) {
		if (!el.isConnected || document.activeElement !== el || el.closest('.af-live-checking')) { return; }
		var rect = el.getBoundingClientRect();
		if (!rect.width || !rect.height) { return; }
		var viewport = window.visualViewport;
		var top = viewport ? viewport.offsetTop : 0;
		var bottom = top + (viewport ? viewport.height : window.innerHeight);
		var samples = [0.2, 0.5, 0.8].map(function (fraction) {
			return document.elementFromPoint(rect.left + rect.width / 2, Math.max(top + 1, Math.min(bottom - 1, rect.top + rect.height * fraction)));
		});
		var owner = el.closest('.af-field-container') || el;
		if (rect.top >= top + 8 && rect.bottom <= bottom - 8 && samples.every(function (hit) { return !hit || owner.contains(hit) || hit.contains(el); })) { return; }
		var safeTop = top + 12, safeBottom = bottom - 12;
		var overlays = [];
		samples.forEach(function (hit) {
			if (!hit || owner.contains(hit) || hit.contains(el)) { return; }
			for (var node = hit; node && node !== document.body; node = node.parentElement) {
				var position = window.getComputedStyle(node).position;
				if (position === 'fixed' || position === 'sticky') {
					if (overlays.indexOf(node) !== -1) { break; }
					overlays.push(node);
					var cover = node.getBoundingClientRect();
					if (cover.top <= top + 1) { safeTop = Math.max(safeTop, cover.bottom + 12); }
					else if (cover.bottom >= bottom - 1) { safeBottom = Math.min(safeBottom, cover.top - 12); }
					else if (cover.top - safeTop >= rect.height) { safeBottom = Math.min(safeBottom, cover.top - 12); }
					else { safeTop = Math.max(safeTop, cover.bottom + 12); }
					break;
				}
			}
		});
		if (safeBottom - safeTop < rect.height) { return; }
		if (rect.top < safeTop || rect.bottom > safeBottom || overlays.length) {
			window.scrollBy({ top: rect.top - (safeTop + (safeBottom - safeTop - rect.height) / 2), left: 0, behavior: 'instant' });
		}
	}
	document.addEventListener('focusin', function (event) {
		var el = event.target;
		if (!el.closest || !el.closest('.af-wrap')) { return; }
		window.requestAnimationFrame(function () { uncoverFocus(el); });
	});

	/**
	 * Events add-ons listen for, dispatched on the form and bubbling to the
	 * document. See docs/EXTENSIONS.md.
	 *
	 * @return {boolean} False when a listener cancelled a cancelable event.
	 */
	function emit(target, name, detail, cancelable) {
		return target.dispatchEvent(
			new CustomEvent(name, { bubbles: true, cancelable: !!cancelable, detail: detail || {} }),
		);
	}

	/** A field's label without its "(required)" hint, ready to prefix a message. */
	function labelText(input) {
		// A radio or checkbox in a group is named by the group's legend: its own
		// label is only one of the options.
		var group = input.closest('fieldset.af-field');
		var legend = group && group.querySelector('.af-legend');
		var source = legend || (input.labels && input.labels[0]);
		if (!source) {
			return '';
		}
		var label = source.cloneNode(true);
		label.querySelectorAll('.af-req').forEach(function (hint) {
			hint.remove();
		});
		return label.textContent.trim() + ': ';
	}

	/**
	 * Problems found before sending, listed like the server's error summary
	 * with links to each field. Focus moves to it, so it has no live-region
	 * role. Returns false (after removing any earlier list) when there are none.
	 */
	function clientSummary(form, heading, problems) {
		var previous = form.querySelector('.af-client-summary');
		if (previous) {
			previous.remove();
		}
		if (!problems.length) {
			if (previous) { emit(form, 'af:statechange', { state: 'answers-corrected' }); }
			return false;
		}
		// The server's summary from an earlier attempt is out of date now and
		// would list a second, contradicting set of problems.
		var wrap = form.closest('.af-wrap');
		wrap.querySelectorAll('.af-summary:not(.af-client-summary)').forEach(function (stale) {
			stale.remove();
		});
		var summary = document.createElement('div');
		summary.className = 'af-summary af-client-summary';
		summary.tabIndex = -1;
		// A real heading one level below the form's, matching the server's summary.
		var formHeading = form.closest('.af-wrap').querySelector('.af-heading');
		var level = formHeading && /^H[1-6]$/.test(formHeading.tagName) ? Math.min(6, Number(formHeading.tagName[1]) + 1) : 2;
		var title = document.createElement('h' + level);
		title.className = 'af-summary__heading';
		title.textContent = heading;
		summary.appendChild(title);
		var list = document.createElement('ul');
		list.className = 'af-summary__list';
		problems.forEach(function (problem) {
			var item = document.createElement('li');
			var link = document.createElement('a');
			link.href = '#' + problem.input.id;
			link.textContent = problem.message;
			item.appendChild(link);
			list.appendChild(item);
		});
		summary.appendChild(list);
		form.insertBefore(summary, form.querySelector('.af-progress, .af-field-container'));
		summary.focus();
		emit(form, 'af:statechange', { state: 'validation-errors' });
		return true;
	}

	function enhance(form, wrap) {
		// Summary links (from the server or from this script) focus the answer
		// directly: browsers differ in whether following an in-page link focuses
		// a control (Firefox does not for time fields, for example).
		wrap.addEventListener('click', function (event) {
			var link = event.target.closest && event.target.closest('.af-summary a[href^="#"]');
			if (!link) {
				return;
			}
			var input = document.getElementById(decodeURIComponent(link.hash.slice(1)));
			if (!input) {
				return;
			}
			// Add-ons first show the answer, such as by opening its step.
			emit(form, 'af:reveal', { wrap: wrap, input: input });
			event.preventDefault();
			focusTarget(input.id);
		});
		form.querySelectorAll('[data-af-count]').forEach(function (input) {
			var count = document.createElement('p');
			count.className = 'af-help';
			count.id = input.id + '-count';
			input.insertAdjacentElement('afterend', count);
			input.setAttribute(
				'aria-describedby',
				(input.getAttribute('aria-describedby') || '') + ' ' + count.id,
			);
			function update() {
				count.textContent = window.wp.i18n.sprintf(
					/* translators: 1: characters used, 2: character limit. */
					__('%1$d of %2$d characters', 'accessible-forms-by-accessible-org'),
					Array.from(input.value).length,
					Number(input.dataset.afCount),
				);
			}
			input.addEventListener('input', update);
			update();
		});
	}

	// Helpers for add-ons that check answers before sending, as this script does.
	async function requestJSON(url, options) {
		var controller = new AbortController(), timer;
		var deadline = new Promise(function (resolve, reject) {
			timer = window.setTimeout(function () { controller.abort(); reject(new Error('Request timed out')); }, 15000);
		});
		try {
			return await Promise.race([
				fetch(url, Object.assign({}, options, { signal: controller.signal })).then(async function (response) {
					return { response: response, data: await response.json() };
				}), deadline,
			]);
		} finally {
			window.clearTimeout(timer);
		}
	}
	window.AccessibleFormsFront = { summary: clientSummary, labelText: labelText, focus: focusTarget, requestJSON: requestJSON };

	/**
	 * Floating labels rest inside an empty text field. Mark empty fields so
	 * the stylesheet can lower their label; everything else keeps it raised.
	 */
	function floatingLabels(wrap) {
		if (!wrap.classList.contains('af-labels-floating')) {
			return;
		}
		var inputs = Array.from(wrap.querySelectorAll('.af-field input.af-input, .af-field textarea.af-input')).filter(
			function (input) {
				return ['date', 'time', 'file', 'hidden', 'checkbox', 'radio'].indexOf(input.type) === -1;
			},
		);
		function sync() {
			inputs.forEach(function (input) {
				input.classList.toggle('af-empty', '' === input.value);
			});
		}
		inputs.forEach(function (input) {
			input.addEventListener('input', sync);
			input.addEventListener('change', sync);
		});
		wrap.afSyncLabels = sync;
		sync();
	}

	/**
	 * After a successful send the answered form stays hidden. Without this
	 * script a link reloads the page; with it, a button reveals a fresh form
	 * in place and moves focus to its first question.
	 */
	function sendAnother(wrap, form) {
		var link = wrap.querySelector('a.af-send-another');
		if (!link || !form) {
			return;
		}
		var button = document.createElement('button');
		button.type = 'button';
		button.className = 'af-send-another';
		button.textContent = link.textContent;
		link.replaceWith(button);
		button.addEventListener('click', function () {
			var status = wrap.querySelector('.af-status');
			if (status) {
				status.remove();
			}
			button.closest('.af-another').remove();
			form.hidden = false;
			var first = form.querySelector(
				'.af-field-container:not([hidden]) input:not([type="hidden"]):not(:disabled), .af-field-container:not([hidden]) select:not(:disabled), .af-field-container:not([hidden]) textarea:not(:disabled)',
			);
			if (first) {
				first.focus();
			}
		});
	}

	function bind(wrap) {
		floatingLabels(wrap);
		var form = wrap.querySelector('.af-form');
		sendAnother(wrap, form);

		if (!form || form.dataset.afBound || !window.fetch) {
			return;
		}

		form.dataset.afBound = '1';
		if (form.dataset.afTest === '1') {
			form.querySelectorAll('[data-af-test-file]').forEach(function (input) { input.disabled = false; });
		}
		var request = form.querySelector('[name="af_request"]');
		if (request && window.crypto && window.crypto.getRandomValues) {
			var bytes = new Uint8Array(16);
			window.crypto.getRandomValues(bytes);
			request.value = Array.from(bytes, function (byte) {
				return byte.toString(16).padStart(2, '0');
			}).join('');
		}
		enhance(form, wrap);
		emit(form, 'af:enhance', { wrap: wrap });

		var button = form.querySelector('.af-submit');
		var label = button ? button.textContent : '';
		// A polite region, never focused, so "Sending" is heard exactly once.
		var sending = form.querySelector('.af-submit-status');

		// aria-disabled rather than disabled keeps keyboard focus on the button.
		function idle() {
			delete form.dataset.afSending;
			if (button) {
				button.removeAttribute('aria-disabled');
				button.textContent = label;
			}
			if (sending) {
				sending.textContent = '';
			}
		}

		form.addEventListener('submit', async function (event) {
			event.preventDefault();
			if (form.dataset.afSending) {
				return;
			}
			wrap.querySelector('.af-network-error').hidden = true;
			// A listener that cancels this shows its own explanation.
			if (!emit(form, 'af:validate', { wrap: wrap }, true)) {
				return;
			}
			form.dataset.afSending = '1';

			if (button) {
				button.setAttribute('aria-disabled', 'true');
				button.textContent = __('Sending…', 'accessible-forms-by-accessible-org');
			}
			if (sending) {
				sending.textContent = __('Sending your response…', 'accessible-forms-by-accessible-org');
			}

			var verification = form.querySelector('accessible-forms-altcha');
			if (
				verification &&
				typeof verification.verify === 'function' &&
				verification.getState() !== 'verified'
			) {
				// The spam check runs in this browser; say so if it takes a while.
				var slow = window.setTimeout(function () {
					if (sending) {
						sending.textContent = __(
							'Still checking that this is not an automated message. This can take a few seconds…',
							'accessible-forms-by-accessible-org',
						);
					}
				}, 3000);
				// Let an automatic check finish; never start two workers for one submit.
				if (verification.getState() === 'verifying') {
					await new Promise(function (resolve) {
						var timer = window.setTimeout(finish, 16000);
						function finish() {
							window.clearTimeout(timer);
							verification.removeEventListener('statechange', changed);
							resolve();
						}
						function changed(event) {
							if (event.detail.state !== 'verifying') {
								finish();
							}
						}
						verification.addEventListener('statechange', changed);
					});
				} else {
					try {
						await verification.verify();
					} catch (error) {
						/* The server holds unverified messages for review. */
					}
				}
				window.clearTimeout(slow);
			}
			// Add-ons may hold the send for asynchronous work, such as a verification token.
			var waits = [];
			emit(form, 'af:beforesubmit', {
				wrap: wrap,
				waitUntil: function (promise) {
					waits.push(promise);
				},
			});
			if (waits.length) {
				try {
					await Promise.all(waits);
				} catch (error) {
					idle();
					return;
				}
			}
			var data = new FormData(form);
			if (form.dataset.afTest === '1') {
				// A private preview validates filenames only. Never send file bytes.
				form.querySelectorAll('input[type="file"]').forEach(function (input) {
					data.delete(input.name);
					var field = input.closest('[data-field]');
					if (field && input.files && input.files.length && !input.disabled) {
						data.set('af[' + field.dataset.field + ']', input.files[0].name);
					}
				});
			}
			data.append('af_ajax', '1');
			var requestController = new AbortController();
			var requestTimer = window.setTimeout(function () {
				requestController.abort();
			}, 30000);

			window
				.fetch(form.action, {
					method: 'POST',
					body: data,
					credentials: 'same-origin',
					signal: requestController.signal,
					headers: { 'X-Requested-With': 'XMLHttpRequest' },
				})
				.then(function (response) {
					if (!response.ok) {
						throw new Error('Bad response');
					}
					return response.json();
				})
				.then(function (payload) {
					if (payload && payload.ok && payload.redirect) {
						var destination = new URL(payload.redirect, location.href);
						if (destination.origin === location.origin) {
							// Coming back to this page from history shows a usable button again.
							window.addEventListener(
								'pageshow',
								function (pageEvent) {
									if (pageEvent.persisted) {
										idle();
									}
								},
								{ once: true },
							);
							location.assign(destination.href);
							return;
						}
					}
					if (!payload || !payload.html) {
						throw new Error('Empty response');
					}

					var holder = document.createElement('div');
					holder.innerHTML = payload.html;

					var fresh = holder.firstElementChild;
					if (!fresh) {
						throw new Error('Unparseable response');
					}

					// Preserve the identity of this embed when the same form appears twice.
					var oldPrefix = fresh.dataset.afInstance;
					var newPrefix = wrap.dataset.afInstance;
					fresh
						.querySelectorAll('[id], [for], [href], [aria-describedby], [aria-labelledby]')
						.forEach(function (element) {
							['id', 'for', 'href', 'aria-describedby', 'aria-labelledby'].forEach(
								function (attr) {
									if (element.hasAttribute(attr)) {
										element.setAttribute(
											attr,
											element
												.getAttribute(attr)
												.split(oldPrefix + '-')
												.join(newPrefix + '-'),
										);
									}
								},
							);
						});
					fresh.dataset.afInstance = newPrefix;
					wrap.parentNode.replaceChild(fresh, wrap);

					bind(fresh);
					emit(fresh, 'af:rendered', { ok: !!payload.ok });

					var target = payload.focus
						? payload.focus.replace(oldPrefix, newPrefix)
						: (fresh.querySelector('.af-summary, .af-status') || {}).id;
					if (target) {
						focusTarget(target);
					}
				})
				.catch(function () {
					// A lost response may follow a successful insert: never silently POST again.
					idle();
					// Focus alone announces the message; it carries no live-region role.
					var networkError = wrap.querySelector('.af-network-error');
					networkError.hidden = false;
					networkError.focus();
				})
				.finally(function () {
					window.clearTimeout(requestTimer);
				});
		});
	}

	/**
	 * Fill opted-in web address fields with the previous page on this site.
	 * Only the origin and path are used, so query strings (which can carry
	 * search terms or tokens) never enter the form. Existing answers win.
	 */
	function prefillReferrer() {
		var referrer;
		try {
			referrer = document.referrer ? new URL(document.referrer) : null;
		} catch (error) {
			referrer = null;
		}
		if (!referrer || referrer.origin !== window.location.origin) {
			return;
		}
		var address = referrer.origin + referrer.pathname;
		if (address === window.location.origin + window.location.pathname) {
			return;
		}
		document.querySelectorAll('.af-wrap input[data-af-prefill="referrer"]').forEach(function (input) {
			var wrap = input.closest('.af-wrap');
			// Only on a fresh form: after a round trip an empty value may be a deliberate choice.
			if (wrap.querySelector('.af-summary, .af-status, .af-previous')) {
				return;
			}
			if (input.maxLength > 0 && address.length > input.maxLength) {
				return;
			}
			if ('' === input.value) {
				input.value = address;
				if (wrap.afSyncLabels) {
					wrap.afSyncLabels();
				}
			}
		});
	}

	function init() {
		var wraps = document.querySelectorAll('.af-wrap');

		for (var i = 0; i < wraps.length; i++) {
			bind(wraps[i]);
		}
		prefillReferrer();

		// A private resume link, when nothing on this site can resume it any more
		// (an add-on that restores saved answers removes the link as it does).
		var resume = window.location.hash.match(/^#af-resume=[a-f0-9]{64}:(\d+)$/);
		var resumeWrap = resume && document.querySelector('.af-wrap[data-af-form="' + resume[1] + '"]');
		if (resumeWrap && resumeWrap.querySelector('.af-form')) {
			history.replaceState(null, '', window.location.pathname + window.location.search);
			var note = document.createElement('p');
			note.className = 'af-help af-resume-note';
			note.tabIndex = -1;
			note.textContent = __(
				'Saved answers for this form are no longer available. Please fill in the form again.',
				'accessible-forms-by-accessible-org',
			);
			var resumeForm = resumeWrap.querySelector('.af-form');
			resumeForm.insertBefore(note, resumeForm.querySelector('.af-field-container'));
			note.focus();
			return;
		}

		// After a no-JS round trip, move focus the same way the enhanced path does.
		var summary = document.querySelector('.af-summary');
		if (summary) {
			focusTarget(summary.id);
			return;
		}

		if (window.location.search.indexOf('af_sent=') !== -1) {
			var status = document.querySelector('.af-status');
			if (status) {
				focusTarget(status.id);
			}
		}
	}

	if ('loading' === document.readyState) {
		document.addEventListener('DOMContentLoaded', init);
	} else {
		init();
	}
})();
