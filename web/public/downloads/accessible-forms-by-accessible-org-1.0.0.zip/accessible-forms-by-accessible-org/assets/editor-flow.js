/** A short setup flow over ordinary WordPress form controls. No extra save state. */
(function () {
	'use strict';
	var builder = document.querySelector('.af-builder');
	var form = document.getElementById('post');
	if (!builder || !form) {
		return;
	}
	var __ = wp.i18n.__,
		sprintf = wp.i18n.sprintf;
	var settings = window.AccessibleFormsFlow || {};
	var saveStatus = document.getElementById('af-save-status');
	var savedStatusText = saveStatus ? saveStatus.textContent : '';
	function showSaveStatus(message) { if (saveStatus && saveStatus.textContent !== message) { saveStatus.textContent = message; } }
	function pendingSave(event) {
		if (event.target.closest('#af-setup-progress')) { return; }
		showSaveStatus(__('Unsaved changes. Save a draft to keep them on the server.', 'accessible-forms-by-accessible-org'));
	}
	form.addEventListener('input', pendingSave);
	form.addEventListener('change', pendingSave);

	var keys = ['build', 'style', 'delivery', 'review'];
	var titles = [
		__('Build your form', 'accessible-forms-by-accessible-org'),
		__('Choose its appearance', 'accessible-forms-by-accessible-org'),
		__('Set up email & confirmation', 'accessible-forms-by-accessible-org'),
		__('Review & publish', 'accessible-forms-by-accessible-org'),
	];
	var nav = builder.querySelector('.af-flow-nav');
	var footer = builder.querySelector('.af-flow-footer');
	var next = document.getElementById('af-step-next');
	var back = document.getElementById('af-step-back');
	var publish = document.getElementById('af-flow-publish');
	var current = 0,
		dirty = false,
		previewRequest = 0,
		previewAnnounced = false,
		previewTimer = 0,
		styleRequest = 0,
		styleTimer = 0,
		styleStale = true,
		styleLoaded = false;
	var reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
	var titleInput = document.getElementById('title');
	if (titleInput) {
		titleInput.required = true;
		titleInput.maxLength = 200;
	}
	var savedStep = document.createElement('input');
	savedStep.type = 'hidden';
	savedStep.name = 'af_editor_step';
	form.appendChild(savedStep);
	var panels = keys.map(function (key, index) {
		var panel = document.createElement('section');
		panel.id = 'af-step-' + key;
		panel.className = 'af-step-panel';
		var heading = document.createElement('h2');
		heading.className = 'af-step-title';
		heading.id = panel.id + '-title';
		heading.tabIndex = -1;
		heading.textContent = titles[index];
		panel.setAttribute('aria-labelledby', heading.id);
		panel.appendChild(heading);
		builder.querySelectorAll('[data-af-editor-step="' + key + '"]').forEach(function (part) {
			panel.appendChild(part);
		});
		builder.insertBefore(panel, footer);
		return panel;
	});
	builder.addEventListener('click', function (event) {
		var link = event.target.closest('[data-af-setup-go]');
		if (link) { event.preventDefault(); show(keys.indexOf(link.dataset.afSetupGo), true); }
	});
	var review = builder.querySelector('.af-review-main');
	panels[3].insertBefore(review, panels[3].children[1]);
	// These are the main content of their steps, rather than optional disclosures.
	builder.querySelectorAll('.af-delivery, .af-appearance').forEach(function (details) {
		var section = document.createElement('section');
		Array.from(details.attributes).forEach(function (attribute) {
			if (attribute.name !== 'open') {
				section.setAttribute(attribute.name, attribute.value);
			}
		});
		Array.from(details.childNodes).forEach(function (child) {
			if (child.nodeName !== 'SUMMARY') {
				section.appendChild(child);
			}
		});
		details.replaceWith(section);
	});
	// Keep heading semantics close to their purpose, out of the first-run path.
	var headingLevel = document.getElementById('af-heading_level');
	if (headingLevel) {
		var headingOptions = document.createElement('details');
		headingOptions.className = 'af-heading-options';
		var headingSummary = document.createElement('summary');
		headingSummary.textContent = __('Heading options', 'accessible-forms-by-accessible-org');
		headingOptions.appendChild(headingSummary);
		var cell = headingLevel.closest('td'),
			row = cell.parentElement;
		var label = row.querySelector('label');
		headingOptions.appendChild(label);
		while (cell.firstChild) {
			headingOptions.appendChild(cell.firstChild);
		}
		row.remove();
		panels[0].querySelector('[aria-labelledby="af-introduction-title"]').appendChild(headingOptions);
	}
	var confirmationPage = builder.querySelector('[name="af_schema[confirmation_page]"]');
	if (confirmationPage) {
		builder
			.querySelector('[aria-labelledby="af-confirmation-title"]')
			.appendChild(
				confirmationPage.closest('.af-confirmation-redirect') ||
					confirmationPage.closest('.af-setting'),
			);
	}
	var nativeBox = document.getElementById('submitdiv');
	if (nativeBox) {
		nativeBox.classList.remove('closed');
		var management = document.createElement('details');
		management.className = 'af-native-publishing';
		var summary = document.createElement('summary');
		summary.textContent = __('WordPress status & deletion', 'accessible-forms-by-accessible-org');
		management.appendChild(summary);
		management.appendChild(nativeBox);
		panels[3].appendChild(management);
	}
	document.body.classList.add('af-guided-editor');
	footer.hidden = false;
	function show(index, focus) {
		current = Math.max(0, Math.min(keys.length - 1, index));
		savedStep.value = keys[current];
		panels.forEach(function (panel, i) {
			panel.hidden = i !== current;
		});
		nav.querySelectorAll('[data-af-go]').forEach(function (link, i) {
			if (i === current) {
				link.setAttribute('aria-current', 'step');
			} else {
				link.removeAttribute('aria-current');
			}
		});
		back.hidden = current === 0;
		next.hidden = current === keys.length - 1;
		if (publish) {
			publish.hidden = current !== keys.length - 1;
		}
		/* translators: 1: current step, 2: total steps. */
		footer.querySelector('.af-step-count').textContent = sprintf(
			/* translators: 1: current step number, 2: total steps. */
			__('Step %1$d of %2$d', 'accessible-forms-by-accessible-org'),
			current + 1,
			keys.length,
		);
		next.textContent =
			current < 3
				? sprintf(
						/* translators: %s: name of the next step. */
						__('Continue to %s', 'accessible-forms-by-accessible-org'),
						nav.querySelectorAll('a')[current + 1].textContent,
					)
				: '';
		if (focus) {
			panels[current].querySelector('.af-step-title').focus();
		}
		previewAnnounced = false;
		if (current === 3) {
			schedulePreview(0);
		}
		if (current === 1 && (styleStale || !styleLoaded)) {
			scheduleStylePreview(0);
		}
	}
	builder.addEventListener('click', function (event) {
		var link = event.target.closest('[data-af-go]');
		if (!link) {
			return;
		}
		event.preventDefault();
		show(keys.indexOf(link.dataset.afGo), true);
	});
	next.addEventListener('click', function () {
		show(current + 1, true);
	});
	back.addEventListener('click', function () {
		show(current - 1, true);
	});
	// Reveal the first invalid control across steps before the browser tries to focus it.
	var revealing = false;
	form.addEventListener(
		'invalid',
		function (event) {
			if (revealing) {
				return;
			}
			revealing = true;
			queueMicrotask(function () {
				revealing = false;
			});
			var panel = event.target.closest('.af-step-panel');
			if (panel) {
				show(panels.indexOf(panel), false);
			}
			var row = event.target.closest('.af-field-row');
			if (row) {
				row.hidden = false;
			}
			var parent = event.target.parentElement;
			while (parent && parent !== form) {
				if (parent.tagName === 'DETAILS') {
					parent.open = true;
				}
				parent = parent.parentElement;
			}
		},
		true,
	);
	function schemaData(supplied) {
		var source = supplied || new FormData(form);
		if (source.has('af_schema_json') && !source.has('af_schema[heading]')) {
			return JSON.parse(source.get('af_schema_json'));
		}
		var schema = Object.create(null);
		source.forEach(function (value, name) {
			if (name.indexOf('af_schema[') !== 0 || typeof value !== 'string') {
				return;
			}
			var path = Array.from(name.matchAll(/\[([^\]]*)\]/g), function (match) {
				return match[1];
			});
			if (
				path.some(function (part) {
					return ['__proto__', 'constructor', 'prototype'].indexOf(part) !== -1;
				})
			) {
				return;
			}
			var node = schema;
			path.forEach(function (part, i) {
				if (i === path.length - 1) {
					if (part === '') {
						node.push(value);
					} else {
						node[part] = value;
					}
				} else {
					if (!node[part]) {
						node[part] = path[i + 1] === '' ? [] : Object.create(null);
					}
					node = node[part];
				}
			});
		});
		return schema;
	}
	var unsaved = false;
	form.addEventListener('input', function (event) {
		if (
			event.target.name &&
			(event.target.name.indexOf('af_schema[') === 0 ||
				event.target.id === 'title' ||
				event.target.hasAttribute('data-af-track'))
		) {
			unsaved = true;
		}
	});
	builder.addEventListener('af:template', function () {
		unsaved = true;
	});
	builder.addEventListener('af:change', function () {
		unsaved = true;
	});
	builder.addEventListener('click', function (event) {
		if (
			event.target.closest(
				'.af-add-choice, .af-remove-choice, .af-paste-choice-list, .af-remove-field, .af-duplicate-field, .af-move-up, .af-move-down, .af-move-top, .af-move-bottom, #af-add-field, #af-add-notification, .af-remove-notification, .af-add-rule-address, .af-remove-rule-address, #af-add-recipient, .af-remove-recipient',
			)
		) {
			unsaved = true;
			dirty = true;
		}
	});
	window.addEventListener('beforeunload', function (event) {
		if (unsaved) {
			event.preventDefault();
			event.returnValue = '';
		}
	});
	form.addEventListener('submit', function (event) {
		if (event.defaultPrevented) {
			return;
		}
		unsaved = false;
		rememberSubmit();
		// WordPress normally clears this handler when its sidebar buttons are clicked.
		// The guided buttons submit the same native form from our action bar.
		if (window.jQuery) {
			window.jQuery(window).off('beforeunload.edit-post');
		}
	});
	form.addEventListener('formdata', function (event) {
		var data = event.formData,
			json = JSON.stringify(schemaData(data));
		Array.from(data.keys()).forEach(function (name) {
			if (name.indexOf('af_schema[') === 0) {
				data.delete(name);
			}
		});
		data.set('af_schema_json', json);
	});
	var preview = document.getElementById('af-live-preview'),
		checkRegion = builder.querySelector('.af-review-checks'),
		checks = checkRegion.querySelector('.af-publication-result'),
		reviewed = document.getElementById('af-accessibility-reviewed'),
		publicationErrors = false,
		publishingCheck = false,
		allowPublication = false;
	function publicationState() {
		if (publish) {
			publish.setAttribute('aria-disabled', String(!reviewed.checked || publicationErrors || publishingCheck));
			publish.setAttribute('aria-describedby', 'af-publication-checks af-accessibility-review-help');
		}
	}
	reviewed.addEventListener('change', publicationState);
	function resetReview(event) {
		var schemaChange = event.type === 'af:change' || event.type === 'af:template' ||
			(event.target.name && event.target.name.indexOf('af_schema[') === 0);
		if (!schemaChange) { return; }
		if (reviewed.checked) {
			reviewed.checked = false;
			say(__('The form changed. Review the updated questions and instructions before publishing.', 'accessible-forms-by-accessible-org'));
		}
		var recordStatus = document.getElementById('af-manual-review-status');
		if (recordStatus) { recordStatus.textContent = __('Current edits need a new manual test report. Test this draft before recording the results.', 'accessible-forms-by-accessible-org'); }
		publicationState();
	}
	['input', 'change', 'af:change', 'af:template'].forEach(function (name) { builder.addEventListener(name, resetReview); });
	publicationState();
	[publish, document.getElementById('publish')].forEach(function (button) {
		if (button) { button.formNoValidate = true; }
	});
	form.addEventListener('submit', async function (event) {
		var button = event.submitter;
		if (!button || (button.id !== 'af-flow-publish' && button.id !== 'publish') || allowPublication) {
			allowPublication = false;
			return;
		}
		event.preventDefault();
		if (current !== 3) { show(3, false); }
		if (publishingCheck) { return; }
		if (!reviewed.checked) {
			markInvalid(reviewed, __('Review the questions and instructions, then confirm this review before publishing.', 'accessible-forms-by-accessible-org'));
			focusControl(reviewed);
			return;
		}
		publishingCheck = true;
		publicationState();
		window.clearTimeout(previewTimer);
		var before = JSON.stringify(schemaData());
		var valid = await refreshPreview(false);
		publishingCheck = false;
		publicationState();
		if (!valid || !reviewed.checked || before !== JSON.stringify(schemaData())) {
			if (valid) {
				checks.textContent = __('The form changed while it was being checked. Review the latest changes and choose Publish again.', 'accessible-forms-by-accessible-org');
			}
			checkRegion.focus();
			return;
		}
		allowPublication = true;
		form.requestSubmit(button);
	}, true);
	var testButton = document.getElementById('af-test-preview');
	testButton.hidden = false;
	async function openTest(button, note, pageId) {
		var tab = window.open('', '_blank');
		if (tab) { tab.opener = null; }
		button.disabled = true;
		note.textContent = __('Preparing private test preview…', 'accessible-forms-by-accessible-org');
		try {
			var data = new FormData(form);
			data.set('action', 'accessible_forms_test_preview');
			data.set('af_test_page', String(pageId));
			data.set('af_schema_json', JSON.stringify(schemaData()));
			var result = await window.AccessibleFormsRequest(settings.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
			if (!result.response.ok || !result.data.success) { throw new Error(); }
			var link = document.createElement('a');
			link.href = result.data.data.url;
			link.target = '_blank';
			link.rel = 'noopener';
			link.textContent = __('Open private test preview (opens in a new tab)', 'accessible-forms-by-accessible-org');
			note.replaceChildren(link);
			if (tab) { tab.location.replace(link.href); }
		} catch (error) {
			if (tab) { tab.close(); }
			note.textContent = __('Test preview could not open. Fix any blocking problems above, then try again.', 'accessible-forms-by-accessible-org');
			await refreshPreview(false);
		} finally {
			button.disabled = false;
		}
	}
	testButton.addEventListener('click', function () { openTest(testButton, document.getElementById('af-test-preview-status'), 0); });
	var themeButton = document.getElementById('af-theme-test-preview');
	var themePage = document.getElementById('af-test-page');
	themeButton.hidden = false;
	themeButton.addEventListener('click', function () {
		var note = document.getElementById('af-theme-test-status');
		if (!Number(themePage.value)) { note.textContent = __('Choose a page to preview with your theme.', 'accessible-forms-by-accessible-org'); themePage.focus(); return; }
		openTest(themeButton, note, Number(themePage.value));
	});
	var pageSearch = document.getElementById('af-test-page-search');
	pageSearch.hidden = false;
	var pageSearchButton = document.getElementById('af-search-test-pages');
	var morePages = document.getElementById('af-more-test-pages');
	morePages.hidden = pageSearch.dataset.more !== '1';
	var pageNumber = 1, pageTerm = '', searchingPages = false;
	async function findTestPages(more) {
		if (searchingPages) { return; }
		searchingPages = true;
		var note = document.getElementById('af-test-page-search-status');
		var number = more ? pageNumber + 1 : 1;
		var term = more ? pageTerm : document.getElementById('af-find-test-page').value.trim();
		pageSearchButton.setAttribute('aria-disabled', 'true'); morePages.setAttribute('aria-disabled', 'true');
		note.textContent = __('Finding pages…', 'accessible-forms-by-accessible-org');
		try {
			var data = new FormData(form);
			data.set('action', 'accessible_forms_test_pages'); data.set('search', term); data.set('page', String(number));
			var result = await window.AccessibleFormsRequest(settings.ajaxUrl, { method:'POST', body:data, credentials:'same-origin' });
			if (!result.response.ok || !result.data.success) { throw new Error(); }
			[themePage, document.getElementById('af-review-page')].forEach(function (select) {
				result.data.data.items.forEach(function (item) {
					if (!Array.from(select.options).some(function (option) { return option.value === String(item.id); })) { select.add(new Option(item.title, String(item.id))); }
				});
			});
			pageNumber = number; pageTerm = term; morePages.hidden = number >= result.data.data.pages;
			if (morePages.hidden && document.activeElement === morePages) { themePage.focus(); }
			note.textContent = result.data.data.items.length ? __('Matching pages added to both page selectors.', 'accessible-forms-by-accessible-org') : __('No editable pages found in this group. Try another search or load more pages.', 'accessible-forms-by-accessible-org');
		} catch (error) { note.textContent = __('Pages could not be loaded. Your selected page is kept. Try again.', 'accessible-forms-by-accessible-org'); }
		finally { searchingPages = false; pageSearchButton.removeAttribute('aria-disabled'); morePages.removeAttribute('aria-disabled'); }
	}
	pageSearchButton.addEventListener('click', function () { findTestPages(false); });
	morePages.addEventListener('click', function () { findTestPages(true); });
	document.getElementById('af-find-test-page').addEventListener('keydown', function (event) { if (event.key === 'Enter') { event.preventDefault(); findTestPages(false); } });
	var summary = document.createElement('dl');
	summary.className = 'af-review-summary';
	review.insertBefore(summary, checkRegion);
	// Optional content suggestions, kept apart from the blocking checks above.
	var advice = document.createElement('section');
	advice.className = 'af-review-advice';
	advice.setAttribute('aria-labelledby', 'af-advice-title');
	advice.hidden = true;
	checks.after(advice);
	function focusField(name) {
		var input = Array.from(document.querySelectorAll('#af-fields > .af-field-row input[name$="[name]"]')).find(
			function (candidate) {
				return candidate.value === name;
			},
		);
		var row = input ? input.closest('.af-field-row') : null;
		if (!row) {
			show(0, false);
			panels[0].querySelector('.af-step-title').focus();
			return;
		}
		focusControl(row.querySelector('.af-label-input') || row.querySelector('summary'));
	}
	// Reveal a control wherever it is (step, collapsed panel, filtered row), then focus it.
	function focusControl(element) {
		if (!element) {
			return;
		}
		var panel = element.closest('.af-step-panel');
		if (panel && panels.indexOf(panel) !== current) {
			show(panels.indexOf(panel), false);
		}
		var row = element.closest('.af-field-row');
		if (row) {
			row.hidden = false;
		}
		var parent = element.parentElement;
		while (parent && parent !== form) {
			if (parent.tagName === 'DETAILS') {
				parent.open = true;
			}
			parent = parent.parentElement;
		}
		// A control inside a hidden option group cannot take focus; use the field label instead.
		if (row && !element.getClientRects().length) {
			element = row.querySelector('.af-label-input') || element;
		}
		if (!element.matches('a, button, input, select, textarea, summary, [tabindex]')) {
			element.tabIndex = -1;
		}
		element.scrollIntoView({ block: 'center', behavior: reducedMotion ? 'auto' : 'smooth' });
		element.focus({ preventScroll: true });
	}
	var fieldControls = {
		label: '.af-label-input',
		type: '.af-type',
		name: 'input[name$="[name]"]',
		choices: '.af-choice-label',
		file_types: 'input[name$="[file_types][]"]',
	};
	var settingControls = {
		heading: '#af-heading',
		success_message: '#af-success_message',
		submit_label: '#af-submit_label',
		closed_message: '[name="af_schema[closed_message]"]',
		recipients: '#af-recipients input',
		appearance: '.af-color-hex[aria-invalid="true"], .af-theme-radio:checked, .af-color-hex',
		fields: '#af-add-field',
		confirmation_page: '[name="af_schema[confirmation_page]"]',
		reply_to: '[name="af_schema[reply_to]"]',
	};
	// Find the control a structured issue refers to: a field property or a form setting.
	function issueControl(issue) {
		var field = issue.field;
		if (field !== null && field !== undefined && field !== '') {
			var row = document.querySelectorAll('#af-fields > .af-field-row')[Number(field)];
			if (!row) {
				return null;
			}
			var control = issue.control || 'label';
			// Add-on controls are named after their input's ID, such as extensions-pro-step.
			var selector =
				fieldControls[control] ||
				(control.indexOf('extensions-') === 0 ? '[id$="-' + control + '"]' : '[name$="[' + control + ']"]');
			return row.querySelector(selector) || row.querySelector('.af-label-input');
		}
		if (issue.setting && settingControls[issue.setting]) {
			var match = document.querySelector(settingControls[issue.setting]);
			if (match) {
				return match;
			}
		}
		return issue.target ? document.getElementById(issue.target) : null;
	}
	var inlineErrors = [];
	// Connect a message to its control, as the public form does: aria-invalid plus a described-by message.
	function markInvalid(element, message) {
		if (!element || !element.matches('input, select, textarea') || element.classList.contains('af-color-hex')) {
			return;
		}
		var id = 'af-inline-error-' + inlineErrors.length;
		var note = document.createElement('span');
		note.className = 'af-inline-error';
		note.id = id;
		note.textContent = message;
		var anchor = element.type === 'checkbox' || element.type === 'radio' ? element.closest('fieldset, label') || element : element;
		anchor.insertAdjacentElement('afterend', note);
		var previous = element.getAttribute('aria-describedby');
		element.setAttribute('aria-describedby', previous ? id + ' ' + previous : id);
		element.setAttribute('aria-invalid', 'true');
		var entry = { element: element, note: note, previous: previous };
		inlineErrors.push(entry);
		function clear() {
			clearInline(entry);
			element.removeEventListener('input', clear);
			element.removeEventListener('change', clear);
		}
		element.addEventListener('input', clear);
		element.addEventListener('change', clear);
	}
	function clearInline(entry) {
		if (!entry.note.isConnected) {
			return;
		}
		entry.note.remove();
		entry.element.removeAttribute('aria-invalid');
		if (entry.previous) {
			entry.element.setAttribute('aria-describedby', entry.previous);
		} else {
			entry.element.removeAttribute('aria-describedby');
		}
	}
	function clearAllInline() {
		inlineErrors.forEach(clearInline);
		inlineErrors = [];
	}
	function markIssues(issues) {
		clearAllInline();
		(issues || []).forEach(function (issue) {
			markInvalid(issueControl(issue), issue.message);
		});
	}
	// Error summary links: open the right step and panel, then focus the control.
	function issueLink(issue) {
		var link = document.createElement('a');
		link.href = '#' + (issue.target || 'af-step-build');
		link.textContent = issue.message;
		link.addEventListener('click', function (event) {
			var control = issueControl(issue);
			if (control) {
				event.preventDefault();
				focusControl(control);
			}
		});
		return link;
	}
	var serverSummary = document.getElementById('af-error-summary');
	if (serverSummary) {
		serverSummary.addEventListener('click', function (event) {
			var link = event.target.closest('a[data-af-setting]');
			if (!link) {
				return;
			}
			var control = issueControl({
				setting: link.dataset.afSetting,
				field: link.dataset.afField,
				control: link.dataset.afControl,
				target: link.hash.slice(1),
			});
			if (control) {
				event.preventDefault();
				focusControl(control);
			}
		});
	}
	async function toggleAdvice(key, restore) {
		var data = new FormData();
		data.set('action', 'accessible_forms_advice_ignore');
		data.set('post_ID', form.querySelector('[name="post_ID"]').value);
		data.set('accessible_forms_schema_nonce', form.querySelector('[name="accessible_forms_schema_nonce"]').value);
		data.set('key', key);
		if (restore) {
			data.set('restore', '1');
		}
		try {
			var requestResult = await window.AccessibleFormsRequest(settings.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
			if (!requestResult.response.ok || !requestResult.data.success) {
				throw new Error();
			}
			await refreshPreview();
			var heading = document.getElementById('af-advice-title');
			if (heading) {
				heading.focus();
			}
		} catch (error) {
			var status = document.createElement('p');
			status.setAttribute('role', 'alert');
			status.textContent = __('The suggestion could not be updated. Save your changes and try again.', 'accessible-forms-by-accessible-org');
			advice.appendChild(status);
		}
	}
	function adviceItem(item) {
		var li = document.createElement('li');
		var text = document.createElement('p');
		text.textContent = item.message;
		li.appendChild(text);
		var actions = document.createElement('p');
		actions.className = 'af-advice-actions';
		if (item.name && !item.ignored) {
			var edit = document.createElement('button');
			edit.type = 'button';
			edit.className = 'button-link';
			edit.textContent = __('Edit field', 'accessible-forms-by-accessible-org');
			edit.setAttribute(
				'aria-label',
				/* translators: %s: field label. */
				sprintf(__('Edit field: %s', 'accessible-forms-by-accessible-org'), item.label),
			);
			edit.addEventListener('click', function () {
				focusField(item.name);
			});
			actions.appendChild(edit);
		} else if ('heading_context' === item.code && !item.ignored) {
			var headingLink = document.createElement('button');
			headingLink.type = 'button';
			headingLink.className = 'button-link';
			headingLink.textContent = __('Open heading options', 'accessible-forms-by-accessible-org');
			headingLink.addEventListener('click', function () {
				show(0, false);
				var level = document.getElementById('af-heading_level');
				if (level) {
					var box = level.closest('details');
					if (box) {
						box.open = true;
					}
					level.focus();
				}
			});
			actions.appendChild(headingLink);
		}
		var toggle = document.createElement('button');
		toggle.type = 'button';
		toggle.className = 'button-link';
		toggle.textContent = item.ignored ? __('Restore', 'accessible-forms-by-accessible-org') : __('Ignore for this form', 'accessible-forms-by-accessible-org');
		toggle.addEventListener('click', function () {
			toggleAdvice(item.key, item.ignored);
		});
		actions.appendChild(toggle);
		li.appendChild(actions);
		return li;
	}
	function renderAdvice(items) {
		advice.replaceChildren();
		items = items || [];
		var open = items.filter(function (item) {
			return !item.ignored;
		});
		var ignored = items.filter(function (item) {
			return item.ignored;
		});
		advice.hidden = !items.length;
		if (!items.length) {
			return;
		}
		var heading = document.createElement('h4');
		heading.id = 'af-advice-title';
		heading.tabIndex = -1;
		heading.textContent = open.length
			? sprintf(
					/* translators: %d: number of suggestions. */
					__('Suggestions (optional): %d', 'accessible-forms-by-accessible-org'),
					open.length,
				)
			: __('Suggestions (optional)', 'accessible-forms-by-accessible-org');
		advice.appendChild(heading);
		var lead = document.createElement('p');
		lead.className = 'description';
		lead.textContent = open.length
			? __(
					'These can make the form easier to complete. They do not block publishing and are not an accessibility conformance check.',
					'accessible-forms-by-accessible-org',
				)
			: __('No open suggestions. Test the published page with a keyboard and a screen reader.', 'accessible-forms-by-accessible-org');
		advice.appendChild(lead);
		if (open.length) {
			var list = document.createElement('ul');
			open.forEach(function (item) {
				list.appendChild(adviceItem(item));
			});
			advice.appendChild(list);
		}
		if (ignored.length) {
			var box = document.createElement('details');
			var boxSummary = document.createElement('summary');
			boxSummary.textContent = sprintf(
				/* translators: %d: number of ignored suggestions. */
				__('Ignored suggestions (%d)', 'accessible-forms-by-accessible-org'),
				ignored.length,
			);
			box.appendChild(boxSummary);
			var ignoredList = document.createElement('ul');
			ignored.forEach(function (item) {
				ignoredList.appendChild(adviceItem(item));
			});
			box.appendChild(ignoredList);
			advice.appendChild(box);
		}
	}
	function reviewSummary() {
		summary.replaceChildren();
		var recipients = Array.from(document.querySelectorAll('#af-recipients input'), function (input) {
			return input.value.trim();
		}).filter(Boolean);
		var rows = [
			[
				__('Form name', 'accessible-forms-by-accessible-org'),
				titleInput.value || __('Add a name above', 'accessible-forms-by-accessible-org'),
				'build',
			],
			[
				__('Fields', 'accessible-forms-by-accessible-org'),
				String(document.querySelectorAll('#af-fields > .af-field-row').length),
				'build',
			],
			[
				__('Send notifications to', 'accessible-forms-by-accessible-org'),
				recipients.join(', ') || __('Add an email address', 'accessible-forms-by-accessible-org'),
				'delivery',
			],
			[
				__('After submission', 'accessible-forms-by-accessible-org'),
				confirmationPage && confirmationPage.value !== '0'
					? confirmationPage.selectedOptions[0].textContent
					: document.getElementById('af-success_message').value,
				'delivery',
			],
		];
		rows.forEach(function (row) {
			var dt = document.createElement('dt');
			dt.textContent = row[0];
			var dd = document.createElement('dd');
			dd.textContent = row[1];
			var link = document.createElement('a');
			link.href = '#af-step-' + row[2];
			link.dataset.afGo = row[2];
			link.textContent = __('Edit', 'accessible-forms-by-accessible-org');
			/* translators: %s: name of the form setting. */
			link.setAttribute('aria-label', sprintf(__('Edit %s', 'accessible-forms-by-accessible-org'), row[0]));
			dd.appendChild(link);
			summary.appendChild(dt);
			summary.appendChild(dd);
		});
	}
	// quiet: an automatic refresh after an edit. It skips the "Checking" message and
	// leaves the status region alone when the result reads the same, to limit announcements.
	async function refreshPreview(quiet) {
		quiet = quiet === true;
		var serial = ++previewRequest,
			data = new FormData(form);
		reviewSummary();
		Array.from(data.keys()).forEach(function (name) {
			if (name.indexOf('af_schema[') === 0) {
				data.delete(name);
			}
		});
		data.set('action', 'accessible_forms_preview_live');
		data.set('af_schema_json', JSON.stringify(schemaData()));
		data.set('af_preview_state', document.getElementById('af-preview-state').value);
		if (!quiet) {
			checks.textContent = __('Checking your current changes…', 'accessible-forms-by-accessible-org');
		}
		preview.setAttribute('aria-busy', 'true');
		try {
			var requestResult = await window.AccessibleFormsRequest(settings.ajaxUrl, {
				method: 'POST',
				body: data,
				credentials: 'same-origin',
			});
			var response = requestResult.response, result = requestResult.data;
			if (serial !== previewRequest) {
				return false;
			}
			if (!response.ok || !result.success) {
				throw new Error();
			}
			var outcome = document.createElement('div');
			publicationErrors = result.data.errors.length > 0;
			checkRegion.dataset.state = publicationErrors ? 'blocked' : 'review';
			publicationState();
			if (result.data.errors.length) {
				var intro = document.createElement('p');
				intro.textContent = __('Publication blocked. Fix every problem below; your edits can still be saved for later:', 'accessible-forms-by-accessible-org');
				outcome.appendChild(intro);
				var list = document.createElement('ul');
				list.className = 'af-review-errors';
				(result.data.issues || result.data.errors).forEach(function (issue) {
					var li = document.createElement('li');
					if (typeof issue === 'string') {
						li.textContent = issue;
					} else if (issueControl(issue)) {
						li.appendChild(issueLink(issue));
					} else {
						li.textContent = issue.message;
					}
					list.appendChild(li);
				});
				outcome.appendChild(list);
				markIssues(result.data.issues);
				preview.textContent = __(
					'Update the settings above, then refresh the preview.',
					'accessible-forms-by-accessible-org',
				);
				renderAdvice([]);
			} else {
				markIssues([]);
				renderAdvice(result.data.advice);
				outcome.textContent = __(
					'Automatic checks found no blocking problems. Complete the author review below and test the page before sharing it. This is not an accessibility certification.',
					'accessible-forms-by-accessible-org',
				);
				preview.innerHTML = result.data.html; // Authenticated server-rendered markup; every value is escaped in Renderer.
				quietPreview(preview);
			}
			if (!quiet || outcome.textContent !== checks.textContent) {
				checks.replaceChildren.apply(checks, Array.from(outcome.childNodes));
			} else if (!result.data.errors.length) {
				announcePreview();
			}
			return !publicationErrors;
		} catch (error) {
			if (serial === previewRequest) {
				checks.textContent = __(
					'Preview could not load. Your edits are still here. Try Refresh preview again.',
					'accessible-forms-by-accessible-org',
				);
			}
			return false;
		} finally {
			if (serial === previewRequest) {
				preview.removeAttribute('aria-busy');
			}
		}
	}
	var emailPreviewButton = document.getElementById('af-preview-email');
	if (emailPreviewButton) {
		emailPreviewButton.addEventListener('click', async function () {
			var output = document.getElementById('af-email-preview');
			output.hidden = false;
			output.textContent = __('Preparing sample…', 'accessible-forms-by-accessible-org');
			emailPreviewButton.disabled = true;
			var data = new FormData(form);
			data.set('action', 'accessible_forms_preview_email');
			try {
				var requestResult = await window.AccessibleFormsRequest(settings.ajaxUrl, {
					method: 'POST',
					body: data,
					credentials: 'same-origin',
				});
				var response = requestResult.response, result = requestResult.data;
				if (!response.ok || !result.success) {
					throw new Error(
						(result.data && result.data.message) ||
							__('The sample could not load. Try again.', 'accessible-forms-by-accessible-org'),
					);
				}
				output.innerHTML = result.data.html;
				var note = document.createElement('p');
				note.className = 'description';
				note.textContent = result.data.message;
				output.prepend(note);
			} catch (error) {
				output.textContent = error.message;
			} finally {
				emailPreviewButton.disabled = false;
			}
		});
	}
	document.getElementById('af-refresh-preview').addEventListener('click', function () {
		previewAnnounced = false;
		refreshPreview(false);
	});
	document.getElementById('af-preview-state').addEventListener('change', function () {
		refreshPreview(false);
	});
	document.getElementById('af-preview-width').addEventListener('change', function (event) {
		preview.classList.toggle('af-preview-narrow', event.target.value === 'narrow');
	});
	var pageSearch = builder.querySelector('.af-page-picker-search');
	if (pageSearch) {
		pageSearch.hidden = false;
		var pageInput = document.getElementById('af-find-confirmation-page');
		var pageButton = document.getElementById('af-search-confirmation-page');
		var pageMore = document.getElementById('af-more-confirmation-pages');
		var pageStatus = document.getElementById('af-page-picker-status');
		var pageLink = document.getElementById('af-view-confirmation-page');
		var pageUrls = JSON.parse(pageSearch.dataset.pageUrls);
		pageMore.hidden = pageSearch.dataset.more !== '1';
		function updatePageLink() {
			var url = pageUrls[confirmationPage.value];
			pageLink.parentElement.hidden = !url;
			if (url) { pageLink.href = url; } else { pageLink.removeAttribute('href'); }
		}
		confirmationPage.addEventListener('change', updatePageLink);
		updatePageLink();
		var findPages = window.AccessibleFormsSearch({
			url: settings.ajaxUrl,
			page: 1,
			parameters: {
				action: 'accessible_forms_page_options',
				accessible_forms_schema_nonce: form.querySelector('[name="accessible_forms_schema_nonce"]').value,
			},
			start: function (context) {
				context.focusFind = document.activeElement === pageButton;
				context.focusMore = document.activeElement === pageMore;
				if (!context.append) { pageMore.hidden = true; }
				pageButton.disabled = true; pageMore.disabled = true;
				confirmationPage.setAttribute('aria-busy', 'true');
				pageStatus.textContent = __('Finding pages…', 'accessible-forms-by-accessible-org');
			},
			success: function (data, context) {
				var chosen = confirmationPage.selectedOptions[0];
				if (!context.append) {
					var options = [new Option(__('Show the confirmation message here', 'accessible-forms-by-accessible-org'), '0')];
					if (chosen && chosen.value !== '0') { options.push(chosen.cloneNode(true)); }
					confirmationPage.replaceChildren.apply(confirmationPage, options);
					if (chosen) { confirmationPage.value = chosen.value; }
					var chosenUrl = pageUrls[confirmationPage.value];
					pageUrls = {}; if (chosenUrl) { pageUrls[confirmationPage.value] = chosenUrl; }
				}
				data.items.forEach(function (item) {
					if (!Array.from(confirmationPage.options).some(function (option) { return option.value === String(item.id); })) {
						confirmationPage.add(new Option(item.title, String(item.id)));
					}
					pageUrls[String(item.id)] = item.url;
				});
				pageMore.hidden = context.page >= data.pages;
				pageStatus.textContent = data.items.length
					? __('Pages added to After submission. Your current choice is unchanged. Choose the page you want.', 'accessible-forms-by-accessible-org')
					: __('No matching public pages. Your current choice is unchanged. Try another name.', 'accessible-forms-by-accessible-org');
				updatePageLink();
				if (context.focusMore && pageMore.hidden && (document.activeElement === pageMore || document.activeElement === document.body)) { confirmationPage.focus(); }
			},
			error: function () { pageStatus.textContent = __('Pages could not load. Your current selection is kept. Try searching again.', 'accessible-forms-by-accessible-org'); },
			end: function (context) {
				pageButton.disabled = false; pageMore.disabled = false; confirmationPage.removeAttribute('aria-busy');
				if (document.activeElement === document.body) {
					if (context.focusFind) { pageButton.focus(); }
					else if (context.focusMore) { (pageMore.hidden ? confirmationPage : pageMore).focus(); }
				}
			},
		});
		pageButton.addEventListener('click', function () { findPages(pageInput.value, false); });
		pageMore.addEventListener('click', function () { findPages(pageInput.value, true); });
		pageInput.addEventListener('keydown', function (event) {
			if (event.key === 'Enter') { event.preventDefault(); findPages(pageInput.value, false); }
		});
	}

	// Template changes are local until the normal WordPress save. Replacing edits needs a visible choice.
	var pendingTemplate = '',
		picker = builder.querySelector('.af-starter-picker');
	if (picker) {
		form.addEventListener('input', function (event) {
			if (event.target.closest('#af-fields')) {
				dirty = true;
			}
		});
		picker.addEventListener('click', function (event) {
			var button = event.target.closest('[data-af-template]');
			if (!button) {
				return;
			}
			pendingTemplate = button.dataset.afTemplate;
			if (dirty) {
				picker.querySelector('.af-template-confirm').hidden = false;
				document.getElementById('af-confirm-template').focus();
			} else {
				applyTemplate();
			}
		});
		document.getElementById('af-confirm-template').addEventListener('click', applyTemplate);
		document.getElementById('af-cancel-template').addEventListener('click', function () {
			picker.querySelector('.af-template-confirm').hidden = true;
			picker.querySelector('[data-af-template="' + pendingTemplate + '"]').focus();
		});
	}
	function applyTemplate() {
		var schema = settings.templates[pendingTemplate];
		if (!schema) {
			return;
		}
		builder.dispatchEvent(new CustomEvent('af:template', { detail: schema }));
		picker.querySelector('summary').textContent = sprintf(
			/* translators: %s: template name. */
			__('%s template · Change template', 'accessible-forms-by-accessible-org'),
			picker.querySelector('[data-af-template="' + pendingTemplate + '"]').textContent,
		);
		picker.querySelector('.af-template-confirm').hidden = true;
		picker.open = false;
		picker.querySelector('summary').focus();
		dirty = false;
	}
	var builderStatus = document.getElementById('af-builder-status');
	function say(message) {
		if (builderStatus) {
			builderStatus.textContent = message;
		}
	}
	// Previews are not live regions: server markup may carry status roles meant for visitors.
	function quietPreview(root) {
		root.querySelectorAll('[role="status"], [role="alert"], [aria-live]').forEach(function (element) {
			element.removeAttribute('role');
			element.removeAttribute('aria-live');
		});
	}
	// One polite announcement per visit to a step, however often the preview refreshes.
	function announcePreview() {
		if (!previewAnnounced) {
			previewAnnounced = true;
			say(__('Preview updated.', 'accessible-forms-by-accessible-org'));
		}
	}
	function schedulePreview(delay, quiet) {
		window.clearTimeout(previewTimer);
		previewTimer = window.setTimeout(function () {
			refreshPreview(quiet === true);
		}, delay);
	}
	function scheduleStylePreview(delay) {
		window.clearTimeout(styleTimer);
		styleTimer = window.setTimeout(refreshStylePreview, delay);
	}

	// Style step: the owner's own fields, rendered by the public renderer from the unsaved state.
	var stylePreview = document.getElementById('af-appearance-preview');
	var styleBody = stylePreview ? stylePreview.querySelector('.af-style-preview-body') : null;
	var styleNote = document.getElementById('af-style-preview-note');
	if (stylePreview) {
		// The preview shows states; it must not change them or follow its links.
		stylePreview.addEventListener('click', function (event) {
			if (event.target.closest('input, button, a, select, textarea')) {
				event.preventDefault();
			}
		});
	}
	function prefixIds(root, prefix) {
		var ids = {};
		root.querySelectorAll('[id]').forEach(function (element) {
			ids[element.id] = prefix + element.id;
			element.id = prefix + element.id;
		});
		root.querySelectorAll('[for], [aria-describedby], [aria-labelledby], [aria-controls], a[href^="#"]').forEach(
			function (element) {
				['for', 'aria-describedby', 'aria-labelledby', 'aria-controls'].forEach(function (attribute) {
					if (element.hasAttribute(attribute)) {
						element.setAttribute(
							attribute,
							element
								.getAttribute(attribute)
								.split(/\s+/)
								.map(function (id) {
									return ids[id] || id;
								})
								.join(' '),
						);
					}
				});
				if (element.matches('a[href^="#"]') && ids[element.hash.slice(1)]) {
					element.setAttribute('href', '#' + ids[element.hash.slice(1)]);
				}
			},
		);
	}
	async function refreshStylePreview() {
		if (!styleBody) {
			return;
		}
		var serial = ++styleRequest;
		var data = new FormData(form);
		Array.from(data.keys()).forEach(function (name) {
			if (name.indexOf('af_schema[') === 0) {
				data.delete(name);
			}
		});
		data.set('action', 'accessible_forms_preview_live');
		data.set('af_preview_context', 'style');
		data.set('af_schema_json', JSON.stringify(schemaData()));
		stylePreview.setAttribute('aria-busy', 'true');
		try {
			var requestResult = await window.AccessibleFormsRequest(settings.ajaxUrl, {
				method: 'POST',
				body: data,
				credentials: 'same-origin',
			});
			var response = requestResult.response, result = requestResult.data;
			if (serial !== styleRequest) {
				return;
			}
			if (!response.ok || !result.success) {
				throw new Error();
			}
			var holder = document.createElement('template');
			holder.innerHTML = result.data.html; // Authenticated server-rendered markup; every value is escaped in Renderer.
			var wrap = holder.content.querySelector('.af-wrap');
			if (!wrap) {
				throw new Error();
			}
			prefixIds(wrap, 'af-style-');
			quietPreview(wrap);
			// Keep the admin page outline intact; the heading keeps its form styles.
			wrap.querySelectorAll('h2.af-heading, h3.af-heading, h4.af-heading, h5.af-heading, h6.af-heading').forEach(
				function (heading) {
					var text = document.createElement('p');
					text.id = heading.id;
					text.className = heading.className;
					text.textContent = heading.textContent;
					heading.replaceWith(text);
				},
			);
			var focusDemo = Array.from(wrap.querySelectorAll('input.af-input, textarea.af-input')).find(function (input) {
				return input.getAttribute('aria-invalid') !== 'true' && input.type !== 'file';
			});
			if (focusDemo) {
				focusDemo.classList.add('af-demo-focus');
				var focusNote = document.createElement('span');
				focusNote.className = 'af-demo-note';
				focusNote.textContent = __('Example: how keyboard focus looks', 'accessible-forms-by-accessible-org');
				focusDemo.insertAdjacentElement('afterend', focusNote);
			}
			styleBody.replaceChildren.apply(styleBody, Array.from(wrap.childNodes));
			styleLoaded = true;
			styleStale = false;
			if (styleNote) {
				styleNote.textContent = __(
					'Preview of your fields with an example error, a checked choice and keyboard focus. It cannot send messages.',
					'accessible-forms-by-accessible-org',
				);
			}
			if (current === 1) {
				announcePreview();
			}
		} catch (error) {
			if (serial === styleRequest && styleNote) {
				styleNote.textContent = __(
					'The preview of your fields could not load, so a sample is shown. Your edits are still here.',
					'accessible-forms-by-accessible-org',
				);
			}
		} finally {
			if (serial === styleRequest) {
				stylePreview.removeAttribute('aria-busy');
			}
		}
	}
	function builderChanged(event) {
		var name = (event && event.target && event.target.name) || '';
		if (event && event.target && event.target.name !== undefined && name.indexOf('af_schema[') !== 0 && name !== '') {
			return;
		}
		if (event && event.type !== 'click' && name === '') {
			return;
		}
		// Colors and sizes apply to the style preview instantly in appearance.js.
		if (name.indexOf('af_schema[appearance]') !== 0) {
			styleStale = true;
			if (current === 1) {
				scheduleStylePreview(700);
			}
		}
		if (current === 3) {
			schedulePreview(900, true);
		}
		queueAutosave();
	}
	form.addEventListener('input', builderChanged);
	form.addEventListener('change', builderChanged);
	builder.addEventListener('af:template', function () {
		builderChanged(null);
	});
	builder.addEventListener('af:change', queueAutosave);
	builder.addEventListener('click', function (event) {
		if (
			event.target.closest(
				'.af-add-choice, .af-remove-choice, .af-paste-choice-list, .af-remove-field, .af-duplicate-field, .af-move-up, .af-move-down, .af-move-top, .af-move-bottom, #af-add-field, #af-undo-field, #af-add-notification, .af-remove-notification, .af-add-rule-address, .af-remove-rule-address, #af-add-recipient, .af-remove-recipient',
			)
		) {
			unsaved = true;
			builderChanged(event);
		}
	});

	// Local autosave. Only the builder's own settings are kept (never secrets outside them),
	// in this browser, for this form and this user. Restoring asks the server to render the
	// kept state on the next load, with the same code that shows a rejected save, which is
	// more reliable than rebuilding every dynamic row in the browser.
	var storageKey = 'accessible-forms-autosave-v2-' + (settings.siteKey || settings.siteId || 0) + '-' + (settings.postId || 0) + '-' + (settings.userId || 0);
	var legacyStorageKey = 'accessible-forms-autosave-' + (settings.postId || 0) + '-' + (settings.userId || 0);
	var recoveredLegacy = false;
	var submittedKey = storageKey + '-submitted';
	var restoredKey = storageKey + '-restored';
	var autosaveTimer = 0;
	var localUnavailable = false;
	function store(kind) {
		try {
			return window[kind] || null;
		} catch (error) {
			return null;
		}
	}
	function readLocal() {
		try {
			var saved = JSON.parse(store('localStorage').getItem(storageKey) || 'null');
			if (!saved) {
				saved = JSON.parse(store('localStorage').getItem(legacyStorageKey) || 'null');
				recoveredLegacy = !!saved;
			}
			if (saved && (!saved.time || Date.now() - saved.time > 7 * 86400000)) {
				forgetLocal();
				return null;
			}
			return saved && typeof saved.schema === 'string' ? saved : null;
		} catch (error) {
			return null;
		}
	}
	function forgetLocal() {
		try {
			store('localStorage').removeItem(storageKey);
			if (recoveredLegacy) { store('localStorage').removeItem(legacyStorageKey); recoveredLegacy = false; }
		} catch (error) {
			// Storage can be unavailable; nothing to clear then.
		}
	}
	function sessionFlag(key, value) {
		try {
			var session = store('sessionStorage');
			if (value === undefined) {
				var found = session.getItem(key);
				session.removeItem(key);
				return found;
			}
			session.setItem(key, value);
		} catch (error) {
			return null;
		}
		return null;
	}
	// Empty choice rows get fresh identities on every load; they are not edits.
	function comparable(json) {
		try {
			var schema = JSON.parse(json);
			Object.keys(schema.fields || {}).forEach(function (key) {
				var field = schema.fields[key];
				if (field && field.choices) {
					field.choices = Object.keys(field.choices)
						.map(function (index) {
							return field.choices[index];
						})
						.filter(function (choice) {
							return choice && choice.label;
						});
				}
			});
			return JSON.stringify(schema);
		} catch (error) {
			return json;
		}
	}
	var initialSchema = comparable(JSON.stringify(schemaData()));
	var initialTitle = titleInput ? titleInput.value : '';
	// The browser clock can be wrong; compare kept copies with the server's clock instead.
	var clockSkew = settings.serverNow ? Date.now() - settings.serverNow * 1000 : 0;
	function snapshot() {
		return {
			time: Date.now(),
			serverTime: Date.now() - clockSkew,
			title: titleInput ? titleInput.value : '',
			schema: JSON.stringify(schemaData()),
		};
	}
	function saveLocal(force) {
		window.clearTimeout(autosaveTimer);
		autosaveTimer = 0;
		if (!unsaved && !force) {
			return;
		}
		var copy = snapshot();
		if (!force && comparable(copy.schema) === initialSchema && copy.title === initialTitle) {
			forgetLocal();
			showSaveStatus(savedStatusText);
			return;
		}
		try {
			store('localStorage').setItem(storageKey, JSON.stringify(copy));
			showSaveStatus(__('Recovery copy kept in this browser. Save a draft to keep these changes on the server.', 'accessible-forms-by-accessible-org'));
		} catch (error) {
			if (!localUnavailable) {
				localUnavailable = true;
				showSaveStatus(__('Unsaved changes. This browser cannot keep a recovery copy.', 'accessible-forms-by-accessible-org'));
					say(__('This browser cannot keep a recovery copy. Use Save draft changes to keep your work on the server.', 'accessible-forms-by-accessible-org'));
			}
		}
	}
	function queueAutosave() {
		showSaveStatus(__('Unsaved changes. Save a draft to keep them on the server.', 'accessible-forms-by-accessible-org'));
		if (!autosaveTimer) {
			autosaveTimer = window.setTimeout(function () {
				saveLocal(false);
			}, 15000);
		}
	}
	function rememberSubmit() {
		saveLocal(true);
		sessionFlag(submittedKey, '1');
	}
	if (titleInput) {
		titleInput.addEventListener('input', queueAutosave);
	}
	document.addEventListener('visibilitychange', function () {
		if (document.visibilityState === 'hidden') {
			saveLocal(false);
		}
	});
	window.addEventListener('pagehide', function () {
		saveLocal(false);
	});
	function localNotice(saved) {
		var notice = document.createElement('div');
		notice.className = 'notice notice-warning inline af-autosave-notice';
		notice.setAttribute('role', 'region');
		notice.setAttribute('aria-labelledby', 'af-autosave-text');
		notice.tabIndex = -1;
		var text = document.createElement('p');
		text.id = 'af-autosave-text';
		var when = new Date(saved.time);
		text.textContent = sprintf(
			/* translators: %s: date and time the changes were kept in this browser. */
			__('You have unsaved changes from %s, kept in this browser.', 'accessible-forms-by-accessible-org'),
			when.toLocaleString(),
		);
		if (recoveredLegacy) {
			text.textContent += ' ' + __('This copy comes from an older version and may belong to another site on this address. Restore it only if it is yours, then review it before saving.', 'accessible-forms-by-accessible-org');
		}
		var actions = document.createElement('p');
		var restore = document.createElement('button');
		restore.type = 'button';
		restore.className = 'button button-primary';
		restore.textContent = __('Restore them', 'accessible-forms-by-accessible-org');
		var discard = document.createElement('button');
		discard.type = 'button';
		discard.className = 'button';
		discard.textContent = __('Discard', 'accessible-forms-by-accessible-org');
		actions.appendChild(restore);
		actions.appendChild(document.createTextNode(' '));
		actions.appendChild(discard);
		notice.appendChild(text);
		notice.appendChild(actions);
		builder.insertBefore(notice, builder.firstChild);
		say(text.textContent);
		discard.addEventListener('click', function () {
			forgetLocal();
			notice.remove();
			say(__('Unsaved changes discarded.', 'accessible-forms-by-accessible-org'));
			panels[current].querySelector('.af-step-title').focus();
		});
		restore.addEventListener('click', async function () {
			restore.disabled = true;
			var data = new FormData();
			data.set('action', 'accessible_forms_restore_local');
			data.set('post_ID', form.querySelector('[name="post_ID"]').value);
			data.set('accessible_forms_schema_nonce', form.querySelector('[name="accessible_forms_schema_nonce"]').value);
			data.set('af_schema_json', saved.schema);
			try {
				var requestResult = await window.AccessibleFormsRequest(settings.ajaxUrl, { method: 'POST', body: data, credentials: 'same-origin' });
				var response = requestResult.response, result = requestResult.data;
				if (!response.ok || !result.success) {
					throw new Error();
				}
				sessionFlag(restoredKey, '1');
				unsaved = false;
				if (window.jQuery) {
					window.jQuery(window).off('beforeunload.edit-post');
				}
				window.location.reload();
			} catch (error) {
				restore.disabled = false;
				text.textContent = __(
					'The changes could not be restored. They are still kept in this browser; try again.',
					'accessible-forms-by-accessible-org',
				);
				notice.focus();
			}
		});
	}
	(function checkLocal() {
		var saved = readLocal();
		var submitted = sessionFlag(submittedKey);
		var saveFailed = (settings.saveErrors || []).length > 0;
		if (sessionFlag(restoredKey)) {
			if (saved && titleInput) {
				titleInput.value = saved.title;
				var titlePrompt = document.getElementById('title-prompt-text');
				if (titlePrompt && saved.title) {
					titlePrompt.classList.add('screen-reader-text');
				}
			}
			// The page now shows the kept edits, but they are still not saved: keep the local copy.
			initialSchema = null;
			initialTitle = null;
			unsaved = true;
			showSaveStatus(__('Recovered changes are not yet saved on the server. Save or publish to keep them.', 'accessible-forms-by-accessible-org'));
			say(__('Unsaved changes restored. Save or publish to keep them.', 'accessible-forms-by-accessible-org'));
			return;
		}
		if (!saved) {
			return;
		}
		if (submitted && !saveFailed) {
			forgetLocal();
			return;
		}
		var same = comparable(saved.schema) === initialSchema && saved.title === initialTitle;
		if (same) {
			if (!saveFailed) {
				forgetLocal();
			}
			return;
		}
		var keptAt = typeof saved.serverTime === 'number' ? saved.serverTime : saved.time;
		if (keptAt > (settings.serverModified || 0) * 1000) {
			localNotice(saved);
		} else {
			forgetLocal();
		}
	})();

	// Add-on editor controls build on these.
	// Live accessibility checks: the rules the server applies when saving,
	// shown next to each control as the owner works. A problem appears when
	// the owner leaves the control, and clears as soon as it is fixed.
	var liveNotes = [];
	function meaningful(text) {
		return /[\p{L}\p{N}]/u.test(text);
	}
	function labelKey(text) {
		return text
			.toLowerCase()
			.replace(/\s+/g, ' ')
			.replace(/[\s:*?.!]+$/, '')
			.trim();
	}
	function liveNote(element, message) {
		var existing = liveNotes.find(function (entry) {
			return entry.element === element;
		});
		if (existing && existing.message === message) {
			return false;
		}
		if (existing) {
			existing.note.remove();
			var ids = (element.getAttribute('aria-describedby') || '').split(' ').filter(function (id) {
				return id && id !== existing.note.id;
			});
			if (ids.length) {
				element.setAttribute('aria-describedby', ids.join(' '));
			} else {
				element.removeAttribute('aria-describedby');
			}
			element.removeAttribute('aria-invalid');
			liveNotes.splice(liveNotes.indexOf(existing), 1);
		}
		if (!message) {
			return false;
		}
		var note = document.createElement('span');
		note.className = 'af-inline-error af-live-error';
		note.id = 'af-live-error-' + Math.random().toString(36).slice(2, 10);
		note.textContent = message;
		element.insertAdjacentElement('afterend', note);
		element.setAttribute('aria-describedby', (note.id + ' ' + (element.getAttribute('aria-describedby') || '')).trim());
		element.setAttribute('aria-invalid', 'true');
		liveNotes.push({ element: element, note: note, message: message });
		return true;
	}
	function liveChecks() {
		var problems = [];
		function check(element, message) {
			// A problem the server reported is already shown on this control.
			if (
				inlineErrors.some(function (entry) {
					return entry.element === element && entry.note.isConnected;
				})
			) {
				return;
			}
			if (element && liveNote(element, message) && document.activeElement !== element) {
				problems.push(message);
			}
		}
		[
			['#af-heading', __('Write the form heading in words, not only symbols.', 'accessible-forms-by-accessible-org')],
			['#af-submit_label', __('Write the button text in words, not only symbols.', 'accessible-forms-by-accessible-org')],
			['#af-success_message', __('Write the success message in words, not only symbols.', 'accessible-forms-by-accessible-org')],
		].forEach(function (pair) {
			var element = document.querySelector(pair[0]);
			if (element) {
				check(element, element.value.trim() && !meaningful(element.value) ? pair[1] : '');
			}
		});
		var seen = {};
		var section = 0;
		document.querySelectorAll('#af-fields > .af-field-row').forEach(function (row) {
			var input = row.querySelector('.af-label-input');
			var type = row.querySelector('.af-type');
			if (!input) {
				return;
			}
			var text = input.value.trim();
			var message = '';
			if (type && type.value === 'section') {
				section++;
			}
			if (text && !meaningful(text)) {
				message = __('Write this label in words, not only symbols. Screen readers announce it as the field’s name.', 'accessible-forms-by-accessible-org');
			} else if (text && type && type.value !== 'section') {
				var key = section + '|' + labelKey(text);
				if (seen[key]) {
					message = __('Another question in this part of the form already uses this label. Make it unique, or put the questions under different section headings.', 'accessible-forms-by-accessible-org');
				}
				seen[key] = true;
			}
			check(input, message);
			row.querySelectorAll('.af-choice-label').forEach(function (choice) {
				check(choice, choice.value.trim() && !meaningful(choice.value) ? __('Write this choice in words or numbers, not only symbols.', 'accessible-forms-by-accessible-org') : '');
			});
		});
		// Announce problems found in controls the owner has already left.
		if (problems.length) {
			say(problems[0]);
		}
	}
	builder.addEventListener('change', function (event) {
		if (event.target.matches('input[type="text"], textarea, select')) {
			liveChecks();
		}
	});
	builder.addEventListener('input', function (event) {
		// Only clear or update a problem already shown; new ones wait until the owner moves on.
		if (
			liveNotes.some(function (entry) {
				return entry.element === event.target;
			})
		) {
			liveChecks();
		}
	});
	document.addEventListener('af:fieldschange', liveChecks);
	// After this script has marked any problems the server reported.
	window.setTimeout(liveChecks, 0);

	window.AccessibleFormsEditorFlow = {
		say: say,
		// Name the control that a save error about an add-on setting should focus.
		registerSettingControl: function (setting, selector) {
			settingControls[setting] = selector;
		},
		// Save as draft with extra fields, bypassing browser validation of the current edits.
		submitDraft: function (fields) {
			Object.keys(fields).forEach(function (name) {
				var input = form.querySelector('input[type="hidden"][name="' + name + '"]');
				if (!input) {
					input = document.createElement('input');
					input.type = 'hidden';
					input.name = name;
					form.appendChild(input);
				}
				input.value = fields[name];
			});
			form.noValidate = true;
			var saveButton = document.getElementById('af-save-draft');
			if (form.requestSubmit) {
				form.requestSubmit(saveButton || undefined);
			} else {
				unsaved = false;
				rememberSubmit();
				form.submit();
			}
		},
	};

	// Start on the relevant panel after a server-side save error or publication.
	var hashStep = keys.indexOf(new URLSearchParams(location.search).get('af_editor_step') || location.hash.replace('#af-step-', ''));
	show(hashStep >= 0 ? hashStep : 0, false);
	if (settings.saveErrors && settings.saveErrors.length) {
		markIssues(settings.saveErrors);
		if (serverSummary) {
			// WordPress moves notices below the page title in its own ready handler,
			// and moving an element drops its focus. Focus once that move is done.
			var focusSummary = function () {
				window.setTimeout(function () {
					serverSummary.focus();
				}, 0);
			};
			if (window.jQuery) {
				window.jQuery(focusSummary);
			} else {
				focusSummary();
			}
		}
	}
})();
