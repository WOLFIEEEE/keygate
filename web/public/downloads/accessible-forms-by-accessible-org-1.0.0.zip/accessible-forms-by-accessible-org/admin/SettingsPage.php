<?php
/**
 * Settings screen.
 *
 * Tabs save independently: each submission merges only its own keys into the
 * stored option, so editing one tab can never blank another.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms\Admin;

use AccessibleForms\Mailer;
use AccessibleForms\Settings;
use AccessibleForms\Extensions;
use AccessibleForms\Spam;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Renders and saves plugin settings.
 */
class SettingsPage {
	const SLUG          = 'accessible-forms-settings';
	const NONCE_SAVE    = 'accessible_forms_save_settings';
	const NONCE_TEST    = 'accessible_forms_test_email';
	const PASSWORD_MASK = '••••••••••••';

	/**
	 * Admin URL for the settings screen.
	 *
	 * @param string $tab Optional tab to open.
	 * @return string
	 */
	public static function url( $tab = '' ) {
		$args = array(
			'post_type' => 'accessible_form',
			'page'      => self::SLUG,
		);

		if ( $tab ) {
			$args['tab'] = $tab;
		}

		return add_query_arg( $args, admin_url( 'edit.php' ) );
	}

	/**
	 * Tab definitions.
	 *
	 * @return array<string, string>
	 */
	private static function tabs() {
		return Extensions::filter(
			'accessible_forms_settings_tabs',
			array(
				'general' => __( 'Overview', 'accessible-forms-by-accessible-org' ),
				'email'   => __( 'Email delivery', 'accessible-forms-by-accessible-org' ),
				'spam'    => __( 'Spam protection', 'accessible-forms-by-accessible-org' ),
				'privacy' => __( 'Privacy', 'accessible-forms-by-accessible-org' ),
			)
		);
	}

	/**
	 * Show a message above the settings after the next redirect. Add-ons use
	 * this from `accessible_forms_settings_saved`.
	 *
	 * @param string $message Plain-text message.
	 */
	public static function flash_error( $message ) {
		set_transient( 'accessible_forms_settings_error_' . get_current_user_id(), (string) $message, 120 );
	}

	/**
	 * Which keys each tab owns.
	 *
	 * @return array<string, string[]>
	 */
	private static function tab_keys() {
		return array(
			'general' => array(),
			'email'   => array(
				'mail_from',
				'mail_from_name',
			),
			'spam'    => array(
				'spam_provider',
				'rate_limit',
				'max_links',
			),
			'privacy' => array( 'retention_days', 'spam_retention_days', 'delete_data' ),
		);
	}

	/**
	 * Handle a settings save.
	 */
	public static function save() {
		if ( ! current_user_can( 'manage_accessible_forms_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'accessible-forms-by-accessible-org' ) );
		}

		check_admin_referer( self::NONCE_SAVE );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
		$tab = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'general';
		$map = self::tab_keys();

		if ( ! isset( self::tabs()[ $tab ] ) ) {
			$tab = 'general';
		}
		$map[ $tab ] = $map[ $tab ] ?? array();

		// phpcs:disable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Each key sanitized below.
		$raw =
			isset( $_POST['af_settings'] ) && is_array( $_POST['af_settings'] )
				? wp_unslash( $_POST['af_settings'] )
				: array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$settings = Settings::get();
		$previous = $settings;

		foreach ( $map[ $tab ] as $key ) {
			if ( ! Settings::is_constant( $key ) ) {
				$settings[ $key ] = self::sanitize_value( $key, $raw[ $key ] ?? null, $settings[ $key ] ?? '' );
			}
		}

		// An add-on may refuse an incomplete setup by returning the previous settings.
		$checked  = Extensions::filter( 'accessible_forms_settings_before_save', $settings, $previous, $tab );
		if ( is_wp_error( $checked ) ) {
			wp_die( esc_html( $checked->get_error_message() ), '', array( 'response' => 503, 'back_link' => true ) );
		}
		$settings = is_array( $checked ) ? $checked : $settings;
		if ( ! Settings::update( $settings ) ) {
			wp_die( esc_html__( 'Your settings could not be saved. Please go back and try again.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 503, 'back_link' => true ) );
		}
		// Add-ons save their own settings for this tab; the nonce and capability were checked above.
		if ( ! Extensions::notify( 'accessible_forms_settings_saved', $tab ) ) {
			wp_die( esc_html__( 'Some add-on settings could not be saved. Please go back, review your settings and try again.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 503, 'back_link' => true ) );
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type' => 'accessible_form',
					'page'      => self::SLUG,
					'tab'       => $tab,
					'af_notice' => 'saved',
				),
				admin_url( 'edit.php' )
			)
		);
		exit();
	}

	/**
	 * Sanitize one setting.
	 *
	 * @param string $key      Setting name.
	 * @param mixed  $value    Submitted value.
	 * @param mixed  $existing Currently stored value.
	 * @return mixed
	 */
	private static function sanitize_value( $key, $value, $existing ) {
		$value = is_scalar( $value ) ? (string) $value : '';
		switch ( $key ) {
			case 'spam_provider':
				return isset( Spam::providers()[ $value ] )
					? $value
					: ( $existing ?:
						'basic' );
			case 'max_links':
				return min( 50, max( 0, (int) $value ) );
			case 'mail_from':
				$clean = sanitize_email( (string) $value );
				return is_email( $clean ) ? $clean : '';

			case 'delete_data':
				return empty( $value ) ? 0 : 1;

			case 'rate_limit':
			case 'retention_days':
				return max( 0, (int) $value );

			case 'spam_retention_days':
				return Settings::spam_retention_days( $value, is_scalar( $existing ) ? (int) $existing : null );

			default:
				return sanitize_text_field( (string) $value );
		}
	}

	/**
	 * Handle the test email request.
	 */
	public static function test_email() {
		if ( ! current_user_can( 'manage_accessible_forms_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'accessible-forms-by-accessible-org' ) );
		}

		check_admin_referer( self::NONCE_TEST );

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
		$to = isset( $_POST['af_test_to'] ) ? sanitize_email( wp_unslash( $_POST['af_test_to'] ) ) : '';

		if ( ! is_email( $to ) ) {
			$to = get_option( 'admin_email' );
		}

		$result = Mailer::send_test( $to );

		set_transient(
			'accessible_forms_test_result_' . get_current_user_id(),
			array(
				'sent'      => $result['sent'],
				'error'     => $result['error'],
				'debug'     => array_slice( $result['debug'], -40 ),
				'transport' => $result['transport'],
				'uncertain' => $result['uncertain'],
				'routes'    => \AccessibleForms\Notifications::mail_routes( $result['routes'] ),
				'to'        => $to,
			),
			120
		);

		wp_safe_redirect(
			add_query_arg(
				array(
					'post_type' => 'accessible_form',
					'page'      => self::SLUG,
					'tab'       => 'email',
				),
				admin_url( 'edit.php' )
			)
		);
		exit();
	}

	/**
	 * Render the settings screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'manage_accessible_forms_settings' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'accessible-forms-by-accessible-org' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$tab  = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'general';
		$tabs = self::tabs();

		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'general';
		}

		$settings = Settings::get();

		$async_tabs = (array) Extensions::filter( 'accessible_forms_async_tabs', array( 'general', 'email', 'spam', 'privacy' ), 'settings' );
		echo '<div class="wrap af-settings" data-af-tabs="settings">';
		echo '<h1>' . esc_html__( 'Settings', 'accessible-forms-by-accessible-org' ) . '</h1>';
		echo '<p class="af-page-description">' .
			esc_html__(
				'Set up delivery, protect your inbox, and choose how long to keep entries.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		echo '<nav class="nav-tab-wrapper" aria-label="' .
			esc_attr__( 'Settings sections', 'accessible-forms-by-accessible-org' ) .
			'">';
		foreach ( $tabs as $key => $label ) {
			$url = add_query_arg(
				array(
					'post_type' => 'accessible_form',
					'page'      => self::SLUG,
					'tab'       => $key,
				),
				admin_url( 'edit.php' )
			);

			printf(
				'<a href="%s" class="nav-tab%s"%s%s>%s</a>',
				esc_url( $url ),
				$key === $tab ? ' nav-tab-active' : '',
				$key === $tab ? ' aria-current="page"' : '',
				in_array( $key, $async_tabs, true ) ? ' data-af-tab' : '',
				esc_html( $label )
			);
		}
		echo '</nav><div data-af-tab-content><div class="af-settings-panel">';

		$settings_error = get_transient( 'accessible_forms_settings_error_' . get_current_user_id() );
		if ( $settings_error ) {
			echo '<div class="notice notice-error" data-af-tab-notice><p>' . esc_html( $settings_error ) . '</p></div>';
			delete_transient( 'accessible_forms_settings_error_' . get_current_user_id() );
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Display only.
		if ( ! $settings_error && isset( $_GET['af_notice'] ) && 'saved' === sanitize_key( wp_unslash( $_GET['af_notice'] ) ) ) {
			echo '<div class="notice notice-success is-dismissible" data-af-tab-notice><p>' .
				esc_html__( 'Settings saved.', 'accessible-forms-by-accessible-org' ) .
				'</p></div>';
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended


		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="accessible_forms_save_settings">';
		echo '<input type="hidden" name="tab" value="' . esc_attr( $tab ) . '">';
		wp_nonce_field( self::NONCE_SAVE );

		switch ( $tab ) {
			case 'email':
				self::tab_email( $settings );
				break;
			case 'spam':
				self::tab_spam( $settings );
				break;
			case 'privacy':
				self::tab_privacy( $settings );
				break;
			case 'general':
				self::tab_general( $settings );
				break;
		}
		// Add-ons add their own settings to any tab, including tabs they added.
		Extensions::notify( 'accessible_forms_settings_tab', $tab, $settings );

		if ( 'general' !== $tab ) {
			submit_button();
		}

		echo '</form></div>';

		if ( 'email' === $tab ) {
			self::test_email_form();
		}
		// Add-ons add tools below a tab's settings form, such as test buttons.
		Extensions::notify( 'accessible_forms_settings_after', $tab );

		echo '</div></div>';
	}

	/**
	 * General tab: an overview rather than settings.
	 */
	private static function tab_general( array $settings ) {
		$transport = Mailer::transport();
		$default   = __( 'WordPress default (wp_mail)', 'accessible-forms-by-accessible-org' );
		$from      = Settings::from_address();

		echo '<section class="af-quick-start"><h2>' .
			esc_html__( 'Your next form, ready in a few steps', 'accessible-forms-by-accessible-org' ) .
			'</h2>';
		echo '<ol><li>' .
			esc_html__( 'Create a form and give it a name you will recognize.', 'accessible-forms-by-accessible-org' ) .
			'</li><li>' .
			esc_html__( 'Add your fields, set a notification address, and publish.', 'accessible-forms-by-accessible-org' ) .
			'</li><li>' .
			esc_html__(
				'Place the Accessible Form block on a page and choose your form.',
				'accessible-forms-by-accessible-org'
			) .
			'</li></ol>';
		echo '<a class="button button-primary" href="' .
			esc_url( admin_url( 'post-new.php?post_type=accessible_form' ) ) .
			'">' .
			esc_html__( 'Create a form', 'accessible-forms-by-accessible-org' ) .
			'</a> <a class="button" href="' .
			esc_url( admin_url( 'edit.php?post_type=accessible_form' ) ) .
			'">' .
			esc_html__( 'Manage forms', 'accessible-forms-by-accessible-org' ) .
			'</a></section>';
		echo '<h2>' . esc_html__( 'Current setup', 'accessible-forms-by-accessible-org' ) . '</h2>';
		echo '<table class="af-status-table"><tbody>';

		self::status_row(
			__( 'Email delivery', 'accessible-forms-by-accessible-org' ),
			$transport === $default ? __( 'WordPress mail', 'accessible-forms-by-accessible-org' ) : $transport,
			$transport === $default ? 'neutral' : 'ok',
			$transport === $default
				? __(
					'Mail is sent exactly as WordPress is already configured, including any SMTP plugin you use.',
					'accessible-forms-by-accessible-org'
				)
				: __( 'Used for this plugin’s notifications and test emails.', 'accessible-forms-by-accessible-org' )
		);

		self::status_row(
			__( 'From address', 'accessible-forms-by-accessible-org' ),
			$from['address'] ? $from['address'] : __( 'WordPress default', 'accessible-forms-by-accessible-org' ),
			'neutral',
			''
		);

		$providers = Spam::providers();
		self::status_row(
			__( 'Spam filtering', 'accessible-forms-by-accessible-org' ),
			$providers[ Spam::provider() ][0] ?? __( 'Built-in protection', 'accessible-forms-by-accessible-org' ),
			'ok',
			__(
				'Review unverified messages in Entries → Needs review. Choose your verification method under Spam protection.',
				'accessible-forms-by-accessible-org'
			)
		);

		$days = (int) Settings::get()['retention_days'];
		self::status_row(
			__( 'Entry retention', 'accessible-forms-by-accessible-org' ),
			$days > 0
				?
				/* translators: %d: number of days. */
				sprintf( _n( '%d day', '%d days', $days, 'accessible-forms-by-accessible-org' ), $days )
				: __( 'Kept indefinitely', 'accessible-forms-by-accessible-org' ),
			'neutral',
			''
		);

		echo '</tbody></table>';

		echo '<details><summary>' .
			esc_html__( 'Advanced: configure credentials in wp-config.php', 'accessible-forms-by-accessible-org' ) .
			'</summary>';
		echo '<p>' .
			esc_html__(
				'These constants override what is saved here.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		echo '<pre class="af-code">' .
			esc_html(
				"define( 'ACCESSIBLE_FORMS_MAIL_FROM', 'hello@example.com' );\n" .
					"define( 'ACCESSIBLE_FORMS_MAIL_FROM_NAME', 'Example' );"
			) .
			'</pre></details>';
	}

	/**
	 * One row of the status table.
	 *
	 * @param string $label Row label.
	 * @param string $value Current value.
	 * @param string $state ok | warn | neutral.
	 * @param string $note  Explanatory note.
	 */
	private static function status_row( $label, $value, $state, $note ) {
		$badges = array(
			'ok'      => __( 'Configured', 'accessible-forms-by-accessible-org' ),
			'warn'    => __( 'Needs attention', 'accessible-forms-by-accessible-org' ),
			'neutral' => '',
		);

		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td><strong>' . esc_html( $value ) . '</strong>';

		if ( ! empty( $badges[ $state ] ) ) {
			echo ' <span class="af-badge af-badge--' .
				esc_attr( $state ) .
				'">' .
				esc_html( $badges[ $state ] ) .
				'</span>';
		}

		if ( $note ) {
			echo '<p class="description">' . esc_html( $note ) . '</p>';
		}

		echo '</td></tr>';
	}

	/**
	 * Email tab.
	 *
	 * @param array $settings Stored settings.
	 */
	private static function tab_email( array $settings ) {
		echo '<h2>' . esc_html__( 'Sender', 'accessible-forms-by-accessible-org' ) . '</h2>';
		echo '<table class="form-table" role="presentation"><tbody>';

		self::field_row(
			'mail_from',
			__( 'From address', 'accessible-forms-by-accessible-org' ),
			'email',
			$settings['mail_from'],
			__(
				'Leave blank to let WordPress decide. With an SMTP service, this usually has to match the authenticated account.',
				'accessible-forms-by-accessible-org'
			)
		);

		self::field_row(
			'mail_from_name',
			__( 'From name', 'accessible-forms-by-accessible-org' ),
			'text',
			$settings['mail_from_name'],
			__( 'Leave blank to let WordPress decide.', 'accessible-forms-by-accessible-org' )
		);



		echo '</tbody></table>';
	}

	/**
	 * Spam tab.
	 *
	 * @param array $settings Stored settings.
	 */
	private static function tab_spam( array $settings ) {
		echo '<h2>' . esc_html__( 'Keep the useful messages', 'accessible-forms-by-accessible-org' ) . '</h2>';
		echo '<p>' .
			esc_html__(
				'Choose one verification method. Local filters run alongside it, and flagged messages stay available for review.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		echo '<fieldset class="af-protection-options"><legend>' .
			esc_html__( 'Verification method', 'accessible-forms-by-accessible-org' ) .
			'</legend>';
		$options  = Spam::providers();
		$provider = Spam::provider();
		foreach ( $options as $value => $copy ) {
			echo '<label class="af-protection-option"><input type="radio" name="af_settings[spam_provider]" value="' .
				esc_attr( $value ) .
				'"' .
				checked( $provider, $value, false ) .
				' aria-labelledby="af-provider-' .
				esc_attr( $value ) .
				'-title" aria-describedby="af-provider-' .
				esc_attr( $value ) .
				'"><span><strong id="af-provider-' .
				esc_attr( $value ) .
				'-title">' .
				esc_html( $copy[0] ) .
				'</strong><span id="af-provider-' .
				esc_attr( $value ) .
				'" class="af-protection-description">' .
				esc_html( $copy[1] ) .
				'</span></span></label>';
		}
		echo '</fieldset>';
		echo '<div class="af-service-note" data-af-spam-panel="altcha"><strong>' .
			esc_html__( 'A quiet check, with a clear fallback', 'accessible-forms-by-accessible-org' ) .
			'</strong><p>' .
			esc_html__(
				'Verification starts automatically when a visitor uses a form. Challenges expire after 20 minutes and can only be used once. No tracking or cookies are added by this check. Your live site needs HTTPS.',
				'accessible-forms-by-accessible-org'
			) .
			'</p><p>' .
			esc_html__(
				'If JavaScript is off or verification fails, the message is held in Needs review without an email notification. Review this folder regularly and accept legitimate messages.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></div>';
		if ( ! Spam::secure_context() ) {
			echo '<div class="notice notice-warning inline" data-af-spam-panel="altcha"><p>' .
				esc_html__(
					'This site’s address starts with http://. Browsers only run the automatic check over HTTPS, so with this method every message would be held for review and visitors would still see the normal confirmation. Use HTTPS before relying on automatic verification.',
					'accessible-forms-by-accessible-org'
				) .
				'</p></div>';
		}
		// Add-ons add the panel for their own verification method here.
		Extensions::notify( 'accessible_forms_spam_provider_panels', $settings );
		echo '<h2>' .
			esc_html__( 'Local filters', 'accessible-forms-by-accessible-org' ) .
			'</h2><p>' .
			esc_html__(
				'The hidden honeypot is always active. Adjust the limits below to suit your forms.',
				'accessible-forms-by-accessible-org'
			) .
			'</p><table class="form-table" role="presentation"><tbody>';

		self::field_row(
			'rate_limit',
			__( 'Submissions per hour, per IP address', 'accessible-forms-by-accessible-org' ),
			'number',
			$settings['rate_limit'],
			__(
				'Applied separately to each form. People sharing a network may share an IP address. Set to 0 to disable.',
				'accessible-forms-by-accessible-org'
			)
		);
		self::field_row(
			'max_links',
			__( 'Maximum links per message', 'accessible-forms-by-accessible-org' ),
			'number',
			$settings['max_links'],
			__(
				'Messages with more links are held in Spam. Counts http, https, and www links across the answers. Set to 0 to disable.',
				'accessible-forms-by-accessible-org'
			)
		);

		// Add-ons add rows for their own content rules here.
		Extensions::notify( 'accessible_forms_spam_filter_rows', $settings );

		echo '</tbody></table>';
		echo '<div class="af-service-note"><strong>' .
			esc_html__( 'Review, recover, and improve', 'accessible-forms-by-accessible-org' ) .
			'</strong><p>' .
			esc_html__(
				'Held messages include the reason they were flagged. Mark a genuine message as not spam to restore it to your inbox; this does not automatically send an email. Rate-limited requests are not stored, and the visitor is asked to try later.',
				'accessible-forms-by-accessible-org'
			) .
			'</p><a class="button" href="' .
			esc_url( EntriesTable::url( array( 'status' => 'spam' ) ) ) .
			'">' .
			esc_html__( 'Review spam messages', 'accessible-forms-by-accessible-org' ) .
			'</a></div>';
	}

	/**
	 * Privacy tab.
	 *
	 * @param array $settings Stored settings.
	 */
	private static function tab_privacy( array $settings ) {
		echo '<h2>' . esc_html__( 'Keep only what you need', 'accessible-forms-by-accessible-org' ) . '</h2>';
		echo '<p>' .
			esc_html__(
				'Choose the default retention period for received submissions. Each form can use its own period. Spam and Needs review messages are kept for the shorter period below, and Trash for 30 days. Include your form and any external services in your site’s privacy policy.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		echo '<table class="form-table" role="presentation"><tbody>';

		self::field_row(
			'retention_days',
			__( 'Delete entries after (days)', 'accessible-forms-by-accessible-org' ),
			'number',
			$settings['retention_days'],
			__(
				'Runs daily. Set to 0 to keep received submissions indefinitely. Each submission keeps the retention policy in effect when it was received.',
				'accessible-forms-by-accessible-org'
			)
		);

		self::field_row(
			'spam_retention_days',
			__( 'Delete spam and Needs review messages after (days)', 'accessible-forms-by-accessible-org' ),
			'number',
			$settings['spam_retention_days'],
			__(
				'Runs daily. Applies to messages marked as spam and messages held for review, counted from when they arrived. Accept a held message to keep it with your received submissions. Between 1 and 3,650 days.',
				'accessible-forms-by-accessible-org'
			)
		);

		echo '<tr><th scope="row">' . esc_html__( 'Uninstalling', 'accessible-forms-by-accessible-org' ) . '</th><td>';
		echo '<label><input type="checkbox" name="af_settings[delete_data]" value="1" ' .
			checked( ! empty( $settings['delete_data'] ), true, false ) .
			'> ' .
			esc_html__( 'Delete all forms and entries when the plugin is deleted', 'accessible-forms-by-accessible-org' ) .
			'</label>';
		echo '<p class="description">' .
			esc_html__(
				'This permanently removes forms, settings, entries and their attachments when you delete the plugin. Temporary saved progress and exports are always removed on uninstall. Deactivation keeps your data.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		echo '</td></tr>';

		echo '<tr><th scope="row">' .
			esc_html__( 'Personal data', 'accessible-forms-by-accessible-org' ) .
			'</th><td><p class="description">' .
			esc_html__(
				'WordPress privacy tools match entries by an exact submitted email address. Forms without an email field require manual review. Entries contain field values, the page path, browser information, and a salted IP hash. Email copies must be managed in your mailbox separately.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></td></tr>';

		echo '</tbody></table>';
	}

	/**
	 * A labelled input row that respects wp-config.php overrides.
	 *
	 * @param string $key   Setting name.
	 * @param string $label Visible label.
	 * @param string $type  Input type.
	 * @param mixed  $value Current value.
	 * @param string $help  Description.
	 */
	private static function field_row( $key, $label, $type, $value, $help ) {
		$id = 'af-' . $key;

		echo '<tr><th scope="row"><label for="' .
			esc_attr( $id ) .
			'">' .
			esc_html( $label ) .
			'</label></th><td>';

		if ( Settings::is_constant( $key ) ) {
			echo '<p><code>' .
				esc_html( (string) Settings::value( $key ) ) .
				'</code> ' .
				esc_html__( '— set in wp-config.php', 'accessible-forms-by-accessible-org' ) .
				'</p>';
		} else {
			printf(
				'<input type="%1$s" class="regular-text" id="%2$s" name="af_settings[%3$s]" value="%4$s" aria-describedby="%2$s-help">',
				esc_attr( $type ),
				esc_attr( $id ),
				esc_attr( $key ),
				esc_attr( (string) $value )
			);

			echo '<p class="description" id="' . esc_attr( $id . '-help' ) . '">' . esc_html( $help ) . '</p>';
		}

		echo '</td></tr>';
	}

	/**
	 * Test email panel, including the last result.
	 */
	private static function test_email_form() {
		$result = get_transient( 'accessible_forms_test_result_' . get_current_user_id() );

		echo '<section class="af-test-email">';
		echo '<h2>' . esc_html__( 'Send a test email', 'accessible-forms-by-accessible-org' ) . '</h2>';
		echo '<p>' .
			esc_html__(
				'Save your settings first, then send a test. Check the recipient’s inbox as well as the result below: acceptance by a mail service does not guarantee delivery to the inbox.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';

		if ( is_array( $result ) ) {
			delete_transient( 'accessible_forms_test_result_' . get_current_user_id() );

			$class = $result['sent'] ? 'notice-success' : 'notice-error';

			// Keep the delivery result beside its test controls; WordPress otherwise
			// relocates notices above the page title on ready.
			echo '<div class="notice inline ' . esc_attr( $class ) . '" role="' . esc_attr( $result['sent'] ? 'status' : 'alert' ) . '"><p><strong>';
			echo $result['sent']
				? esc_html__( 'Test email accepted by the mail service.', 'accessible-forms-by-accessible-org' )
				: ( ! empty( $result['uncertain'] ) ? esc_html__( 'Test email delivery is uncertain. Check before sending again.', 'accessible-forms-by-accessible-org' ) : esc_html__( 'Test email failed.', 'accessible-forms-by-accessible-org' ) );
			echo '</strong></p>';

			echo '<p>' .
				esc_html(
					sprintf(
						/* translators: 1: recipient, 2: transport description. */
						__( 'To %1$s using %2$s', 'accessible-forms-by-accessible-org' ),
						$result['to'],
						$result['transport']
					)
				) .
				'</p>';

			EntryWorkflow::mail_routes( $result['routes'] ?? array() );
			if ( ! empty( $result['error'] ) ) {
				echo '<p><code>' . esc_html( $result['error'] ) . '</code></p>';
			}

			if ( ! empty( $result['debug'] ) ) {
				echo '<details><summary>' .
					esc_html__( 'Mail server conversation', 'accessible-forms-by-accessible-org' ) .
					'</summary>';
				echo '<pre class="af-code">' . esc_html( implode( "\n", $result['debug'] ) ) . '</pre></details>';
			}

			echo '</div>';
		}

		echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">';
		echo '<input type="hidden" name="action" value="accessible_forms_test_email">';
		wp_nonce_field( self::NONCE_TEST );
		echo '<p><label for="af-test-to">' . esc_html__( 'Send to', 'accessible-forms-by-accessible-org' ) . '</label><br>';
		echo '<input type="email" class="regular-text" id="af-test-to" name="af_test_to" value="' .
			esc_attr( get_option( 'admin_email' ) ) .
			'"></p>';
		submit_button( __( 'Send test email', 'accessible-forms-by-accessible-org' ), 'secondary', 'submit', false );
		echo '</form></section>';
	}
}
