<?php
/** Submission cards: notification evidence, attachments and activity. @package AccessibleForms */
namespace AccessibleForms\Admin;

use AccessibleForms\{Entries, Capabilities, Notifications, Audit, Extensions};
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
class EntryWorkflow {
	/**
	 * A stored UTC time shown in the site's time zone.
	 *
	 * @param string $utc MySQL datetime in UTC.
	 * @return string
	 */
	public static function local_time( $utc ) {
		$timestamp = \AccessibleForms\EntryTime::parse( $utc );
		if ( null === $timestamp ) {
			return (string) $utc;
		}
		return wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $timestamp );
	}

	/**
	 * Display name of the person behind a recorded action.
	 *
	 * @param int $user_id User ID; 0 for automatic actions.
	 * @return string
	 */
	public static function person( $user_id ) {
		if ( ! $user_id ) {
			return __( 'Automatic', 'accessible-forms-by-accessible-org' );
		}
		$user = get_userdata( (int) $user_id );
		return $user ? $user->display_name : __( 'Former team member', 'accessible-forms-by-accessible-org' );
	}

	/**
	 * Readable label for a recorded activity.
	 *
	 * @param string $action Stored action name.
	 * @return string
	 */
	public static function activity_label( $action ) {
		$labels = array(
			'entry_updated'                    => __( 'Updated follow-up', 'accessible-forms-by-accessible-org' ),
			'entry_workflow'                   => __( 'Saved follow-up', 'accessible-forms-by-accessible-org' ),
			'entry_unread'                     => __( 'Marked as unread', 'accessible-forms-by-accessible-org' ),
			'entry_spam'                       => __( 'Marked as spam', 'accessible-forms-by-accessible-org' ),
			'entry_ham'                        => __( 'Accepted without sending email', 'accessible-forms-by-accessible-org' ),
			'entry_accept_notify'              => __( 'Accepted and notified recipients', 'accessible-forms-by-accessible-org' ),
			'entry_resend'                     => __( 'Queued the notification again', 'accessible-forms-by-accessible-org' ),
			'entry_trash'                      => __( 'Moved to Trash', 'accessible-forms-by-accessible-org' ),
			'entry_restore'                    => __( 'Restored from Trash', 'accessible-forms-by-accessible-org' ),
			'entry_reply'                      => __( 'Replied to the visitor', 'accessible-forms-by-accessible-org' ),
			'entry_reply_test'                 => __( 'Sent a test reply', 'accessible-forms-by-accessible-org' ),
			'entry_reply_failed'               => __( 'Reply could not be sent', 'accessible-forms-by-accessible-org' ),
			'entry_reply_unrecorded'           => __( 'Reply sent but not saved in notes', 'accessible-forms-by-accessible-org' ),
			'bulk_read'                        => __( 'Marked as read (bulk)', 'accessible-forms-by-accessible-org' ),
			'bulk_unread'                      => __( 'Marked as unread (bulk)', 'accessible-forms-by-accessible-org' ),
			'bulk_spam'                        => __( 'Marked as spam (bulk)', 'accessible-forms-by-accessible-org' ),
			'bulk_ham'                         => __( 'Accepted without notifying (bulk)', 'accessible-forms-by-accessible-org' ),
			'bulk_trash'                       => __( 'Moved to Trash (bulk)', 'accessible-forms-by-accessible-org' ),
			'bulk_delete'                      => __( 'Deleted permanently (bulk)', 'accessible-forms-by-accessible-org' ),
			'bulk_resend'                      => __( 'Asked to send the notification again (bulk)', 'accessible-forms-by-accessible-org' ),
			'resend_original_recipients'       => __( 'Notification queued again for the original recipients', 'accessible-forms-by-accessible-org' ),
			'resend_current_recipients'        => __( 'Notification queued again for the current recipients', 'accessible-forms-by-accessible-org' ),
			'attachment_approved'              => __( 'Approved an attachment', 'accessible-forms-by-accessible-org' ),
			'attachment_downloaded'            => __( 'Downloaded an attachment', 'accessible-forms-by-accessible-org' ),
			'attachment_downloaded_for_review' => __( 'Downloaded an attachment for review', 'accessible-forms-by-accessible-org' ),
		);
		return $labels[ $action ] ?? ucfirst( str_replace( '_', ' ', (string) $action ) );
	}

	/**
	 * Readable label for a notification job or attempt status.
	 *
	 * @param string $status Stored status.
	 * @return string
	 */
	/**
	 * Where a notification went: its recipients, or the host of an add-on's destination.
	 *
	 * @param array $config Notification.
	 * @return string
	 */
	private static function destination( array $config ) {
		if ( isset( $config['destination'] ) && is_string( $config['destination'] ) ) {
			return $config['destination'];
		}
		if ( 'email' !== Notifications::channel( $config ) ) {
			return (string) wp_parse_url( (string) ( $config['url'] ?? '' ), PHP_URL_HOST );
		}
		return implode( ', ', (array) ( $config['recipients'] ?? array() ) );
	}

	private static function status_label( $status ) {
		$labels = array(
			'pending'   => __( 'Waiting to send', 'accessible-forms-by-accessible-org' ),
			'sending'   => __( 'Sending', 'accessible-forms-by-accessible-org' ),
			'accepted'  => __( 'Accepted', 'accessible-forms-by-accessible-org' ),
			'failed'    => __( 'Failed', 'accessible-forms-by-accessible-org' ),
			'uncertain' => __( 'Delivery uncertain', 'accessible-forms-by-accessible-org' ),
			'cancelled' => __( 'Cancelled', 'accessible-forms-by-accessible-org' ),
		);
		return $labels[ $status ] ?? (string) $status;
	}

	/**
	 * One attempt in the notification history, with the reason explained.
	 *
	 * @param array $attempt Stored attempt.
	 */
	private static function attempt( array $attempt ) {
		echo '<li>' .
			esc_html( self::local_time( $attempt['at'] ?? '' ) . ' · ' . self::status_label( $attempt['status'] ?? '' ) );
		if ( ! empty( $attempt['code'] ) ) {
			echo ' ' . esc_html(
				sprintf(
					/* translators: %d: HTTP status code. */
					__( '(HTTP %d)', 'accessible-forms-by-accessible-org' ),
					$attempt['code']
				)
			);
		}
		self::mail_routes( $attempt['routes'] ?? array() );
		if ( ! empty( $attempt['reason'] ) ) {
			$explained = Notifications::explain( $attempt['reason'] );
			echo '<br>' . esc_html( $explained['summary'] ) . ' <strong>' . esc_html( $explained['next'] ) . '</strong>';
			if ( ! empty( $attempt['detail'] ) ) {
				echo '<br><span class="af-muted">' .
					esc_html(
						sprintf(
							/* translators: %s: technical error message. */
							__( 'Technical detail: %s', 'accessible-forms-by-accessible-org' ),
							$attempt['detail']
						)
					) .
					'</span>';
			}
		}
		echo '</li>';
	}

	/** The route and outcome of each handoff, without exposing message content. */
	public static function mail_routes( array $routes ) {
		foreach ( array_slice( $routes, 0, 2 ) as $route ) {
			echo '<p class="af-muted">' . esc_html(
				sprintf(
					/* translators: 1: mail transport, 2: handoff status. */
					__( 'Mail route: %1$s: %2$s', 'accessible-forms-by-accessible-org' ),
					$route['transport'] ?? '',
					self::status_label( $route['status'] ?? '' )
				)
			) . '</p>';
			if ( ! empty( $route['reference'] ) ) {
				echo '<p class="af-muted">' . esc_html( sprintf( /* translators: %s: SMTP provider queue reference. */ __( 'Provider reference: %s', 'accessible-forms-by-accessible-org' ), $route['reference'] ) ) . '</p>';
			}
			if ( ! empty( $route['reason'] ) ) {
				$explained = Notifications::explain( $route['reason'] );
				echo '<p>' . esc_html( $explained['summary'] ) . ( 'uncertain' === ( $route['status'] ?? '' ) ? ' ' . esc_html( $explained['next'] ) : '' ) . '</p>';
			}
		}
	}
	public static function start( $entry ) {
		echo '<form method="post" action="' .
			esc_url( admin_url( 'admin-post.php' ) ) .
			'"><input type="hidden" name="action" value="accessible_forms_entry_action"><input type="hidden" name="entry" value="' .
			esc_attr( (string) $entry['id'] ) .
			'">';
		static $nonce_number = 0; ++$nonce_number;
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress escapes this nonce markup; only a fixed-prefix ID changes.
		echo str_replace( 'id="_wpnonce"', 'id="af-entry-nonce-' . $nonce_number . '"', wp_nonce_field( EntryView::NONCE, '_wpnonce', false, false ) );
		EntryView::view_field();
	}
	public static function render( array $entry ) {
		// Add-ons add cards first, such as a reply form and follow-up.
		Extensions::notify( 'accessible_forms_entry_cards', $entry );
		echo '<details class="af-entry-workflow af-notification-history"' . ( in_array( $entry['mail_status'], array( 'failed', 'uncertain' ), true ) ? ' open' : '' ) . '><summary><h2>' .
			esc_html__( 'Notification history', 'accessible-forms-by-accessible-org' ) .
			'</h2></summary><div><p>' .
			esc_html__(
				'Accepted means the mail service accepted the request. It does not confirm inbox delivery. An uncertain attempt is held for manual review.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		$jobs = Notifications::history( $entry['id'] );
		if ( ! $jobs ) {
			echo '<p>' .
				esc_html__( 'No queued notification attempts are recorded.', 'accessible-forms-by-accessible-org' ) .
				'</p>';
		} else {
			echo '<table class="af-entry-history"><thead><tr><th>' .
				esc_html__( 'Notification', 'accessible-forms-by-accessible-org' ) .
				'</th><th>' .
				esc_html__( 'Recipients / destination', 'accessible-forms-by-accessible-org' ) .
				'</th><th>' .
				esc_html__( 'Status', 'accessible-forms-by-accessible-org' ) .
				'</th></tr></thead><tbody>';
			foreach ( $jobs as $job ) {
				$config = json_decode( $job['config'], true ) ?: array();
				echo '<tr><th scope="row">' .
					esc_html( $config['name'] ?? '' ) .
					'</th><td>' .
					esc_html( self::destination( $config ) ) .
					'</td><td>' .
					esc_html( self::status_label( $job['status'] ) ) .
					'<ul>';
				foreach ( json_decode( (string) $job['history'], true ) ?: array() as $attempt ) {
					if ( is_array( $attempt ) ) {
						self::attempt( $attempt );
					}
				}
				echo '</ul></td></tr>';
			}
			echo '</tbody></table>';
		}
		if ( Capabilities::entry( $entry, 'send_accessible_form_notifications' ) && 'received' === $entry['status'] ) {
			self::start( $entry );
			Editor::select(
				'use_current',
				__( 'Recipient configuration for this resend', 'accessible-forms-by-accessible-org' ),
				array(
					'0' => __( 'Original recipients saved with this entry', 'accessible-forms-by-accessible-org' ),
					'1' => __( 'Current published form recipients', 'accessible-forms-by-accessible-org' ),
				),
				'0'
			);
			echo '<p>' .
				esc_html__(
					'This deliberately sends another copy. Check the attempt history first.',
					'accessible-forms-by-accessible-org'
				) .
				'</p><button name="af_do" value="resend" class="button">' .
				esc_html__( 'Queue notification again', 'accessible-forms-by-accessible-org' ) .
				'</button></form>';
		}
		echo '</div></details>';
		$activity = Audit::recent( $entry['id'] );
		if ( $activity ) {
			echo '<details class="af-entry-workflow"><summary>' .
				esc_html__( 'Activity', 'accessible-forms-by-accessible-org' ) .
				'</summary><ul>';
			foreach ( $activity as $item ) {
				echo '<li>' .
					esc_html(
						sprintf(
							/* translators: 1: date and time, 2: what was done, 3: who did it. */
							__( '%1$s · %2$s · by %3$s', 'accessible-forms-by-accessible-org' ),
							self::local_time( $item['created_at'] ),
							self::activity_label( $item['action'] ),
							self::person( $item['actor'] )
						)
					) .
					'</li>';
			}
			echo '</ul></details>';
		}
	}
}
