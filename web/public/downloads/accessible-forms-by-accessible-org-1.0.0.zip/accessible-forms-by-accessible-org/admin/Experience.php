<?php
/** Accessible feedback and resumable setup for admin workflows. @package AccessibleForms */
namespace AccessibleForms\Admin;

use AccessibleForms\{Entries, Capabilities, Audit, Notifications, Schema};

if ( ! defined( 'ABSPATH' ) ) { exit(); }

class Experience {
	private static $setup_forms = array();
	public static function init() {
		add_action( 'admin_post_accessible_forms_undo_entries', array( self::class, 'undo' ) );
		add_action( 'admin_post_accessible_forms_setup', array( self::class, 'save_setup' ) );
		add_action( 'admin_footer', array( self::class, 'setup_forms' ) );
	}
	private static function notice_key() { return 'accessible_forms_bulk_notice_' . get_current_blog_id() . '_' . get_current_user_id(); }
	private static function snapshot( array $entry ) {
		return array( 'is_read' => (int) $entry['is_read'], 'status' => $entry['status'], 'spam_reason' => $entry['spam_reason'] ?? null, 'trashed_at' => $entry['trashed_at'] ?? null );
	}
	/** Compare and write only the state this action read; never overwrite a newer state. */
	private static function write( $id, array $before, array $after ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching -- Plugin-owned state; conditional update prevents stale undo and concurrent overwrites.
		return $wpdb->update( Entries::table_name(), $after, array( 'id' => (int) $id ) + $before, array( '%d', '%s', '%s', '%s' ), array( '%d', '%d', '%s', '%s', '%s' ) );
	}
	/** Permission checked per entry; counts describe completed writes, not requested IDs. */
	public static function bulk( $action, array $ids ) {
		if ( ! in_array( $action, array( 'read', 'unread', 'spam', 'ham', 'trash', 'delete' ), true ) ) { return false; }
		$ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		if ( count( $ids ) > 500 ) { wp_die( esc_html__( 'Select no more than 500 entries at a time.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 400 ) ); }
		$changed = 0; $unchanged = 0; $skipped = 0; $undo = array();
		$cap = in_array( $action, array( 'trash', 'delete' ), true ) ? 'delete_accessible_form_entries' : 'manage_accessible_form_entries';
		foreach ( $ids as $id ) {
			$entry = Entries::get( $id );
			if ( ! $entry || ! Capabilities::entry( $entry, $cap ) ) { ++$skipped; continue; }
			if ( 'delete' === $action ) {
				if ( 'trash' !== $entry['status'] || 1 !== Entries::delete( array( $id ) ) ) { ++$skipped; continue; }
				++$changed; continue;
			}
			$before = self::snapshot( $entry ); $after = $before;
			if ( in_array( $action, array( 'read', 'unread' ), true ) ) {
				$after['is_read'] = 'read' === $action ? 1 : 0;
			} else {
				$status = array( 'spam' => 'spam', 'ham' => 'received', 'trash' => 'trash' )[ $action ];
				if ( $before['status'] === $status ) { ++$unchanged; continue; }
				$after['status'] = $status;
				$after['spam_reason'] = 'spam' === $status ? 'manual' : null;
				$after['trashed_at'] = 'trash' === $status ? gmdate( 'Y-m-d H:i:s' ) : null;
			}
			if ( $before === $after ) { ++$unchanged; continue; }
			if ( 1 !== self::write( $id, $before, $after ) ) { ++$skipped; continue; }
			++$changed;
			Audit::record( 'bulk_' . $action, $entry['form_id'], $id );
			// Pending sends stop; the attempt history stays with the entry, which Undo
			// or Restore can bring back. Only permanent deletion forgets it.
			if ( in_array( $action, array( 'trash', 'spam' ), true ) ) { Notifications::cancel( $id ); }
			if ( in_array( $action, array( 'read', 'unread', 'trash' ), true ) ) { $undo[ $id ] = array( 'before' => $before, 'after' => $after ); }
		}
		$messages = array(
			/* translators: %d: number of entries for this result. */
			'read' => _n( '%d entry marked as read.', '%d entries marked as read.', $changed, 'accessible-forms-by-accessible-org' ),
			/* translators: %d: number of entries for this result. */
			'unread' => _n( '%d entry marked as unread.', '%d entries marked as unread.', $changed, 'accessible-forms-by-accessible-org' ),
			/* translators: %d: number of entries for this result. */
			'spam' => _n( '%d entry marked as spam.', '%d entries marked as spam.', $changed, 'accessible-forms-by-accessible-org' ),
			/* translators: %d: number of entries for this result. */
			'ham' => _n( '%d entry accepted without sending email.', '%d entries accepted without sending email.', $changed, 'accessible-forms-by-accessible-org' ),
			/* translators: %d: number of entries for this result. */
			'trash' => _n( '%d entry moved to Trash.', '%d entries moved to Trash.', $changed, 'accessible-forms-by-accessible-org' ),
			/* translators: %d: number of entries for this result. */
			'delete' => _n( '%d entry deleted permanently.', '%d entries deleted permanently.', $changed, 'accessible-forms-by-accessible-org' ),
		);
		$message = sprintf( $messages[ $action ], $changed );
		/* translators: %d: number of entries for this result. */
		if ( $unchanged ) { $message .= ' ' . sprintf( _n( '%d already had this state.', '%d already had this state.', $unchanged, 'accessible-forms-by-accessible-org' ), $unchanged ); }
		/* translators: %d: number of entries for this result. */
		if ( $skipped ) { $message .= ' ' . sprintf( _n( '%d could not be changed; it may have changed or your access may have changed.', '%d could not be changed; they may have changed or your access may have changed.', $skipped, 'accessible-forms-by-accessible-org' ), $skipped ); }
		$token = '';
		if ( $undo ) {
			$token = str_replace( '-', '', wp_generate_uuid4() );
			set_transient( 'accessible_forms_undo_' . $token, array( 'user' => get_current_user_id(), 'site' => get_current_blog_id(), 'cap' => $cap, 'items' => $undo ), 10 * MINUTE_IN_SECONDS );
		}
		self::feedback( $message, $skipped ? 'warning' : 'success', $token );
		return 'updated';
	}
	public static function feedback( $message, $type = 'success', $token = '' ) {
		set_transient( self::notice_key(), array( 'message' => $message, 'type' => $type, 'undo' => $token ), 10 * MINUTE_IN_SECONDS );
	}
	public static function notice() {
		$data = get_transient( self::notice_key() );
		if ( ! is_array( $data ) ) { return false; }
		delete_transient( self::notice_key() );
		echo '<div class="notice notice-' . esc_attr( 'warning' === $data['type'] ? 'warning' : 'success' ) . ' af-bulk-result" role="status"><p>' . esc_html( $data['message'] ) . '</p>';
		if ( ! empty( $data['undo'] ) && get_transient( 'accessible_forms_undo_' . $data['undo'] ) ) {
			echo '<form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '" data-af-list-action><input type="hidden" name="action" value="accessible_forms_undo_entries"><input type="hidden" name="token" value="' . esc_attr( $data['undo'] ) . '"><input type="hidden" name="filters" value="' . esc_attr( wp_json_encode( Inbox::current() ) ) . '">';
			wp_nonce_field( 'accessible_forms_undo_' . $data['undo'], 'af_undo_nonce', false );
			echo '<button class="button">' . esc_html__( 'Undo', 'accessible-forms-by-accessible-org' ) . '</button><span class="description">' . esc_html__( 'Available for 10 minutes. Restoring an entry does not send email.', 'accessible-forms-by-accessible-org' ) . '</span></form>';
		}
		echo '</div>';
		return true;
	}
	/** One-time undo with current permissions, expiry and an atomic state comparison. */
	public static function restore( $token ) {
		$data = preg_match( '/^[a-f0-9]{32}$/', $token ) ? get_transient( 'accessible_forms_undo_' . $token ) : false;
		if ( ! is_array( $data ) || (int) $data['user'] !== get_current_user_id() || (int) $data['site'] !== get_current_blog_id() ) {
			return new \WP_Error( 'unavailable', __( 'This undo has expired or is not available to your account.', 'accessible-forms-by-accessible-org' ) );
		}
		delete_transient( 'accessible_forms_undo_' . $token );
		$count = 0; $skipped = 0;
		foreach ( $data['items'] as $id => $state ) {
			$entry = Entries::get( $id );
			$held = $entry ? Entries::held_expiry( array_merge( $entry, $state['before'] ) ) : 0;
			if ( ( $held && $held <= time() ) || ! $entry || ! Capabilities::entry( $entry, $data['cap'] ) || ( ! empty( $entry['expires_at'] ) && $entry['expires_at'] <= gmdate( 'Y-m-d H:i:s' ) ) || self::snapshot( $entry ) !== $state['after'] || 1 !== self::write( $id, $state['after'], $state['before'] ) ) { ++$skipped; continue; }
			++$count; Audit::record( 'entry_undo', $entry['form_id'], $id );
		}
		/* translators: %d: number of entries for this result. */
		$message = sprintf( _n( '%d entry restored to its previous state.', '%d entries restored to their previous state.', $count, 'accessible-forms-by-accessible-org' ), $count );
		/* translators: %d: number of entries for this result. */
		if ( $skipped ) { $message .= ' ' . sprintf( _n( '%d was left unchanged because its state or access changed.', '%d were left unchanged because their state or access changed.', $skipped, 'accessible-forms-by-accessible-org' ), $skipped ); }
		self::feedback( $message, $skipped ? 'warning' : 'success' );
		return array( 'restored' => $count, 'skipped' => $skipped, 'message' => $message );
	}
	public static function undo() {
		$token = isset( $_POST['token'] ) && is_string( $_POST['token'] ) ? sanitize_key( wp_unslash( $_POST['token'] ) ) : '';
		check_admin_referer( 'accessible_forms_undo_' . $token, 'af_undo_nonce' );
		$result = self::restore( $token );
		if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ), '', array( 'response' => 403, 'back_link' => true ) ); }
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Bounded JSON; Inbox::filters sanitizes and allowlists every decoded value.
		$json = isset( $_POST['filters'] ) && is_string( $_POST['filters'] ) ? wp_unslash( $_POST['filters'] ) : '';
		$raw = strlen( $json ) <= 4000 ? json_decode( $json, true ) : array();
		wp_safe_redirect( EntriesTable::url( Inbox::url_filters( Inbox::filters( is_array( $raw ) ? $raw : array() ) ) ) ); exit();
	}
	private static function setup_key( $id ) { return '_accessible_forms_setup_' . get_current_blog_id() . '_' . (int) $id; }
	/** Saved configuration is verified; placement and a real submission are explicitly owner-confirmed. */
	public static function setup( $post, array $schema ) {
		if ( 'auto-draft' === $post->post_status ) {
			echo '<p class="af-setup-intro">' . esc_html__( 'Save your form to keep a setup checklist that you can return to later.', 'accessible-forms-by-accessible-org' ) . '</p>'; return;
		}
		$progress = get_user_meta( get_current_user_id(), self::setup_key( $post->ID ), true );
		$progress = is_array( $progress ) ? $progress : array();
		$recipients = (array) ( $schema['recipients'] ?? array() );
		$delivery = $recipients && count( array_filter( $recipients, 'is_email' ) ) === count( $recipients );
		$checks = array(
			'build' => array( __( 'Create your form', 'accessible-forms-by-accessible-org' ), ! empty( $schema['fields'] ), '#af-step-build' ),
			'email' => array( __( 'Configure notification recipients', 'accessible-forms-by-accessible-org' ), $delivery, '#af-step-delivery' ),
			'publish' => array( __( 'Publish the form', 'accessible-forms-by-accessible-org' ), 'publish' === $post->post_status, '#af-step-review' ),
			'placed' => array( __( 'Check the form on its published page', 'accessible-forms-by-accessible-org' ), ! empty( $progress['placed'] ), Placement::url( $post->ID ) ),
			'tested' => array( __( 'Submit a test and check its entry and email', 'accessible-forms-by-accessible-org' ), ! empty( $progress['tested'] ), EntriesTable::url( array( 'form_id' => $post->ID ) ) ),
		);
		$done = count( array_filter( $checks, static fn( $check ) => $check[1] ) );
		/* translators: 1: completed setup steps, 2: total setup steps. */
		echo '<details id="af-setup-progress" class="af-setup-progress"' . ( empty( $progress['dismissed'] ) ? ' open' : '' ) . '><summary>' . esc_html( sprintf( __( 'Form setup · %1$d of %2$d complete', 'accessible-forms-by-accessible-org' ), $done, count( $checks ) ) ) . '</summary><p class="description">' . esc_html__( 'Saved configuration is checked automatically. Page placement and a real test are confirmed by you and remembered for your account.', 'accessible-forms-by-accessible-org' ) . '</p><ol>';
		foreach ( $checks as $key => [$label, $complete, $url] ) {
			echo '<li><span class="af-setup-state">' . esc_html( $complete ? __( 'Complete', 'accessible-forms-by-accessible-org' ) : __( 'To do', 'accessible-forms-by-accessible-org' ) ) . '</span><a href="' . esc_url( $url ) . '"' . ( in_array( $key, array( 'build', 'email', 'publish' ), true ) ? ' data-af-setup-go="' . esc_attr( array( 'build' => 'build', 'email' => 'delivery', 'publish' => 'review' )[ $key ] ) . '"' : '' ) . '>' . esc_html( $label ) . '</a>';
			if ( in_array( $key, array( 'placed', 'tested' ), true ) ) {
				$form_id = 'af-setup-' . $key;
				self::$setup_forms[ $form_id ] = array( 'post' => $post->ID, 'step' => $key, 'complete' => ! $complete );
				echo '<button type="submit" class="button-link" form="' . esc_attr( $form_id ) . '"' . ( ! $complete && 'publish' !== $post->post_status ? ' disabled' : '' ) . '>' . esc_html( $complete ? __( 'Mark as to do', 'accessible-forms-by-accessible-org' ) : __( 'I checked this', 'accessible-forms-by-accessible-org' ) ) . '<span class="screen-reader-text">: ' . esc_html( $label ) . '</span></button>';
			}
			echo '</li>';
		}
		self::$setup_forms['af-setup-dismiss'] = array( 'post' => $post->ID, 'step' => 'dismissed', 'complete' => empty( $progress['dismissed'] ) );
		echo '</ol><button class="button-link" type="submit" form="af-setup-dismiss">' . esc_html( empty( $progress['dismissed'] ) ? __( 'Keep this checklist collapsed', 'accessible-forms-by-accessible-org' ) : __( 'Keep this checklist open', 'accessible-forms-by-accessible-org' ) ) . '</button></details>';
	}
	/** External forms avoid nesting a second form inside WordPress's editor form. */
	public static function setup_forms() {
		foreach ( self::$setup_forms as $id => $data ) {
			echo '<form id="' . esc_attr( $id ) . '" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="accessible_forms_setup"><input type="hidden" name="form_id" value="' . esc_attr( $data['post'] ) . '"><input type="hidden" name="step" value="' . esc_attr( $data['step'] ) . '"><input type="hidden" name="complete" value="' . ( $data['complete'] ? '1' : '0' ) . '">';
			wp_nonce_field( 'accessible_forms_setup_' . $data['post'], $id . '-nonce', false ); echo '</form>';
		}
	}
	public static function save_setup() {
		$id = isset( $_POST['form_id'] ) ? absint( $_POST['form_id'] ) : 0;
		$step = isset( $_POST['step'] ) ? sanitize_key( wp_unslash( $_POST['step'] ) ) : '';
		check_admin_referer( 'accessible_forms_setup_' . $id, 'af-setup-' . ( 'dismissed' === $step ? 'dismiss' : $step ) . '-nonce' );
		if ( 'accessible_form' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) || ! in_array( $step, array( 'placed', 'tested', 'dismissed' ), true ) ) { wp_die( esc_html__( 'You cannot change this form’s setup progress.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 403 ) ); }
		$data = get_user_meta( get_current_user_id(), self::setup_key( $id ), true );
		$data = is_array( $data ) ? $data : array();
		if ( 'dismissed' !== $step && ! empty( $_POST['complete'] ) && 'publish' !== get_post_status( $id ) ) { wp_die( esc_html__( 'Publish the form before confirming a page or submission test.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 400, 'back_link' => true ) ); }
		$data[ $step ] = ! empty( $_POST['complete'] );
		update_user_meta( get_current_user_id(), self::setup_key( $id ), $data );
		wp_safe_redirect( add_query_arg( 'af_editor_step', 'review', get_edit_post_link( $id, 'raw' ) ) . '#af-setup-progress' ); exit();
	}
	public static function delete_setup( $id ) {
		if ( 'accessible_form' !== get_post_type( $id ) ) { return; }
		// The metadata API invalidates each affected user's cache as well as deleting rows.
		delete_metadata( 'user', 0, self::setup_key( $id ), '', true );
	}
}
