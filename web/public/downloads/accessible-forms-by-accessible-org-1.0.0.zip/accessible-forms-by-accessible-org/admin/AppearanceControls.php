<?php
/** The Style step: contrast-checked themes and a preview using the public form styles.
 *
 * The free plugin offers the built-in themes. An add-on can add editing
 * controls through `accessible_forms_style_editor`, `accessible_forms_style_colors`
 * and `accessible_forms_style_controls`. Without one, the current values ride
 * along in hidden inputs, so saving never changes how a form looks.
 *
 * @package AccessibleForms
 */
namespace AccessibleForms\Admin;

use AccessibleForms\Appearance;
use AccessibleForms\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class AppearanceControls {
	/** Text and spacing keys stored with the appearance. */
	const TYPE_KEYS = array( 'font_size', 'spacing', 'radius' );
	/** Layout keys stored under the schema's `layout`. */
	const LAYOUT_KEYS = array( 'width', 'button', 'labels' );

	/**
	 * A theme card's swatch, drawn from the theme's own colors.
	 *
	 * @param array $colors Theme colors keyed like Appearance::colors().
	 * @return string Escaped markup.
	 */
	public static function theme_swatch( array $colors ) {
		$style = sprintf(
			'--af-swatch-bg:%1$s;--af-swatch-text:%2$s;--af-swatch-button:%3$s;--af-swatch-border:%4$s;',
			$colors['background'] ?? '#ffffff',
			$colors['text'] ?? '#1d2327',
			$colors['button'] ?? '#1d2327',
			$colors['border'] ?? '#737980'
		);
		return '<span class="af-theme-swatch" aria-hidden="true" style="' . esc_attr( $style ) . '"><span class="af-swatch-text">Aa</span><span class="af-swatch-field"></span><span class="af-swatch-button"></span></span>';
	}

	/** Whether an add-on provides the style editing controls. */
	public static function editor() {
		return (bool) Extensions::filter( 'accessible_forms_style_editor', false );
	}

	/**
	 * The theme whose colors match, or `custom`.
	 *
	 * @param array $values Appearance values.
	 * @return string
	 */
	public static function current_theme( array $values ) {
		foreach ( Appearance::presets() as $key => $candidate ) {
			$colors = array_intersect_key( $candidate['colors'], Appearance::colors() );
			if ( ! array_diff_assoc( $colors, array_intersect_key( $values, Appearance::colors() ) ) ) {
				return $key;
			}
		}
		return 'custom';
	}

	public static function render( $raw, $layout = array() ) {
		$values = is_array( $raw ) ? array_merge( Appearance::defaults(), array_filter( $raw, 'is_scalar' ) ) : Appearance::defaults();
		$layout = array_merge(
			array(
				'width'  => 'comfortable',
				'button' => 'start',
				'labels' => 'above',
			),
			is_array( $layout ) ? array_filter( $layout, 'is_scalar' ) : array()
		);
		$preset = self::current_theme( $values );
		$editor = self::editor();
		?>
		<details class="af-editor-section af-appearance" data-af-editor-step="style" id="af-appearance-title" open>
			<summary><?php esc_html_e( 'Form appearance', 'accessible-forms-by-accessible-org' ); ?></summary>
			<p class="af-section-description"><?php esc_html_e( 'Make this form your own. Color contrast is checked as you edit and again when you save.', 'accessible-forms-by-accessible-org' ); ?></p>
			<div class="af-appearance-grid">
				<div class="af-appearance-controls">
					<section class="af-style-card" aria-labelledby="af-style-colors-title">
						<h3 class="af-style-card__title" id="af-style-colors-title"><?php esc_html_e( 'Colors', 'accessible-forms-by-accessible-org' ); ?></h3>
						<fieldset class="af-choice-group" id="af-preset-control" hidden>
							<legend><?php esc_html_e( 'Color theme', 'accessible-forms-by-accessible-org' ); ?></legend>
							<div class="af-theme-cards" id="af-theme-cards">
							<?php foreach ( Appearance::presets() as $key => $theme ) : ?>
								<label class="af-theme-card"><input type="radio" class="af-theme-radio" name="af_theme_preset" value="<?php echo esc_attr( $key ); ?>" <?php checked( $preset, $key ); ?>>
								<?php echo self::theme_swatch( $theme['colors'] ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped in theme_swatch(). ?>
								<span class="af-theme-name"><?php echo esc_html( $theme['label'] ); ?></span></label>
							<?php endforeach; ?>
							</div>
						</fieldset>
						<?php
						if ( $editor ) {
							Extensions::notify( 'accessible_forms_style_colors', $values, $preset );
						} else {
							if ( 'custom' === $preset ) {
								echo '<p class="description af-custom-style-note">' .
									esc_html__( 'This form uses custom colors. Choosing a theme replaces them.', 'accessible-forms-by-accessible-org' ) .
									'</p>';
							}
							foreach ( array_keys( Appearance::colors() ) as $key ) {
								echo '<input type="hidden" class="af-color-hex" data-color="' . esc_attr( $key ) . '" id="af-color-' . esc_attr( $key ) . '" name="af_schema[appearance][' . esc_attr( $key ) . ']" value="' . esc_attr( (string) $values[ $key ] ) . '">';
							}
						}
						?>
					</section>
					<?php
					if ( $editor ) {
						Extensions::notify( 'accessible_forms_style_controls', $values, $layout );
					} else {
						foreach ( self::TYPE_KEYS as $key ) {
							echo '<input type="hidden" class="af-style-value" data-style="' . esc_attr( $key ) . '" name="af_schema[appearance][' . esc_attr( $key ) . ']" value="' . esc_attr( (string) $values[ $key ] ) . '">';
						}
						foreach ( self::LAYOUT_KEYS as $key ) {
							echo '<input type="hidden" class="af-layout-value" data-style="' . esc_attr( $key ) . '" name="af_schema[layout][' . esc_attr( $key ) . ']" value="' . esc_attr( (string) $layout[ $key ] ) . '">';
						}
					}
					?>
				</div>
				<div class="af-appearance-result">
					<div class="af-preview-head">
						<div>
							<p class="af-preview-label" id="af-appearance-preview-label"><?php esc_html_e( 'Appearance preview', 'accessible-forms-by-accessible-org' ); ?></p>
							<p class="description" id="af-style-preview-note"><?php esc_html_e( 'A sample form. It cannot send messages.', 'accessible-forms-by-accessible-org' ); ?></p>
						</div>
						<?php // Shown by appearance.js where the browser supports CSS zoom. ?>
						<div class="af-preview-zoom" role="group" aria-label="<?php esc_attr_e( 'Preview zoom', 'accessible-forms-by-accessible-org' ); ?>" hidden>
							<button type="button" class="button af-zoom-fit" aria-pressed="true"><?php esc_html_e( 'Fit', 'accessible-forms-by-accessible-org' ); ?></button>
							<button type="button" class="button af-zoom-out" aria-label="<?php esc_attr_e( 'Zoom out', 'accessible-forms-by-accessible-org' ); ?>"><span aria-hidden="true">&minus;</span></button>
							<output class="af-zoom-level" aria-live="polite">100%</output>
							<button type="button" class="button af-zoom-in" aria-label="<?php esc_attr_e( 'Zoom in', 'accessible-forms-by-accessible-org' ); ?>"><span aria-hidden="true">+</span></button>
						</div>
					</div>
					<?php // Not a live region: the editor script announces "Preview updated" once through the builder status. ?>
					<div class="af-preview-stage" data-label="<?php esc_attr_e( 'Preview area. Scroll to see more when zoomed in.', 'accessible-forms-by-accessible-org' ); ?>">
					<div id="af-appearance-preview" class="af-wrap af-appearance-preview af-width-<?php echo esc_attr( $layout['width'] ); ?> af-button-<?php echo esc_attr( $layout['button'] ); ?> af-labels-<?php echo esc_attr( $layout['labels'] ); ?>" style="<?php echo esc_attr( Appearance::css( $raw ) ); ?>" role="group" aria-labelledby="af-appearance-preview-label" aria-describedby="af-style-preview-note">
						<div class="af-style-preview-body">
						<p class="af-heading"><?php esc_html_e( 'Let’s get in touch', 'accessible-forms-by-accessible-org' ); ?></p>
						<div class="af-form"><div class="af-field-container"><div class="af-field af-field--text"><label class="af-label" for="af-sample-name"><?php esc_html_e( 'Your name', 'accessible-forms-by-accessible-org' ); ?> <span class="af-req"><?php esc_html_e( '(required)', 'accessible-forms-by-accessible-org' ); ?></span></label>
						<input id="af-sample-name" class="af-input af-empty" type="text" readonly value="" aria-describedby="af-sample-help">
						<p id="af-sample-help" class="af-help"><?php esc_html_e( 'This is how help text will look.', 'accessible-forms-by-accessible-org' ); ?></p></div></div>
						<div class="af-field-container"><div class="af-field af-field--email"><label class="af-label" for="af-sample-email"><?php esc_html_e( 'Email address', 'accessible-forms-by-accessible-org' ); ?></label><input id="af-sample-email" class="af-input" type="text" readonly value="name@example.com"></div></div>
						<div class="af-actions"><button type="button" class="af-submit"><?php esc_html_e( 'Send message', 'accessible-forms-by-accessible-org' ); ?></button></div></div>
						</div>
					</div>
					</div>
					<div class="af-contrast-panel" hidden><p id="af-contrast-status" role="status"></p>
					<?php Extensions::notify( 'accessible_forms_style_contrast_panel' ); ?>
					<details class="af-contrast-details"><summary><?php esc_html_e( 'View contrast details', 'accessible-forms-by-accessible-org' ); ?></summary><ul id="af-contrast-results"></ul>
					<p class="description"><?php esc_html_e( 'These checks protect this form’s palette. Check the published page too: site themes and custom CSS can override form styles.', 'accessible-forms-by-accessible-org' ); ?></p></details></div>
				</div>
			</div>
		</details>
		<?php
	}
}
