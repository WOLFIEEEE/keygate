<?php
/**
 * Single entry screen.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms\Admin;

use AccessibleForms\Entries;
use AccessibleForms\Capabilities;
use AccessibleForms\Notifications;
use AccessibleForms\Audit;
use AccessibleForms\Schema;
use AccessibleForms\Spam;
use AccessibleForms\Extensions;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

/**
 * Renders one stored submission in full.
 */
class EntryView {
	const SLUG  = 'accessible-forms-entry';
	const NONCE = 'accessible_forms_entry_action';

	/**
	 * Admin URL for an entry.
	 *
	 * @param int $id Entry ID.
	 * @return string
	 */
	public static function url( $id, array $view = array() ) {
		return add_query_arg(
			array(
				'post_type' => 'accessible_form',
				'page'      => self::SLUG,
				'entry'     => (int) $id,
				'view'      => $view ? rawurlencode( wp_json_encode( $view ) ) : false,
			),
			admin_url( 'admin.php' )
		);
	}

	/**
	 * Handle a single-entry action.
	 */
	public static function handle_action() {
		if ( ! current_user_can( 'read_accessible_form_entries' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'accessible-forms-by-accessible-org' ) );
		}

		check_admin_referer( self::NONCE );

		// phpcs:disable WordPress.Security.NonceVerification.Missing -- Verified above.
		$id = isset( $_POST['entry'] ) ? (int) $_POST['entry'] : 0;
		$do = isset( $_POST['af_do'] ) ? sanitize_key( wp_unslash( $_POST['af_do'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		$view = self::view( true );

		$entry = $id ? Entries::get( $id ) : null;

		if ( ! $entry ) {
			wp_safe_redirect( EntriesTable::url( Inbox::url_filters( $view ) ) );
			exit();
		}
		// Add-on actions check their own permissions, then redirect and exit.
		if ( ! in_array( $do, array( 'resend', 'accept_notify', 'trash', 'restore', 'unread', 'spam', 'ham', 'delete' ), true ) ) {
			Extensions::notify( 'accessible_forms_entry_action', $do, $entry, $view );
			wp_die( esc_html__( 'Unknown action.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 400 ) );
		}

		$required = in_array( $do, array( 'delete', 'trash' ), true )
			? 'delete_accessible_form_entries'
			: ( in_array( $do, array( 'resend', 'accept_notify' ), true )
				? 'send_accessible_form_notifications'
				: 'manage_accessible_form_entries' );
		if (
			! Capabilities::entry( $entry, $required ) ||
			( 'accept_notify' === $do && ! Capabilities::entry( $entry, 'manage_accessible_form_entries' ) )
		) {
			wp_die(
				esc_html__( 'You cannot perform this action on this submission.', 'accessible-forms-by-accessible-org' ),
				'',
				array(
					'response' => 403,
				)
			);
		}
		if ( 'delete' === $do && 'trash' !== $entry['status'] ) {
			wp_die(
				esc_html__( 'Move this submission to Trash before deleting it permanently.', 'accessible-forms-by-accessible-org' ),
				'',
				array( 'response' => 400 )
			);
		}
		$result = true;
		if ( 'resend' === $do ) {
			$result = Notifications::queue( $id, true, ! empty( $_POST['use_current'] ) );
		}
		if ( 'accept_notify' === $do ) {
			Entries::set_status( array( $id ), 'received' );
			$result = Notifications::queue( $id, true );
			if ( is_wp_error( $result ) ) {
				// Nothing was queued, so the submission stays where it was, with its reason.
				Entries::set_status( array( $id ), $entry['status'], (string) $entry['spam_reason'] );
			}
		}
		if ( 'trash' === $do ) {
			Entries::set_status( array( $id ), 'trash' );
			Notifications::cancel( $id );
		}
		if ( 'restore' === $do ) {
			Entries::set_status( array( $id ), 'received' );
		}
		if ( is_wp_error( $result ) ) {
			wp_die( esc_html( $result->get_error_message() ), '', array( 'back_link' => true ) );
		}
		Audit::record( 'entry_' . $do, $entry['form_id'], $id );
		switch ( $do ) {
			case 'unread':
				Entries::set_read( array( $id ), false );
				wp_safe_redirect( EntriesTable::url( Inbox::url_filters( $view ) ) );
				exit();

			case 'spam':
				Entries::set_status( array( $id ), 'spam' );
				break;

			case 'ham':
				Entries::set_status( array( $id ), 'received' );
				break;

			case 'delete':
				Entries::delete( array( $id ) );
				wp_safe_redirect(
					add_query_arg( 'af_notice', 'deleted', EntriesTable::url( Inbox::url_filters( $view ) ) )
				);
				exit();
		}

		wp_safe_redirect( self::url( $id, $view ) );
		exit();
	}

	/**
	 * Keep a one-time result for the current user until the next page load.
	 *
	 * @param string $type    success, info, warning or error.
	 * @param string $message Message.
	 */
	public static function flash( $type, $message ) {
		set_transient(
			'accessible_forms_notice_' . get_current_user_id(),
			array(
				'type'    => $type,
				'message' => $message,
			),
			5 * MINUTE_IN_SECONDS
		);
	}

	/**
	 * Show the one-time result of the last action, after its redirect. The
	 * message lives server-side, so a crafted link cannot fake a result.
	 */
	private static function notice() {
		$key    = 'accessible_forms_notice_' . get_current_user_id();
		$notice = get_transient( $key );
		if ( ! is_array( $notice ) || empty( $notice['message'] ) ) {
			return;
		}
		delete_transient( $key );
		$type = in_array( $notice['type'] ?? '', array( 'success', 'info', 'warning', 'error' ), true ) ? $notice['type'] : 'info';
		echo '<div class="notice notice-' . esc_attr( $type ) . ' is-dismissible" role="' . ( 'error' === $type ? 'alert' : 'status' ) . '"><p>' .
			esc_html( $notice['message'] ) . '</p></div>';
	}

	/**
	 * Render the screen.
	 */
	public static function render() {
		if ( ! current_user_can( 'read_accessible_form_entries' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'accessible-forms-by-accessible-org' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$id    = isset( $_GET['entry'] ) ? (int) $_GET['entry'] : 0;
		$entry = $id ? Entries::get( $id ) : null;

		echo '<div class="wrap af-entry">';

		if ( ! $entry ) {
			echo '<h1>' . esc_html__( 'Entry not found', 'accessible-forms-by-accessible-org' ) . '</h1>';
			echo '<p><a href="' .
				esc_url( EntriesTable::url( Inbox::url_filters( self::view() ) ) ) .
				'">' .
				esc_html__( 'Back to all entries', 'accessible-forms-by-accessible-org' ) .
				'</a></p></div>';
			return;
		}

		if ( ! Capabilities::entry( $entry ) ) {
			wp_die(
				esc_html__( 'You cannot read this submission.', 'accessible-forms-by-accessible-org' ),
				'',
				array(
					'response' => 403,
				)
			);
		}
		// Opening an entry marks it read.
		if ( empty( $entry['is_read'] ) ) {
			Entries::set_read( array( $id ), true );
			$entry['is_read'] = true;
		}

		$labels     = Entries::labels( $entry );
		$form_title = $entry['snapshot']['title'] ?? get_the_title( $entry['form_id'] );

		echo '<h1 class="wp-heading-inline">' .
			esc_html__( 'Entry', 'accessible-forms-by-accessible-org' ) .
			' #' .
			esc_html( (string) $entry['id'] ) .
			'</h1>';
		echo '<a href="' .
			esc_url( EntriesTable::url( Inbox::url_filters( self::view() ) ) ) .
			'" class="page-title-action af-entry-back">' .
			esc_html__( 'All entries', 'accessible-forms-by-accessible-org' ) .
			'</a>';
		self::navigation( $entry );
		$received = \AccessibleForms\EntryTime::display( $entry );
		echo '<p class="af-entry__subtitle">' .
			esc_html(
				sprintf(
					/* translators: 1: form name, 2: date and time the submission was received. */
					__( '%1$s · Received %2$s', 'accessible-forms-by-accessible-org' ),
					$form_title ? $form_title : __( '(deleted form)', 'accessible-forms-by-accessible-org' ),
					$received
				)
			) .
			'</p>';
		echo '<hr class="wp-header-end">';
		$states = array( 'received' => __( 'Received', 'accessible-forms-by-accessible-org' ), 'review' => __( 'Needs review', 'accessible-forms-by-accessible-org' ), 'spam' => __( 'Spam', 'accessible-forms-by-accessible-org' ), 'trash' => __( 'Trash', 'accessible-forms-by-accessible-org' ) );
		$delivery = array( 'sent' => __( 'Accepted by mail service', 'accessible-forms-by-accessible-org' ), 'queued' => __( 'Queued', 'accessible-forms-by-accessible-org' ), 'uncertain' => __( 'Delivery uncertain', 'accessible-forms-by-accessible-org' ), 'failed' => __( 'Failed', 'accessible-forms-by-accessible-org' ), 'skipped' => __( 'Not sent', 'accessible-forms-by-accessible-org' ) );
		echo '<dl class="af-entry-summary"><div><dt>' . esc_html__( 'Entry status', 'accessible-forms-by-accessible-org' ) . '</dt><dd>' . esc_html( $states[ $entry['status'] ] ?? $entry['status'] ) . '</dd></div><div><dt>' . esc_html__( 'Notification', 'accessible-forms-by-accessible-org' ) . '</dt><dd>' . esc_html( $delivery[ $entry['mail_status'] ] ?? __( 'Unknown', 'accessible-forms-by-accessible-org' ) ) . '</dd></div></dl>';

		self::notice();

		if ( in_array( $entry['status'], array( 'spam', 'review' ), true ) ) {
			echo '<div class="notice notice-warning"><p>' .
				esc_html(
					'review' === $entry['status']
						? __(
							'This submission needs review. Verification was incomplete or unavailable.',
							'accessible-forms-by-accessible-org'
						)
						: __( 'This entry is marked as spam.', 'accessible-forms-by-accessible-org' )
				) .
				'</p>';
			$expiry = Entries::held_expiry( $entry );
			if ( $expiry ) {
				echo '<p><strong>' .
					esc_html(
						sprintf(
							/* translators: %s: date and time in the site's time zone. */
							__( 'Will be deleted automatically on %s.', 'accessible-forms-by-accessible-org' ),
							wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), $expiry )
						)
					) .
					'</strong> ' .
					esc_html__( 'Accept it to keep it with your received submissions.', 'accessible-forms-by-accessible-org' ) .
					'</p>';
			}
			echo '</div>';
		}

		if ( 'failed' === $entry['mail_status'] ) {
			echo '<div class="notice notice-error"><p><strong>' .
				esc_html__( 'The notification email for this entry did not send.', 'accessible-forms-by-accessible-org' ) .
				'</strong> ' .
				esc_html__(
					'The submission itself was stored safely — only the email failed.',
					'accessible-forms-by-accessible-org'
				) .
				'</p>';

			if ( ! empty( $entry['mail_error'] ) ) {
				echo '<p><code>' . esc_html( $entry['mail_error'] ) . '</code></p>';
			}

			echo '</div>';
		}

		echo '<div class="af-entry__grid">';

		// The submission itself.
		echo '<div class="af-entry__main"><div class="postbox"><h2 class="hndle"><span>' .
			esc_html__( 'Submission', 'accessible-forms-by-accessible-org' ) .
			'</span></h2><div class="inside">';

		if ( empty( $entry['fields'] ) ) {
			echo '<p>' . esc_html__( 'This entry has no stored values.', 'accessible-forms-by-accessible-org' ) . '</p>';
		} else {
			echo '<dl class="af-entry__fields">';
			foreach ( Entries::display_values( $entry ) as $key => $value ) {
				$label = $labels[ $key ] ?? $key;
				$value = is_array( $value ) ? implode( ', ', $value ) : (string) $value;

				echo '<dt>' . esc_html( $label ) . '</dt><dd>';

				if ( '' === trim( $value ) ) {
					echo '<em>' . esc_html__( '(empty)', 'accessible-forms-by-accessible-org' ) . '</em>';
				} elseif ( is_email( $value ) ) {
					echo '<a href="mailto:' . esc_attr( $value ) . '">' . esc_html( $value ) . '</a>';
				} else {
					echo nl2br( esc_html( $value ) );
				}

				echo '</dd>';
			}
			echo '</dl>';
		}

		if ( empty( $entry['snapshot'] ) ) {
			echo '<p class="description">' .
				esc_html__(
					'Legacy entry: original question labels were not recorded. Field keys are shown.',
					'accessible-forms-by-accessible-org'
				) .
				'</p>';
		}
		// Reply, follow-up and history follow as their own cards.
		echo '</div></div>';
		EntryWorkflow::render( $entry );
		echo '</div>';

		// Metadata and actions.
		echo '<div class="af-entry__side"><div class="postbox"><h2 class="hndle"><span>' .
			esc_html__( 'Details', 'accessible-forms-by-accessible-org' ) .
			'</span></h2><div class="inside">';

		echo '<table class="af-entry__meta"><tbody>';

		self::meta_row(
			__( 'Received', 'accessible-forms-by-accessible-org' ),
			\AccessibleForms\EntryTime::display( $entry )
		);

		self::meta_row(
			__( 'Form', 'accessible-forms-by-accessible-org' ),
			$form_title ? $form_title : __( '(deleted form)', 'accessible-forms-by-accessible-org' )
		);

		if ( ! empty( $entry['page_url'] ) ) {
			self::meta_row(
				__( 'Submitted from', 'accessible-forms-by-accessible-org' ),
				$entry['page_url'],
				wp_validate_redirect( $entry['page_url'], home_url() )
			);
		}

		$mail_labels = array(
			'sent'      => __( 'Accepted by mail service', 'accessible-forms-by-accessible-org' ),
			'queued'    => __( 'Queued', 'accessible-forms-by-accessible-org' ),
			'uncertain' => __( 'Delivery uncertain', 'accessible-forms-by-accessible-org' ),
			'failed'    => __( 'Failed', 'accessible-forms-by-accessible-org' ),
			'skipped'   => __( 'Not sent', 'accessible-forms-by-accessible-org' ),
		);

		self::meta_row(
			__( 'Notification', 'accessible-forms-by-accessible-org' ),
			$mail_labels[ $entry['mail_status'] ] ?? __( 'Unknown', 'accessible-forms-by-accessible-org' )
		);

		if ( ! empty( $entry['spam_reason'] ) ) {
			$reasons = Spam::reason_labels() + array( 'manual' => __( 'Marked by hand', 'accessible-forms-by-accessible-org' ) );
			self::meta_row(
				__( 'Spam check', 'accessible-forms-by-accessible-org' ),
				$reasons[ $entry['spam_reason'] ] ?? $entry['spam_reason']
			);
		}

		if ( ! empty( $entry['user_agent'] ) ) {
			self::meta_row( __( 'Browser', 'accessible-forms-by-accessible-org' ), $entry['user_agent'] );
		}

		echo '</tbody></table>';

		echo '<p class="description">' .
			esc_html__(
				'The sender\'s IP address is stored only as a salted hash, so it cannot be read back.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';

		echo '</div></div>';

		// Actions.
		echo '<div class="postbox"><h2 class="hndle"><span>' .
			esc_html__( 'Actions', 'accessible-forms-by-accessible-org' ) .
			'</span></h2><div class="inside">';
		echo '<form method="post" action="' .
			esc_url( admin_url( 'admin-post.php' ) ) .
			'" class="af-entry__actions">';
		echo '<input type="hidden" name="action" value="accessible_forms_entry_action">';
		echo '<input type="hidden" name="entry" value="' . esc_attr( (string) $entry['id'] ) . '">';
		self::view_field();
		wp_nonce_field( self::NONCE );

		if ( Capabilities::entry( $entry, 'manage_accessible_form_entries' ) ) {
			echo '<p><button class="button" name="af_do" value="unread">' .
				esc_html__( 'Mark as unread', 'accessible-forms-by-accessible-org' ) .
				'</button></p>';
			if ( in_array( $entry['status'], array( 'spam', 'review' ), true ) ) {
				echo '<p><button class="button" name="af_do" value="ham">' .
					esc_html__( 'Accept without sending email', 'accessible-forms-by-accessible-org' ) .
					'</button></p>';
				if ( Capabilities::entry( $entry, 'send_accessible_form_notifications' ) ) {
					echo '<p><button class="button" name="af_do" value="accept_notify">' .
						esc_html__( 'Accept and notify original recipients', 'accessible-forms-by-accessible-org' ) .
						'</button></p>';
				}
			} elseif ( 'trash' === $entry['status'] ) {
				echo '<p><button class="button" name="af_do" value="restore">' .
					esc_html__( 'Restore from Trash', 'accessible-forms-by-accessible-org' ) .
					'</button></p>';
			} else {
				echo '<p><button class="button" name="af_do" value="spam">' .
					esc_html__( 'Mark as spam', 'accessible-forms-by-accessible-org' ) .
					'</button></p>';
			}
		}
		if ( Capabilities::entry( $entry, 'delete_accessible_form_entries' ) ) {
			if ( 'trash' !== $entry['status'] ) {
				echo '<p><button class="button-link button-link-delete" name="af_do" value="trash">' .
					esc_html__( 'Move to Trash', 'accessible-forms-by-accessible-org' ) .
					'</button></p><p class="description">' .
					esc_html__(
						'Trash is deleted after 30 days, or earlier if the entry’s retention expires.',
						'accessible-forms-by-accessible-org'
					) .
					'</p>';
			} else {
				echo '<p><button class="button button-link-delete" name="af_do" value="delete" onclick="return confirm(' .
					esc_attr(
						wp_json_encode(
							__( 'Delete this entry and its attachments permanently?', 'accessible-forms-by-accessible-org' )
						)
					) .
					')">' .
					esc_html__( 'Delete permanently', 'accessible-forms-by-accessible-org' ) .
					'</button></p>';
			}
		}

		echo '</form></div></div>';

		echo '</div></div></div>';
	}

	/**
	 * Previous and next links.
	 *
	 * @param array $entry Current entry.
	 */
	private static function navigation( array $entry ) {
		$view = self::view();
		$prev = Entries::adjacent_id( $entry, 'prev', $view );
		$next = Entries::adjacent_id( $entry, 'next', $view );

		if ( ! $prev && ! $next ) {
			return;
		}

		echo '<nav class="af-entry__nav" aria-label="' .
			esc_attr__( 'Entry navigation', 'accessible-forms-by-accessible-org' ) .
			'">';

		if ( $prev ) {
			echo '<a class="button" href="' .
				esc_url( self::url( $prev, $view ) ) .
				'">' .
				esc_html__( '← Newer entry', 'accessible-forms-by-accessible-org' ) .
				'</a> ';
		}

		if ( $next ) {
			echo '<a class="button" href="' .
				esc_url( self::url( $next, $view ) ) .
				'">' .
				esc_html__( 'Older entry →', 'accessible-forms-by-accessible-org' ) .
				'</a>';
		}

		echo '</nav>';
	}
	private static function view( $posted = false ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Display filters only (POST callers verify their nonce). The JSON text is size-bounded, decoded, then every value is sanitized and allowlisted.
		$raw = $posted ? wp_unslash( $_POST['view'] ?? '' ) : wp_unslash( $_GET['view'] ?? '' );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$json = is_string( $raw ) ? $raw : '';
		$view = strlen( $json ) <= 4000 ? json_decode( $json, true ) : null;
		return is_array( $view ) ? Inbox::filters( \AccessibleForms\Schema::clean_input( $view ) ) : array();
	}

	/** Keep the current inbox filters through entry actions. */
	public static function view_field() {
		echo '<input type="hidden" name="view" value="' . esc_attr( wp_json_encode( self::view() ) ) . '">';
	}

	/**
	 * One metadata row.
	 *
	 * @param string $label Row label.
	 * @param string $value Value.
	 * @param string $link  Optional URL to wrap the value in.
	 */
	private static function meta_row( $label, $value, $link = '' ) {
		echo '<tr><th scope="row">' . esc_html( $label ) . '</th><td>';

		if ( $link ) {
			echo '<a href="' . esc_url( $link ) . '">' . esc_html( $value ) . '</a>';
		} else {
			echo esc_html( $value );
		}

		echo '</td></tr>';
	}
}
