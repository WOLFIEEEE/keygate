<?php
/** Progressive, accessible form setup. @package AccessibleForms */
namespace AccessibleForms\Admin;

use AccessibleForms\{Schema, Revisions, FormLibrary, Renderer, Capabilities};
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
class Flow {
	public static function init() {
		TestPreview::init();
		add_action( 'wp_ajax_accessible_forms_preview_email', array( self::class, 'preview_email' ) );
		add_action( 'wp_ajax_accessible_forms_preview_live', array( self::class, 'preview' ) );
		add_action( 'wp_ajax_accessible_forms_advice_ignore', array( self::class, 'ignore_advice' ) );
		add_action( 'wp_ajax_accessible_forms_page_options', array( self::class, 'pages' ) );
		add_action( 'wp_ajax_accessible_forms_restore_local', array( self::class, 'restore_local' ) );
		add_filter(
			'enter_title_here',
			static function ( $text, $post ) {
				return 'accessible_form' === $post->post_type
					? __( 'Form name, e.g. Contact our team', 'accessible-forms-by-accessible-org' )
					: $text;
			},
			10,
			2
		);
	}
	public static function assets() {
		wp_register_script( 'accessible-forms-admin-search', ACCESSIBLE_FORMS_URL . 'assets/admin-search.js', array(), \AccessibleForms\VERSION, true );
		$templates = array();
		foreach ( FormLibrary::templates() as $key => $label ) {
			$templates[ $key ] = FormLibrary::template( $key );
		}
		wp_enqueue_script(
			'accessible-forms-flow',
			ACCESSIBLE_FORMS_URL . 'assets/editor-flow.js',
			array( 'accessible-forms-admin', 'accessible-forms-appearance', 'accessible-forms-admin-search', 'wp-i18n' ),
			\AccessibleForms\VERSION,
			true
		);
		wp_set_script_translations( 'accessible-forms-flow', 'accessible-forms-by-accessible-org' );
		$post   = get_post();
		$errors = array();
		if ( $post ) {
			// Read before admin_notices prints and clears them, so the editor can mark each control.
			$issues = Admin::pending_errors( $post->ID );
			if ( ! $issues && current_user_can( 'edit_post', $post->ID ) ) {
				// Edits kept with problems, or a saved form that fails the current checks.
				$issues = \AccessibleForms\FormCheck::issues( $post->ID );
			}
			foreach ( $issues as $issue ) {
				$issue['target'] = Admin::issue_target( $issue );
				$errors[]        = $issue;
			}
		}
		wp_localize_script(
			'accessible-forms-flow',
			'AccessibleFormsFlow',
			array(
				'templates'      => $templates,
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'postId'         => $post ? (int) $post->ID : 0,
				'siteId'         => get_current_blog_id(),
				'siteKey'        => hash( 'sha256', site_url( '/' ) . ':' . get_current_blog_id() ),
				'userId'         => get_current_user_id(),
				'serverModified' => $post ? (int) get_post_modified_time( 'U', true, $post ) : 0,
				'serverNow'      => time(),
				'saveErrors'     => $errors,
			)
		);
	}

	/** Transient holding locally saved edits the owner chose to restore, read once. */
	const RESTORED = 'accessible_forms_restored_';

	/**
	 * Accept unsaved edits kept in this browser, so the next page load renders
	 * them with the same server code that renders a rejected save. Nothing is
	 * saved to the form itself.
	 */
	public static function restore_local() {
		check_ajax_referer( Admin::NONCE, Admin::NONCE . '_nonce' );
		$id = absint( $_POST['post_ID'] ?? 0 );
		if ( ! $id || 'accessible_form' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot change this form.', 'accessible-forms-by-accessible-org' ) ), 403 );
		}
		$raw = self::submitted();
		if ( ! $raw ) {
			wp_send_json_error( array( 'message' => __( 'The saved changes could not be read.', 'accessible-forms-by-accessible-org' ) ), 400 );
		}
		$key = self::RESTORED . $id . '_' . get_current_user_id();
		set_transient( $key, $raw, 300 );
		if ( get_transient( $key ) !== $raw ) {
			wp_send_json_error( array( 'message' => __( 'The changes could not be restored. Your browser recovery copy is kept; try again.', 'accessible-forms-by-accessible-org' ) ), 503 );
		}
		wp_send_json_success();
	}

	/**
	 * Take locally saved edits chosen for restoring, if any. They apply once.
	 *
	 * @param int $id Form ID.
	 * @return array|null Raw schema input, sanitized as text.
	 */
	public static function take_restored( $id ) {
		$key      = self::RESTORED . (int) $id . '_' . get_current_user_id();
		$restored = get_transient( $key );
		if ( ! is_array( $restored ) ) {
			return null;
		}
		delete_transient( $key );
		return $restored;
	}
	public static function top( $post, array $schema ) {
		$state = Revisions::has_draft( $post->ID ) ? 'draft' : ( 'publish' === $post->post_status ? 'published' : 'unpublished' );
		echo '<input type="hidden" name="af_edit_version" value="' .
			esc_attr( Revisions::token( $post->ID ) ) .
			'"><input type="hidden" name="af_editor_format" value="2">';
		echo '<div class="af-flow-heading"><div class="af-flow-copy"><p class="af-workspace-label">' . esc_html__( 'Form workspace', 'accessible-forms-by-accessible-org' ) . '</p><p>' .
			esc_html(
				'publish' === $post->post_status
					? __( 'Edit a draft, check the preview, then publish your changes.', 'accessible-forms-by-accessible-org' )
					: __(
						'Start with a simple form. Customize it, choose who receives messages, then publish.',
						'accessible-forms-by-accessible-org'
					)
			) .
			'</p></div><span class="af-flow-state" data-state="' . esc_attr( $state ) . '">' .
			esc_html(
				Revisions::has_draft( $post->ID )
					? __( 'Draft changes', 'accessible-forms-by-accessible-org' )
					: ( 'publish' === $post->post_status
						? __( 'Published', 'accessible-forms-by-accessible-org' )
						: __( 'Unpublished', 'accessible-forms-by-accessible-org' ) )
			) .
			'</span></div>';
		$saved = Revisions::has_draft( $post->ID ) ? __( 'Draft changes saved', 'accessible-forms-by-accessible-org' ) : ( 'publish' === $post->post_status ? __( 'Published', 'accessible-forms-by-accessible-org' ) : __( 'Draft saved', 'accessible-forms-by-accessible-org' ) );
		if ( 'auto-draft' === $post->post_status ) { $saved = __( 'Form not yet saved', 'accessible-forms-by-accessible-org' ); }
		elseif ( $post->post_modified_gmt && '0000-00-00 00:00:00' !== $post->post_modified_gmt ) { $saved .= ' · ' . wp_date( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $post->post_modified_gmt . ' UTC' ) ); }
		echo '<p id="af-save-status" class="af-save-status" role="status" aria-atomic="true">' . esc_html( $saved ) . '</p>';
		echo '<nav class="af-flow-nav" aria-label="' .
			esc_attr__( 'Form setup steps', 'accessible-forms-by-accessible-org' ) .
			'">';
		foreach (
			array(
				'build'    => __( 'Build', 'accessible-forms-by-accessible-org' ),
				'style'    => __( 'Style', 'accessible-forms-by-accessible-org' ),
				'delivery' => __( 'Email & confirmation', 'accessible-forms-by-accessible-org' ),
				'review'   => __( 'Review & publish', 'accessible-forms-by-accessible-org' ),
			)
			as $key => $label
		) {
			echo '<a href="#af-step-' .
				esc_attr( $key ) .
				'" data-af-go="' .
				esc_attr( $key ) .
				'">' .
				esc_html( $label ) .
				'</a>';
		}
		echo '</nav>';
		if ( 'auto-draft' === $post->post_status ) {
			echo '<details class="af-starter-picker" data-af-editor-step="build"><summary>' .
				esc_html__( 'Starting with a contact form · Change template', 'accessible-forms-by-accessible-org' ) .
				'</summary><p class="description">' .
				esc_html__(
					'Templates replace the fields below. Your form name and email recipients stay as you set them.',
					'accessible-forms-by-accessible-org'
				) .
				'</p><div class="af-starter-options">';
			foreach ( FormLibrary::templates() as $key => $label ) {
				echo '<button type="button" class="button" data-af-template="' .
					esc_attr( $key ) .
					'">' .
					esc_html( $label ) .
					'</button>';
			}
			echo '</div><p class="af-template-confirm" hidden>' .
				esc_html__( 'Replace your current fields with this template?', 'accessible-forms-by-accessible-org' ) .
				' <button type="button" class="button" id="af-confirm-template">' .
				esc_html__( 'Replace fields', 'accessible-forms-by-accessible-org' ) .
				'</button> <button type="button" class="button-link" id="af-cancel-template">' .
				esc_html__( 'Keep my fields', 'accessible-forms-by-accessible-org' ) .
				'</button></p></details>';
		}
	}
	public static function review( $post, $schema = null ) {
		$schema = is_array( $schema ) ? $schema : ( Schema::get( $post->ID, true ) ?: Schema::defaults() );
		echo '<section class="af-editor-section af-review-main" data-af-editor-step="review"><h3>' .
			esc_html__( 'Check your form', 'accessible-forms-by-accessible-org' ) .
			'</h3><p>' .
			esc_html__(
				'Preview the fields and review delivery before you publish. The preview cannot send messages. Publishing changes updates every page using this form.',
				'accessible-forms-by-accessible-org'
			) .
			'</p><div id="af-publication-checks" class="af-review-checks" role="region" tabindex="-1" aria-labelledby="af-publication-checks-title"><h4 id="af-publication-checks-title">' .
			esc_html__( 'Accessibility checks before publishing', 'accessible-forms-by-accessible-org' ) . '</h4><div class="af-publication-result">' .
			esc_html__( 'Publishing runs the automatic checks again. Fix every blocking problem and confirm the review below. Passing these checks does not certify accessibility.', 'accessible-forms-by-accessible-org' ) . '</div></div>';
		// Keep the required author confirmation visible beside the automatic checks.
		echo '<div class="af-review-manual af-review-author"><h4>' . esc_html__( 'Required author review', 'accessible-forms-by-accessible-org' ) . '</h4>';
		echo '<p id="af-accessibility-review-help">' . esc_html__( 'Required before each publication. Review the questions, choices, instructions and messages for clarity; automatic checks cannot judge their meaning. After placing the form, repeat keyboard, zoom and screen reader checks with your theme. This confirmation is an author review, not a WCAG certification.', 'accessible-forms-by-accessible-org' ) . '</p><label class="af-publication-confirm"><input type="checkbox" id="af-accessibility-reviewed" name="af_accessibility_reviewed" value="1" aria-required="true" aria-describedby="af-accessibility-review-help"> <span>' .
			esc_html__( 'I reviewed the form’s questions and instructions and understand the page checks still required before sharing it with visitors.', 'accessible-forms-by-accessible-org' ) . '</span></label>';
		echo '<details class="af-review-instructions"><summary>' . esc_html__( 'How to review this form', 'accessible-forms-by-accessible-org' ) . '</summary><p>' .
			esc_html__( 'The automatic checks catch missing labels, low contrast and broken structure. They cannot tell whether your questions make sense. These take a few minutes:', 'accessible-forms-by-accessible-org' ) . '</p><ul>';
		foreach (
			array(
				__( 'Read each label on its own. Does it say exactly what to enter, without the rest of the page?', 'accessible-forms-by-accessible-org' ),
				__( 'Open the keyboard test preview. Use Tab and Shift+Tab, arrow keys for radio choices, and Space for checkboxes. Reach every question and the send button, including conditional questions and each step.', 'accessible-forms-by-accessible-org' ),
				__( 'Switch the preview to “Validation errors”. Does each message say how to fix the answer?', 'accessible-forms-by-accessible-org' ),
				__( 'Try the test page at a narrow width and 200% zoom. Labels, instructions and errors must stay readable and controls must remain reachable.', 'accessible-forms-by-accessible-org' ),
				__( 'Check the test page with a screen reader, such as VoiceOver or NVDA. Questions, required states, choices, steps and errors should make sense when heard.', 'accessible-forms-by-accessible-org' ),
				__( 'After placing the form, open its page while logged in. The live check tests it with your theme and lists anything to fix.', 'accessible-forms-by-accessible-org' ),
			)
			as $prompt
		) {
			echo '<li>' . esc_html( $prompt ) . '</li>';
		}
		echo '</ul></details></div>';
		echo '<section class="af-review-testing" aria-labelledby="af-review-testing-title"><h4 id="af-review-testing-title">' . esc_html__( 'Preview and test', 'accessible-forms-by-accessible-org' ) . '</h4>';
		echo '<div class="af-preview-toolbar"><button type="button" class="button" id="af-refresh-preview">' .
			esc_html__( 'Refresh preview', 'accessible-forms-by-accessible-org' ) .
			'</button><label for="af-preview-width">' .
			esc_html__( 'Preview width', 'accessible-forms-by-accessible-org' ) .
			'</label><select id="af-preview-width"><option value="wide">' .
			esc_html__( 'Desktop', 'accessible-forms-by-accessible-org' ) .
			'</option><option value="narrow">' .
			esc_html__( 'Mobile', 'accessible-forms-by-accessible-org' ) .
			'</option></select><label for="af-preview-state">' .
			esc_html__( 'Preview state', 'accessible-forms-by-accessible-org' ) .
			'</label><select id="af-preview-state"><option value="normal">' .
			esc_html__( 'Normal', 'accessible-forms-by-accessible-org' ) .
			'</option><option value="errors">' .
			esc_html__( 'Validation errors', 'accessible-forms-by-accessible-org' ) .
			'</option><option value="success">' .
			esc_html__( 'Confirmation', 'accessible-forms-by-accessible-org' ) .
			'</option></select></div><div id="af-live-preview" tabindex="-1"><p>' .
			esc_html__( 'Choose Refresh preview to see your current changes.', 'accessible-forms-by-accessible-org' ) .
			'</p></div>';
		echo '<p><button type="button" class="button" id="af-test-preview" aria-describedby="af-test-preview-help" hidden>' . esc_html__( 'Open keyboard test preview', 'accessible-forms-by-accessible-org' ) . '</button> <span id="af-test-preview-status" role="status"></span></p><p class="description" id="af-test-preview-help">' .
			esc_html__( 'Opens your current changes in a private test page in a new tab. Try the questions, errors, steps and confirmation. No entries, files or emails are saved. Your theme and spam verification are tested on the page where you place the form.', 'accessible-forms-by-accessible-org' ) . '</p><noscript><p class="description" id="af-test-preview-script-help">' .
			esc_html__( 'To open a private test preview, enable JavaScript. You can still save draft changes and use the required publication review below. Test the placed form on staging before sharing it with visitors.', 'accessible-forms-by-accessible-org' ) . '</p></noscript>';
		$pages = TestPreview::page_options();
		echo '<details class="af-theme-preview af-review-manual"><summary>' . esc_html__( 'Test current edits with your site theme', 'accessible-forms-by-accessible-org' ) . '</summary><p id="af-theme-preview-help" class="description">' . esc_html__( 'Choose a page you can edit. A private snapshot replaces this form at its existing location; if it is not placed yet, it appears at the end of the page content. Neither the page nor the live form is changed. The preview opens in a new tab and expires after 30 minutes.', 'accessible-forms-by-accessible-org' ) . '</p><label for="af-test-page">' . esc_html__( 'Page for the private theme preview', 'accessible-forms-by-accessible-org' ) . '</label><select id="af-test-page" aria-describedby="af-theme-preview-help"><option value="0">' . esc_html__( 'Choose a page', 'accessible-forms-by-accessible-org' ) . '</option>';
		foreach ( $pages['items'] as $page ) { echo '<option value="' . esc_attr( $page['id'] ) . '">' . esc_html( $page['title'] ) . '</option>'; }
		echo '</select><div id="af-test-page-search" data-more="' . esc_attr( $pages['pages'] > 1 ? '1' : '0' ) . '" hidden><label for="af-find-test-page">' . esc_html__( 'Find a page to test', 'accessible-forms-by-accessible-org' ) . '</label><input type="search" id="af-find-test-page" maxlength="200"><button type="button" class="button" id="af-search-test-pages">' . esc_html__( 'Search pages', 'accessible-forms-by-accessible-org' ) . '</button> <button type="button" class="button" id="af-more-test-pages" hidden>' . esc_html__( 'Load more pages', 'accessible-forms-by-accessible-org' ) . '</button><span id="af-test-page-search-status" role="status" aria-atomic="true"></span></div><p><button type="button" class="button" id="af-theme-test-preview" hidden>' . esc_html__( 'Open private theme preview', 'accessible-forms-by-accessible-org' ) . '</button> <span id="af-theme-test-status" role="status" aria-atomic="true"></span></p><noscript><p>' . esc_html__( 'Opening a snapshot with your theme requires JavaScript. You can still save a draft, record manual test results below, and test the placed form on a staging page.', 'accessible-forms-by-accessible-org' ) . '</p></noscript></details>';
		AccessibilityReview::panel( $post->ID, $schema );
		echo '</section>';
		$live_rows = array_filter( \AccessibleForms\LiveCheck::rows(), static function ( $row ) use ( $post ) { return (int) $post->ID === $row['form_id']; } );
		if ( $live_rows ) {
			echo '<div class="af-review-manual"><h4>' . esc_html__( 'Checks on the pages using this form', 'accessible-forms-by-accessible-org' ) . '</h4><ul>';
			foreach ( $live_rows as $row ) {
				$state = $row['stale'] ? __( 'Out of date: check this page again.', 'accessible-forms-by-accessible-org' ) :
					( $row['issues'] ? __( 'Accessibility problems detected. Fix the page or theme and check again before sharing it.', 'accessible-forms-by-accessible-org' ) :
						( $row['unverified'] ? __( 'Some checks could not be completed. Manual review is required.', 'accessible-forms-by-accessible-org' ) : __( 'No problems detected by the live check. Manual review is still required.', 'accessible-forms-by-accessible-org' ) ) );
				echo '<li><a href="' . esc_url( \AccessibleForms\LiveCheck::page_url( $row['path'] ) ) . '">' . esc_html( $row['path'] ) . '</a> — ' . esc_html( $state ) . '</li>';
			}
			echo '</ul></div>';
		}
		// What to do once the form is published, grouped apart from the preview.
		echo '<section class="af-review-next" aria-labelledby="af-review-next-title"><h4 id="af-review-next-title">' . esc_html__( 'After publishing', 'accessible-forms-by-accessible-org' ) . '</h4><p class="description">' .
			esc_html__(
				'Publish the form, then choose a page, post or block. Publishing the form alone does not add it to your site.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		if ( 'publish' === $post->post_status ) {
			echo '<p><strong>' . esc_html__( 'Choose where visitors see this form', 'accessible-forms-by-accessible-org' ) . '</strong></p>';
			$summary = Placement::summary( $post->ID );
			if ( $summary ) {
				echo '<p>' . esc_html( $summary ) . '</p>';
			}
			echo '<p class="af-review-next__actions"><a class="button button-primary" href="' .
				esc_url( Placement::url( $post->ID ) ) .
				'">' .
				esc_html__( 'Choose where it appears', 'accessible-forms-by-accessible-org' ) .
				'</a> <a href="' .
				esc_url( Management::url( 'usage', array( 'form_id' => $post->ID ) ) ) .
				'">' .
				esc_html__( 'See where this form is used', 'accessible-forms-by-accessible-org' ) .
				'</a></p>';
		}
		if ( Capabilities::form( $post->ID ) && 'auto-draft' !== $post->post_status ) {
			$links = (array) \AccessibleForms\Extensions::filter(
				'accessible_forms_review_links',
				array( EntriesTable::url( array( 'form_id' => $post->ID ) ) => __( 'View this form’s submissions', 'accessible-forms-by-accessible-org' ) ),
				$post->ID
			);
			echo '<p class="af-review-next__links">';
			foreach ( $links as $url => $label ) {
				echo '<a href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a> ';
			}
			echo '</p>';
		}
		Experience::setup( $post, Schema::get( $post->ID ) ?: array() );
		echo '</section></section>';
		echo '<div class="af-flow-footer"><button type="button" class="button" id="af-step-back" hidden>' .
			esc_html__( 'Back', 'accessible-forms-by-accessible-org' ) .
			'</button><span class="af-step-count" aria-live="polite"></span><button type="submit" name="save" value="1" class="button" id="af-save-draft">' .
			esc_html(
				'publish' === $post->post_status
					? __( 'Save draft changes', 'accessible-forms-by-accessible-org' )
					: __( 'Save draft', 'accessible-forms-by-accessible-org' )
			) .
			'</button><button type="button" class="button button-primary" id="af-step-next" hidden>' .
			esc_html__( 'Continue', 'accessible-forms-by-accessible-org' ) .
			'</button>';
		if ( current_user_can( 'publish_accessible_forms' ) ) {
			echo '<button type="submit" class="button button-primary" id="af-flow-publish" name="' .
				esc_attr( 'publish' === $post->post_status ? 'af_publish_changes' : 'publish' ) .
				'" value="1">' .
				esc_html(
					'publish' === $post->post_status
						? __( 'Publish changes', 'accessible-forms-by-accessible-org' )
						: __( 'Publish form', 'accessible-forms-by-accessible-org' )
				) .
				'</button>';
		}
		echo '</div>';
	}
	/** A bounded page catalog, shared by the initial selector and its search. */
	public static function page_options( $search = '', $page = 1 ) {
		$query = new \WP_Query(
			array(
				'post_type'      => 'page',
				'post_status'    => 'publish',
				'has_password'   => false,
				'posts_per_page' => 20,
				'paged'          => max( 1, (int) $page ),
				's'              => wp_html_excerpt( sanitize_text_field( $search ), 200, '' ),
				'orderby'        => array(
					'title' => 'ASC',
					'ID'    => 'ASC',
				),
			)
		);
		return array(
			'items' => array_map( array( self::class, 'page_option' ), $query->posts ),
			'pages' => (int) $query->max_num_pages,
		);
	}

	/** Include a unique identity and a safe preview link for similarly named pages. */
	private static function page_option( $page ) {
		$title = $page->post_title ?: __( '(no title)', 'accessible-forms-by-accessible-org' );
		return array(
			'id'    => (int) $page->ID,
			/* translators: 1: content title, 2: unique content ID. */
			'title' => sprintf( __( '%1$s · #%2$d', 'accessible-forms-by-accessible-org' ), $title, $page->ID ),
			'url'   => 'publish' === $page->post_status && '' === $page->post_password ? get_permalink( $page ) : '',
		);
	}

	public static function page_picker( $selected ) {
		$catalog = self::page_options();
		$options = array( 0 => __( 'Show the confirmation message here', 'accessible-forms-by-accessible-org' ) );
		$urls    = array();
		foreach ( $catalog['items'] as $page ) {
			$options[ $page['id'] ] = $page['title'];
			$urls[ $page['id'] ]    = $page['url'];
		}
		if ( $selected && ! isset( $options[ $selected ] ) ) {
			$page = get_post( $selected );
			if ( $page && 'page' === $page->post_type && 'publish' === $page->post_status && '' === $page->post_password ) {
				$item                 = self::page_option( $page );
				$options[ $selected ] = $item['title'];
				$urls[ $selected ]    = $item['url'];
			} else {
				/* translators: %d: selected page ID. */
				$options[ $selected ] = sprintf( __( 'Unavailable page · #%d — choose another page', 'accessible-forms-by-accessible-org' ), $selected );
			}
		}
		echo '<details class="af-confirmation-redirect"' . ( $selected ? ' open' : '' ) . '><summary>' . esc_html__( 'Use a thank-you page (optional)', 'accessible-forms-by-accessible-org' ) . '</summary>';
		Editor::select( 'af_schema[confirmation_page]', __( 'After submission', 'accessible-forms-by-accessible-org' ), $options, $selected );
		echo '<p class="af-confirmation-page-link" hidden><a id="af-view-confirmation-page" target="_blank" rel="noopener">' . esc_html__( 'View selected page (new tab)', 'accessible-forms-by-accessible-org' ) . '</a></p><div class="af-page-picker-search" data-page-urls="' . esc_attr( wp_json_encode( $urls ) ) . '" data-more="' . esc_attr( $catalog['pages'] > 1 ? '1' : '0' ) . '" hidden><label for="af-find-confirmation-page">' . esc_html__( 'Find a page', 'accessible-forms-by-accessible-org' ) . '</label><div><input type="search" id="af-find-confirmation-page" maxlength="200" aria-describedby="af-confirmation-page-help"><button type="button" class="button" id="af-search-confirmation-page">' . esc_html__( 'Search pages', 'accessible-forms-by-accessible-org' ) . '</button><button type="button" class="button" id="af-more-confirmation-pages" hidden>' . esc_html__( 'Load more pages', 'accessible-forms-by-accessible-org' ) . '</button></div><p id="af-page-picker-status" role="status" aria-atomic="true"></p></div><p class="description" id="af-confirmation-page-help">' . esc_html__( 'Only public pages on this site are available. Search adds matching pages to After submission and keeps your current choice. Submitted answers stay out of the page address.', 'accessible-forms-by-accessible-org' ) . '</p></details>';
	}

	public static function pages() {
		check_ajax_referer( Admin::NONCE, Admin::NONCE . '_nonce' );
		if ( ! current_user_can( 'edit_accessible_forms' ) ) {
			wp_send_json_error( array(), 403 );
		}
		wp_send_json_success( self::page_options( sanitize_text_field( wp_unslash( $_POST['search'] ?? '' ) ), max( 1, absint( $_POST['page'] ?? 1 ) ) ) );
	}

	/** Decode one bounded JSON parameter so a large form does not hit max_input_vars. */
	public static function submitted() {
		// phpcs:disable WordPress.Security.NonceVerification.Missing -- All callers verify the form nonce and edit capability before reading schema input.
		if ( isset( $_POST['af_schema_json'] ) ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- Raw JSON text is size-bounded, decoded, then every decoded string is sanitized.
			$json = is_string( $_POST['af_schema_json'] ) ? wp_unslash( $_POST['af_schema_json'] ) : '';
			$raw  = strlen( $json ) <= 262144 ? json_decode( $json, true, 32 ) : null;
			return is_array( $raw ) ? \AccessibleForms\Schema::clean_input( $raw ) : array();
		}
		$native = isset( $_POST['af_schema'] ) && is_array( $_POST['af_schema'] )
			? map_deep( wp_unslash( $_POST['af_schema'] ), 'sanitize_textarea_field' )
			: array();
		// phpcs:enable WordPress.Security.NonceVerification.Missing
		return $native;
	}
	public static function preview() {
		check_ajax_referer( Admin::NONCE, Admin::NONCE . '_nonce' );
		$id = absint( $_POST['post_ID'] ?? 0 );
		if ( ! $id || 'accessible_form' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot preview this form.', 'accessible-forms-by-accessible-org' ) ), 403 );
		}
		[$schema, $issues] = Schema::validate( Admin::submitted_schema( $id ) );
		$errors            = Schema::messages( $issues );
		$context           = sanitize_key( wp_unslash( $_POST['af_preview_context'] ?? '' ) );
		if ( 'style' === $context ) {
			wp_send_json_success(
				array(
					'errors' => array(),
					'html'   => self::style_preview( $id, $schema ),
				)
			);
		}
		if ( $errors ) {
			foreach ( $issues as $number => $issue ) {
				$issues[ $number ]['target'] = Admin::issue_target( $issue );
			}
			wp_send_json_success(
				array(
					'errors' => $errors,
					'issues' => $issues,
					'html'   => '',
				)
			);
		}
		$state = array();
		$mode  = sanitize_key( wp_unslash( $_POST['af_preview_state'] ?? 'normal' ) );
		if ( 'success' === $mode ) {
			$state['sent'] = true;
		}
		if ( 'errors' === $mode ) {
			foreach ( $schema['fields'] as $field ) {
				if ( 'section' !== $field['type'] ) {
					$state['errors'][ $field['name'] ] = __(
						'Enter an answer for this field.',
						'accessible-forms-by-accessible-org'
					);
					break;
				}
			}
		}
		$html = Renderer::render( $id, $state, true, $schema );
		$html = str_replace( array( '<form ', '</form>', ' autofocus' ), array( '<div role="form" ', '</div>', '' ), $html );
		$html = preg_replace( '/(<(?:input|textarea|select|button)\b)/', '$1 disabled', $html );
		wp_send_json_success(
			array(
				'errors' => array(),
				'html'   => $html,
				'advice' => self::advice( $id, $schema ),
			)
		);
	}

	/**
	 * The owner's own fields, rendered by the public renderer, with example
	 * states so every style is visible: an error, a checked choice and (marked
	 * for the editor script) a focused field. Nothing in it can be submitted.
	 *
	 * Fields that do not validate yet are left out; the Review step lists them.
	 *
	 * @param int   $id     Form ID.
	 * @param array $schema Sanitized draft schema.
	 * @return string
	 */
	public static function style_preview( $id, array $schema ) {
		$state = array(
			'errors' => array(),
			'values' => array(),
		);
		foreach ( $schema['fields'] as $field ) {
			if ( in_array( $field['type'], array( 'section', 'radio', 'checkbox', 'consent', 'file' ), true ) ) {
				continue;
			}
			$state['errors'][ $field['name'] ] = __( 'Example: this is how an error message looks.', 'accessible-forms-by-accessible-org' );
			break;
		}
		foreach ( $schema['fields'] as $field ) {
			if ( in_array( $field['type'], array( 'radio', 'checkbox' ), true ) && ! empty( $field['options'] ) ) {
				$state['values'][ $field['name'] ] = 'checkbox' === $field['type'] ? array( $field['options'][0] ) : $field['options'][0];
				break;
			}
			if ( 'consent' === $field['type'] ) {
				$state['values'][ $field['name'] ] = '1';
				break;
			}
		}
		$html = Renderer::render( $id, $state, true, $schema );
		$html = str_replace( array( '<form ', '</form>', ' autofocus' ), array( '<div role="group" ', '</div>', '' ), $html );
		// A sample inside the editor adds no headings to the editor's outline.
		$html = preg_replace( '#<(h[1-6]) class="af-summary__heading">(.*?)</\1>#s', '<p class="af-summary__heading">$2</p>', $html );
		// Keep the real styles (not the disabled look) but make every control inert to typing.
		$html = preg_replace( '/(<(?:input|textarea|select)\b)/', '$1 readonly tabindex="-1"', $html );
		// readonly does not stop clicks on choices or menus; the preview body blocks pointer input in CSS.
		$html = str_replace( 'type="submit"', 'type="button"', $html );
		$html = preg_replace( '/(<button\b)(?![^>]*\btype=)/', '$1 type="button"', $html );
		$html = preg_replace( '/(<button\b)/', '$1 tabindex="-1"', $html );
		return (string) $html;
	}

	/** Post meta holding suggestion keys the editor chose to ignore for a form. */
	const IGNORED = '_accessible_forms_advice_ignored';

	/**
	 * Content suggestions for the current draft of a form.
	 *
	 * @param int   $id     Form ID.
	 * @param array $schema Sanitized draft schema.
	 * @return array[]
	 */
	public static function advice( $id, array $schema ) {
		$places  = 'publish' === get_post_status( $id ) ? Placement::heading_contexts( $id ) : array( 'places' => array() );
		$ignored = get_post_meta( $id, self::IGNORED, true );
		// The scan is shared by everyone; only name pages this person can edit.
		$visible = array_values(
			array_filter(
				$places['places'],
				static function ( $place ) {
					return current_user_can( 'edit_post', $place['id'] );
				}
			)
		);
		$context = array(
			'places'  => $visible,
			'more'    => ! empty( $places['more'] ),
			'ignored' => is_array( $ignored ) ? $ignored : array(),
		);
		// Add-ons may add context of their own, such as correction counts.
		$context = (array) \AccessibleForms\Extensions::filter( 'accessible_forms_content_context', $context, (int) $id );
		return \AccessibleForms\ContentCheck::run( $schema, $context );
	}

	/** Ignore or restore one suggestion for a form. */
	public static function ignore_advice() {
		check_ajax_referer( Admin::NONCE, Admin::NONCE . '_nonce' );
		$id = absint( $_POST['post_ID'] ?? 0 );
		if ( ! $id || 'accessible_form' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			wp_send_json_error( array( 'message' => __( 'You cannot change this form.', 'accessible-forms-by-accessible-org' ) ), 403 );
		}
		$key     = isset( $_POST['key'] ) ? sanitize_text_field( wp_unslash( $_POST['key'] ) ) : '';
		$restore = ! empty( $_POST['restore'] );
		if ( ! preg_match( '/^[a-z_]{3,40}:[A-Za-z0-9_-]{0,64}$/', $key ) ) {
			wp_send_json_error( array( 'message' => __( 'Unknown suggestion.', 'accessible-forms-by-accessible-org' ) ), 400 );
		}
		$ignored = get_post_meta( $id, self::IGNORED, true );
		$ignored = is_array( $ignored ) ? $ignored : array();
		$ignored = $restore ? array_values( array_diff( $ignored, array( $key ) ) ) : array_values( array_unique( array_merge( $ignored, array( $key ) ) ) );
		$ignored = array_slice( $ignored, -200 );
		update_post_meta( $id, self::IGNORED, $ignored );
		wp_send_json_success( array( 'ignored' => $ignored ) );
	}
	public static function preview_email() {
		check_ajax_referer( Admin::NONCE, Admin::NONCE . '_nonce' );
		$id = absint( $_POST['post_ID'] ?? 0 );
		if ( 'accessible_form' !== get_post_type( $id ) || ! current_user_can( 'edit_post', $id ) ) {
			wp_send_json_error( array(), 403 );
		}
		[$schema, $errors] = Schema::sanitize( Admin::submitted_schema( $id ) );
		if ( $errors ) {
			wp_send_json_error( array( 'message' => implode( ' ', $errors ) ), 400 );
		}
		$values = array();
		foreach ( $schema['fields'] as $field ) {
			if ( 'section' === $field['type'] ) {
				continue;
			}
			$value = $field['options'][0] ?? __( 'Sample answer', 'accessible-forms-by-accessible-org' );
			if ( 'email' === $field['type'] ) {
				$value = 'visitor@example.com';
			}
			$values[ $field['name'] ] = $value;
		}
		$entry   = array(
			'id'       => 0,
			'form_id'  => $id,
			'fields'   => $values,
			'snapshot' => array(
				'schema' => $schema,
				'title'  => $schema['heading'],
			),
		);
		$configs = \AccessibleForms\Notifications::configurations( $schema, $entry, false );
		$html    = '';
		foreach ( $configs as $config ) {
			$mail = 'email' === \AccessibleForms\Notifications::channel( $config ) ? \AccessibleForms\Notifications::message( $entry, $config ) : null;
			if ( ! $mail ) {
				continue;
			}
			$html .=
				'<section class="af-email-sample"><h3>' .
				esc_html( $config['name'] ) .
				'</h3><p><strong>' .
				esc_html__( 'Recipients:', 'accessible-forms-by-accessible-org' ) .
				'</strong> ' .
				esc_html( implode( ', ', $config['recipients'] ) ) .
				'</p><p><strong>' .
				esc_html__( 'Subject:', 'accessible-forms-by-accessible-org' ) .
				'</strong> ' .
				esc_html( $mail['subject'] ) .
				'</p>';
			$html .=
				in_array( 'Content-Type: text/html; charset=UTF-8', $mail['headers'], true )
					? '<div>' . wp_kses(
						// Drop the document head (only a title), and show the email's own
						// heading as bold text so this screen's heading levels stay intact.
						preg_replace(
							array( '#<head\b.*?</head>#is', '#<h1\b[^>]*>(.*?)</h1>#is' ),
							array( '', '<p><strong>$1</strong></p>' ),
							$mail['message']
						),
						array(
							'p'       => array(),
							'br'      => array(),
							'strong'  => array(),
							'a'       => array( 'href' => true ),
							'table'   => array(),
							'caption' => array(),
							'tbody'   => array(),
							'tr'      => array(),
							'th'      => array( 'scope' => true ),
							'td'      => array(),
						)
					) . '</div>'
					: '<pre>' . esc_html( $mail['message'] ) . '</pre>';
			$html .= '</section>';
		}
		wp_send_json_success(
			array(
				'html'    => $html,
				'message' => __(
					'Sample only. No email was sent. Conditional notifications use the first choice in each field; review other routes in their settings. Test actual delivery from Settings → Email.',
					'accessible-forms-by-accessible-org'
				),
			)
		);
	}
}
