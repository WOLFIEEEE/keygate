<?php
/**
 * A single place to choose manual, automatic or block placement.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms\Admin;

use AccessibleForms\{ContentTypes, Schema, Extensions};

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/** Accessible placement workflows. Add-ons can add tabs, such as automatic placement. */
class PlacementScreen {
	public static function init() {
	}

	public static function can_view() {
		return current_user_can( 'edit_accessible_forms' ) || (bool) ContentTypes::types( true );
	}

	public static function render() {
		if ( ! self::can_view() ) {
			wp_die( esc_html__( 'You cannot place forms on this site.', 'accessible-forms-by-accessible-org' ), '', array( 'response' => 403 ) );
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only screen selection. Changes verify a POST nonce and capabilities.
		$id    = absint( $_GET['form_id'] ?? 0 );
		$mode  = sanitize_key( wp_unslash( $_GET['af_mode'] ?? 'manual' ) );
		$saved = ! empty( $_GET['af_saved'] );
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		if ( ! Schema::get( $id ) ) {
			wp_die( esc_html__( 'Publish this form before choosing where it appears.', 'accessible-forms-by-accessible-org' ), '', array( 'back_link' => true ) );
		}
		$tabs = (array) Extensions::filter(
			'accessible_forms_placement_tabs',
			array(
				'manual' => __( 'One page or post', 'accessible-forms-by-accessible-org' ),
				'block'  => __( 'Block or shortcode', 'accessible-forms-by-accessible-org' ),
			),
			$id
		);
		if ( ! isset( $tabs[ $mode ] ) ) {
			$mode = 'manual';
		}
		// Shared with add-on tabs that search content.
		wp_register_script( 'accessible-forms-admin-search', ACCESSIBLE_FORMS_URL . 'assets/admin-search.js', array(), \AccessibleForms\VERSION, true );
		wp_enqueue_script( 'accessible-forms-placement-settings', ACCESSIBLE_FORMS_URL . 'assets/placement-settings.js', array( 'wp-i18n' ), \AccessibleForms\VERSION, true );
		wp_set_script_translations( 'accessible-forms-placement-settings', 'accessible-forms-by-accessible-org' );
		$async_tabs = (array) Extensions::filter( 'accessible_forms_async_tabs', array( 'manual', 'block' ), 'placement' );
		echo '<div class="wrap af-placement" data-af-tabs="placement-' . esc_attr( (string) $id ) . '"><h1>' . esc_html__( 'Where this form appears', 'accessible-forms-by-accessible-org' ) . '</h1><p class="af-page-description"><strong>' . esc_html( get_the_title( $id ) ) . '</strong> — ' . esc_html__( 'Use the same accessible form in one place or across your site.', 'accessible-forms-by-accessible-org' ) . '</p>';
		if ( current_user_can( 'edit_post', $id ) ) {
			echo '<p><a href="' . esc_url( get_edit_post_link( $id, 'raw' ) . '#af-step-review' ) . '">' . esc_html__( 'Back to form settings', 'accessible-forms-by-accessible-org' ) . '</a></p>';
		}
		echo '<nav class="nav-tab-wrapper" aria-label="' . esc_attr__( 'Placement methods', 'accessible-forms-by-accessible-org' ) . '">';
		foreach ( $tabs as $key => $label ) {
			echo '<a class="nav-tab' . ( $key === $mode ? ' nav-tab-active' : '' ) . '" href="' . esc_url( Placement::url( $id, array( 'af_mode' => $key ) ) ) . '"' . ( $key === $mode ? ' aria-current="page"' : '' ) . ( in_array( $key, $async_tabs, true ) ? ' data-af-tab' : '' ) . '>' . esc_html( $label ) . '</a>';
		}
		echo '</nav><div data-af-tab-content>';
		if ( 'block' === $mode ) {
			self::block( $id );
		} elseif ( 'manual' === $mode ) {
			self::manual( $id );
		} else {
			Extensions::notify( 'accessible_forms_placement_tab', $mode, $id, $saved );
		}
		echo '</div></div>';
	}

	private static function manual( $id ) {
		$types = ContentTypes::types( true );
		if ( ! $types ) {
			echo '<section class="af-placement-section"><h2>' . esc_html__( 'Ask a content editor to place this form', 'accessible-forms-by-accessible-org' ) . '</h2><p>' . esc_html__( 'Your role can build forms but cannot edit public content. Share the form name or shortcode with someone who can edit the destination.', 'accessible-forms-by-accessible-org' ) . '</p><a href="' . esc_url( Placement::url( $id, array( 'af_mode' => 'block' ) ) ) . '">' . esc_html__( 'Get block and shortcode instructions', 'accessible-forms-by-accessible-org' ) . '</a></section>';
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only content search. Opening an editor does not change content.
		$type     = sanitize_key( wp_unslash( $_GET['af_content_type'] ?? 'page' ) );
		$search   = sanitize_text_field( wp_unslash( $_GET['af_page_search'] ?? '' ) );
		$page     = max( 1, absint( $_GET['af_page'] ?? 1 ) );
		$position = 'before' === sanitize_key( wp_unslash( $_GET['af_position'] ?? '' ) ) ? 'before' : 'after';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		if ( ! isset( $types[ $type ] ) ) {
			$type = array_key_first( $types );
		}
		$args = array(
			'post_type'      => $type,
			'post_status'    => array( 'publish', 'draft', 'pending', 'private', 'future' ),
			'posts_per_page' => 10,
			'paged'          => $page,
			's'              => $search,
			'orderby'        => array(
				'modified' => 'DESC',
				'ID'       => 'DESC',
			),
		);
		if ( ! current_user_can( $types[ $type ]->cap->edit_others_posts ) ) {
			$args['author'] = get_current_user_id();
		}
		$query = new \WP_Query( $args );
		echo '<section class="af-placement-section" aria-labelledby="af-manual-title"><h2 id="af-manual-title">' . esc_html__( 'Choose an existing item', 'accessible-forms-by-accessible-org' ) . '</h2><p>' . esc_html__( 'Open its editor, insert the form, then save the page or post. You can move the block to any position before saving.', 'accessible-forms-by-accessible-org' ) . '</p><form method="get" class="af-placement-search"><input type="hidden" name="post_type" value="accessible_form"><input type="hidden" name="page" value="' . esc_attr( Placement::SLUG ) . '"><input type="hidden" name="form_id" value="' . esc_attr( (string) $id ) . '">';
		self::type_select( 'af_content_type', __( 'Content type', 'accessible-forms-by-accessible-org' ), $types, $type );
		echo '<div><label for="af-page-search">' . esc_html__( 'Search title or content', 'accessible-forms-by-accessible-org' ) . '</label><input id="af-page-search" type="search" name="af_page_search" value="' . esc_attr( $search ) . '"></div><div><label for="af-insert-position">' . esc_html__( 'Initial position', 'accessible-forms-by-accessible-org' ) . '</label><select id="af-insert-position" name="af_position"><option value="after"' . selected( $position, 'after', false ) . '>' . esc_html__( 'After the content', 'accessible-forms-by-accessible-org' ) . '</option><option value="before"' . selected( $position, 'before', false ) . '>' . esc_html__( 'Before the content', 'accessible-forms-by-accessible-org' ) . '</option></select></div><button class="button" type="submit">' . esc_html__( 'Find content', 'accessible-forms-by-accessible-org' ) . '</button></form><ul class="af-page-choices">';
		$shown = 0;
		foreach ( $query->posts as $post ) {
			if ( ! current_user_can( 'edit_post', $post->ID ) ) {
				continue;
			}
			++$shown;
			$present = Placement::contains_form( $post->post_content, $id );
			// Add-ons may note placement of their own, such as an automatic rule.
			$note   = $present ? '' : (string) Extensions::filter( 'accessible_forms_placement_item_note', '', $post, $id );
			$status = get_post_status_object( $post->post_status );
			$title  = $post->post_title ?: __( '(no title)', 'accessible-forms-by-accessible-org' );
			echo '<li><div><strong>' . esc_html( $title ) . '</strong><span class="af-muted">' . esc_html( $status ? $status->label : $post->post_status );
			if ( $present ) {
				echo ' · ' . esc_html__( 'Form already added', 'accessible-forms-by-accessible-org' );
			} elseif ( $note ) {
				echo ' · ' . esc_html( $note );
			}
				echo '</span></div><a class="button" href="' . esc_url( $present ? get_edit_post_link( $post->ID, 'raw' ) : Placement::editor_url( $post->ID, $id, false, $position ) ) . '" aria-label="' . esc_attr( sprintf( /* translators: %s: destination title. */ __( 'Open editor: %s', 'accessible-forms-by-accessible-org' ), $title ) ) . '">' . esc_html__( 'Open editor', 'accessible-forms-by-accessible-org' ) . '</a></li>';
		}
		echo '</ul>';
		if ( ! $shown ) {
			echo '<p class="af-placement-empty">' . esc_html__( 'No editable items match. Try another title or content type, or create a draft below.', 'accessible-forms-by-accessible-org' ) . '</p>';
		}
		if ( $query->max_num_pages > 1 ) {
			echo '<nav class="af-page-pagination" aria-label="' . esc_attr__( 'Content search results', 'accessible-forms-by-accessible-org' ) . '">';
			foreach ( array(
				-1 => __( 'Previous results', 'accessible-forms-by-accessible-org' ),
				1  => __( 'More results', 'accessible-forms-by-accessible-org' ),
			) as $offset => $label ) {
				if ( $page + $offset > 0 && $page + $offset <= $query->max_num_pages ) {
					echo '<a class="button" href="' . esc_url(
						Placement::url(
							$id,
							array(
								'af_page'         => $page + $offset,
								'af_page_search'  => $search,
								'af_content_type' => $type,
								'af_position'     => $position,
							)
						)
					) . '">' . esc_html( $label ) . '</a> ';
				}
			}
			echo '</nav>';
		}
		echo '</section>';
		$creatable = array_filter(
			$types,
			static function ( $object ) {
				return current_user_can( $object->cap->create_posts );
			}
		);
		if ( $creatable ) {
			echo '<details class="af-placement-create"><summary>' . esc_html__( 'Create a new page or post instead', 'accessible-forms-by-accessible-org' ) . '</summary><p>' . esc_html__( 'Starts a draft with the form already included. Review and publish it from the content editor.', 'accessible-forms-by-accessible-org' ) . '</p><form method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '"><input type="hidden" name="action" value="accessible_forms_create_page"><input type="hidden" name="form_id" value="' . esc_attr( (string) $id ) . '">';
			wp_nonce_field( 'accessible_forms_create_page_' . $id );
			self::type_select( 'content_type', __( 'New content type', 'accessible-forms-by-accessible-org' ), $creatable, isset( $creatable[ $type ] ) ? $type : array_key_first( $creatable ) );
			echo '<p><label for="af-new-page-name">' . esc_html__( 'Title', 'accessible-forms-by-accessible-org' ) . '</label><input id="af-new-page-name" name="page_title" type="text" maxlength="200" required></p><button class="button button-primary" type="submit">' . esc_html__( 'Create draft with form', 'accessible-forms-by-accessible-org' ) . '</button></form></details>';
		}
	}

	private static function type_select( $name, $label, array $types, $selected ) {
		echo '<div><label for="af-' . esc_attr( $name ) . '">' . esc_html( $label ) . '</label><select id="af-' . esc_attr( $name ) . '" name="' . esc_attr( $name ) . '">';
		foreach ( $types as $key => $object ) {
			echo '<option value="' . esc_attr( $key ) . '"' . selected( $selected, $key, false ) . '>' . esc_html( $object->labels->name ) . '</option>';
		}
		echo '</select></div>';
	}

	private static function block( $id ) {
		echo '<section class="af-placement-section"><h2>' . esc_html__( 'Place an Accessible Form block', 'accessible-forms-by-accessible-org' ) . '</h2><ol class="af-placement-instructions"><li>' . esc_html__( 'Open the page, post, custom content or template in the WordPress block editor.', 'accessible-forms-by-accessible-org' ) . '</li><li>' . esc_html__( 'Open the block inserter and search for “Accessible Form”.', 'accessible-forms-by-accessible-org' ) . '</li><li>' . esc_html__( 'Choose this published form:', 'accessible-forms-by-accessible-org' ) . ' <strong>' . esc_html( get_the_title( $id ) ) . '</strong></li><li>' . esc_html__( 'Move the block to the intended position. Use its alignment control if your theme supports wide or full width.', 'accessible-forms-by-accessible-org' ) . '</li><li>' . esc_html__( 'Save the content, then check the published form with a keyboard and on a small screen.', 'accessible-forms-by-accessible-org' ) . '</li></ol><p class="description">' . esc_html__( 'For every item of a post type, you can place the block in that type’s Single template. Avoid adding it to a Query Loop unless you intend a separate form on every listed item.', 'accessible-forms-by-accessible-org' ) . '</p></section><section class="af-placement-section"><h2>' . esc_html__( 'Classic Editor or page builder', 'accessible-forms-by-accessible-org' ) . '</h2><p>' . esc_html__( 'Paste this shortcode in a Shortcode block or a shortcode-enabled content area.', 'accessible-forms-by-accessible-org' ) . '</p><label for="af-placement-shortcode">' . esc_html__( 'Shortcode for this form', 'accessible-forms-by-accessible-org' ) . '</label><div class="af-shortcode-copy"><input type="text" id="af-placement-shortcode" readonly value="' . esc_attr( '[accessible_form id="' . $id . '"]' ) . '"><button type="button" class="button" id="af-copy-placement-shortcode">' . esc_html__( 'Copy shortcode', 'accessible-forms-by-accessible-org' ) . '</button></div><p id="af-placement-copy-status" role="status"></p><p>' . esc_html__( 'All placements use this form’s published fields, recipients and accessible color theme. Change the form once to update every placement.', 'accessible-forms-by-accessible-org' ) . '</p></section>';
	}
}
