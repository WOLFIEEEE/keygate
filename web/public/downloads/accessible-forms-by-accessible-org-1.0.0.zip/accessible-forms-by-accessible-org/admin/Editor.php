<?php
/** Additional form controls using native, keyboard-operable WordPress UI. @package AccessibleForms */
namespace AccessibleForms\Admin;

use AccessibleForms\{Schema, Revisions, FormOptions, Capabilities, Extensions};
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

class Editor {
	private static $fields = array();
	public static function input( $name, $label, $value = '', $type = 'text', $help = '', $attrs = array() ) {
		$id = 'af-opt-' . sanitize_html_class( str_replace( array( '[', ']' ), array( '-', '' ), $name ) );
		if ( $help ) {
			$attrs['aria-describedby'] = $id . '-help';
		}
		echo '<p class="af-setting"><label for="' . esc_attr( $id ) . '">' . esc_html( $label ) . '</label>';
		if ( 'textarea' === $type ) {
			echo '<textarea rows="3" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"';
			foreach ( $attrs as $key => $attribute ) {
				echo ' ' . esc_attr( $key ) . '="' . esc_attr( $attribute ) . '"';
			}
			echo '>' . esc_textarea( $value ) . '</textarea>';
		} else {
			echo '<input id="' .
				esc_attr( $id ) .
				'" name="' .
				esc_attr( $name ) .
				'" type="' .
				esc_attr( $type ) .
				'" value="' .
				esc_attr( $value ) .
				'"';
			foreach ( $attrs as $key => $attribute ) {
				echo ' ' . esc_attr( $key ) . '="' . esc_attr( $attribute ) . '"';
			}
			echo '>';
		}
		if ( $help ) {
			echo '<span class="description" id="' .
				esc_attr( $id . '-help' ) .
				'">' .
				esc_html( $help ) .
				'</span>';
		}
		echo '</p>';
	}
	public static function select( $name, $label, array $options, $value, $id = '' ) {
		$id = $id ?: 'af-opt-' . sanitize_html_class( str_replace( array( '[', ']' ), array( '-', '' ), $name ) );
		echo '<p class="af-setting"><label for="' .
			esc_attr( $id ) .
			'">' .
			esc_html( $label ) .
			'</label><select id="' .
			esc_attr( $id ) .
			'" name="' .
			esc_attr( $name ) .
			'">';
		foreach ( $options as $key => $text ) {
			echo '<option value="' .
				esc_attr( (string) $key ) .
				'"' .
				selected( (string) $value, (string) $key, false ) .
				'>' .
				esc_html( $text ) .
				'</option>';
		}
		echo '</select></p>';
	}
	public static function check( $name, $label, $value ) {
		echo '<p><label><input type="checkbox" name="' .
			esc_attr( $name ) .
			'" value="1"' .
			checked( (bool) $value, true, false ) .
			'> ' .
			esc_html( $label ) .
			'</label></p>';
	}
	/**
	 * Fields of the form being edited, in order.
	 *
	 * @return array[]
	 */
	public static function fields() {
		return self::$fields;
	}
	public static function top( $post, array $schema ) {
		self::$fields = $schema['fields'];
		Flow::top( $post, $schema );
	}

	public static function field( $base, $id, array $field ) {
		echo '<input type="hidden" name="' .
			esc_attr( $base . '[uid]' ) .
			'" value="' .
			esc_attr( $field['uid'] ?? '' ) .
			'">';
		echo '<div class="af-field-extra">';
		// Add-ons add per-field settings here, named under $base[extensions][slug].
		Extensions::notify( 'accessible_forms_field_editor', $base, $id, $field );
		self::select(
			$base . '[autofill_section]',
			__( 'Address purpose', 'accessible-forms-by-accessible-org' ),
			array(
				''         => __( 'General', 'accessible-forms-by-accessible-org' ),
				'shipping' => __( 'Shipping', 'accessible-forms-by-accessible-org' ),
				'billing'  => __( 'Billing', 'accessible-forms-by-accessible-org' ),
			),
			$field['autofill_section'] ?? ''
		);
		echo '<div class="af-validation-options"><h4>' .
			esc_html__( 'Answer limits', 'accessible-forms-by-accessible-org' ) .
			'</h4><div class="af-field-grid">';
		foreach (
			array(
				'min_length'  => __( 'Minimum characters', 'accessible-forms-by-accessible-org' ),
				'max_length'  => __( 'Maximum characters', 'accessible-forms-by-accessible-org' ),
				'min_choices' => __( 'Minimum choices', 'accessible-forms-by-accessible-org' ),
				'max_choices' => __( 'Maximum choices', 'accessible-forms-by-accessible-org' ),
			)
			as $key => $label
		) {
			self::input(
				$base . '[' . $key . ']',
				$label,
				$field[ $key ] ?? 0,
				'number',
				__( '0 uses the default.', 'accessible-forms-by-accessible-org' ),
				array(
					'min' => 0,
					'max' => 10000,
				)
			);
		}
		echo '</div></div><div class="af-number-options"><h4>' .
			esc_html__( 'Number range', 'accessible-forms-by-accessible-org' ) .
			'</h4><div class="af-field-grid">';
		foreach (
			array(
				'min'       => __( 'Minimum number', 'accessible-forms-by-accessible-org' ),
				'max'       => __( 'Maximum number', 'accessible-forms-by-accessible-org' ),
				'increment' => __( 'Increment', 'accessible-forms-by-accessible-org' ),
			)
			as $key => $label
		) {
			self::input(
				$base . '[' . $key . ']',
				$label,
				$field[ $key ] ?? '',
				'number',
				'',
				array(
					'step' => 'any',
				)
			);
		}
		echo '</div></div><div class="af-url-options"><h4>' .
			esc_html__( 'Web address', 'accessible-forms-by-accessible-org' ) .
			'</h4><p><label><input type="checkbox" name="' .
			esc_attr( $base . '[prefill]' ) .
			'" value="referrer"' .
			checked( 'referrer' === ( $field['prefill'] ?? '' ), true, false ) .
			'> ' .
			esc_html__( 'Prefill with the previous page on this site', 'accessible-forms-by-accessible-org' ) .
			'</label></p><p class="description">' .
			esc_html__(
				'Useful on a “Report a problem” page: when a visitor arrives from another page of this site, its address (without any query string) is filled in. Visitors can change or clear it. Requires JavaScript.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></div></div>';
	}
	public static function choices( $base, $id, array $field ) {
		$values = is_array( $field['options'] ?? null )
			? $field['options']
			: preg_split( '/\r\n|\r|\n/', (string) ( $field['options'] ?? '' ) );
		$rows   =
			$field['choices'] ??
			array_map(
				static function ( $value ) use ( $field ) {
					return array(
						'value' => $value,
						'label' => \AccessibleForms\Choices::label( $field, $value ),
					);
				},
				$values
			);
		if ( ! $rows ) {
			$rows = array( array(), array() );
		}
		echo '<div class="af-options-row"><fieldset><legend>' .
			esc_html__( 'Choices', 'accessible-forms-by-accessible-org' ) .
			'</legend><p class="description">' .
			esc_html__(
				'Edit a label without changing saved answers or routing. Add at least two choices.',
				'accessible-forms-by-accessible-org'
			) .
			'</p><div class="af-choice-rows">';
		foreach ( array_values( $rows ) as $index => $row ) {
			echo '<div class="af-choice-row"><label class="screen-reader-text" for="' .
				esc_attr( $id . '-choice-' . $index ) .
				'">' .
				esc_html__( 'Choice label', 'accessible-forms-by-accessible-org' ) .
				'</label><input class="af-choice-label" id="' .
				esc_attr( $id . '-choice-' . $index ) .
				'" name="' .
				esc_attr( $base . '[choices][' . $index . '][label]' ) .
				'" value="' .
				esc_attr( $row['label'] ?? '' ) .
				'"><input type="hidden" class="af-choice-value" name="' .
				esc_attr( $base . '[choices][' . $index . '][value]' ) .
				'" value="' .
				esc_attr( $row['value'] ?? '' ) .
				'"><button type="button" class="button-link af-remove-choice">' .
				esc_html__( 'Remove choice', 'accessible-forms-by-accessible-org' ) .
				'</button></div>';
		}
		echo '</div><button type="button" class="button af-add-choice">' .
			esc_html__( 'Add choice', 'accessible-forms-by-accessible-org' ) .
			'</button><details class="af-paste-choices"><summary>' .
			esc_html__( 'Paste several choices', 'accessible-forms-by-accessible-org' ) .
			'</summary><label for="' .
			esc_attr( $id . '-options' ) .
			'">' .
			esc_html__( 'One label per line', 'accessible-forms-by-accessible-org' ) .
			'</label><textarea id="' .
			esc_attr( $id . '-options' ) .
			'" rows="4"></textarea><button type="button" class="button af-paste-choice-list">' .
			esc_html__( 'Add these choices', 'accessible-forms-by-accessible-org' ) .
			'</button></details></fieldset></div>';
	}
	public static function options( $post, array $schema ) {
		$schema = wp_parse_args( $schema, FormOptions::defaults() );
		$emails = array( '' => __( 'Choose an email field', 'accessible-forms-by-accessible-org' ) );
		foreach ( $schema['fields'] as $field ) {
			if ( 'email' === $field['type'] ) {
				$emails[ $field['name'] ] = $field['label'];
			}
		}
		echo '<details class="af-editor-section" data-af-editor-step="delivery" id="af-email-options"><summary>' .
			esc_html__( 'Advanced email options', 'accessible-forms-by-accessible-org' ) .
			'</summary><div class="af-options-grid">';
		ob_start();
		self::select(
			'af_schema[reply_to]',
			__( 'Reply to', 'accessible-forms-by-accessible-org' ),
			array( '' => __( 'First email field', 'accessible-forms-by-accessible-org' ) ) + $emails,
			$schema['reply_to']
		);
		// The list follows the email fields while the form is edited.
		echo str_replace( '<select ', '<select data-af-email-fields ', (string) ob_get_clean() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Escaped by select().
		echo '</div><p><button type="button" class="button" id="af-preview-email">' .
			esc_html__( 'Preview a sample email', 'accessible-forms-by-accessible-org' ) .
			'</button></p><div id="af-email-preview" role="status" hidden></div>';
		// Add-ons add email options here, such as formats and extra notifications.
		Extensions::notify( 'accessible_forms_editor_section', 'delivery', $schema, $post );
		echo '</details>';
		echo '<details class="af-editor-section" data-af-editor-step="build" id="af-experience"><summary>' .
			esc_html__( 'Advanced form behavior', 'accessible-forms-by-accessible-org' ) .
			'</summary><div class="af-options-grid">';
		// Add-ons add form behavior here, such as steps.
		Extensions::notify( 'accessible_forms_editor_section', 'behavior', $schema, $post );
		echo '</div>';
		Flow::page_picker( $schema['confirmation_page'] );
		echo '</details>';
		echo '<details class="af-editor-section" data-af-editor-step="review" id="af-publishing"><summary>' .
			esc_html__( 'Availability & history', 'accessible-forms-by-accessible-org' ) .
			'</summary>';
		self::check(
			'af_schema[closed]',
			__( 'Close this form to new submissions', 'accessible-forms-by-accessible-org' ),
			$schema['closed']
		);
		self::input(
			'af_schema[closed_message]',
			__( 'Closed message', 'accessible-forms-by-accessible-org' ),
			$schema['closed_message']
		);
		// Add-ons add availability settings here, such as a schedule or version history.
		Extensions::notify( 'accessible_forms_editor_section', 'availability', $schema, $post );
		echo '</details><details class="af-editor-section" data-af-editor-step="review"><summary>' .
			esc_html__( 'Privacy & protection', 'accessible-forms-by-accessible-org' ) .
			'</summary><div class="af-options-grid">';
		self::input(
			'af_schema[privacy][retention_days]',
			__( 'Keep entries for (days)', 'accessible-forms-by-accessible-org' ),
			$schema['privacy']['retention_days'],
			'number',
			__(
				'−1 uses the site default; 0 keeps entries until you delete them. Applies to new entries.',
				'accessible-forms-by-accessible-org'
			),
			array(
				'min' => -1,
				'max' => 3650,
			)
		);
		// Add-ons add per-form protection settings here.
		Extensions::notify( 'accessible_forms_editor_section', 'privacy', $schema, $post );
		echo '</div>';
		self::check(
			'af_schema[privacy][minimal_metadata]',
			__( 'Do not retain browser information or the IP address hash with entries', 'accessible-forms-by-accessible-org' ),
			$schema['privacy']['minimal_metadata']
		);
		echo '</details>';
		// Add-ons add their own sections for integrations with other services.
		Extensions::notify( 'accessible_forms_editor_section', 'integrations', $schema, $post );
	}
	/**
	 * One checkbox per answer field, kept in step with the fields being edited.
	 *
	 * @param string   $name     Input name.
	 * @param string[] $selected Checked field names.
	 */
	public static function field_checks( $name, array $selected ) {
		echo '<div data-af-field-checks="' . esc_attr( $name ) . '">';
		foreach ( self::$fields as $field ) {
			if ( 'section' !== $field['type'] ) {
				echo '<label class="af-inline-choice"><input type="checkbox" name="' .
					esc_attr( $name ) .
					'" value="' .
					esc_attr( $field['name'] ) .
					'"' .
					checked( in_array( $field['name'], $selected, true ), true, false ) .
					'> ' .
					esc_html( $field['label'] ) .
					'</label>';
			}
		}
		echo '</div>';
	}
}
