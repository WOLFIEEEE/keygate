<?php
/** Form library, operational health and administrator tools. @package AccessibleForms */
namespace AccessibleForms\Admin;

use AccessibleForms\{
	Schema,
	FormOptions,
	FormLibrary,
	Health,
	Capabilities,
	Notifications,
	Entries,
	Audit,
	Appearance,
	Settings,
	Extensions
};
if ( ! defined( 'ABSPATH' ) ) {
	exit();
}
class Management {
	const SLUG = 'accessible-forms-tools';
	/** Tabs rendered by this class; any other tab belongs to an add-on. */
	const CORE_TABS = array( 'templates', 'usage', 'guide', 'health', 'activity' );
	public static function init() {
		add_action( 'admin_menu', array( self::class, 'menus' ), 20 );
		add_action( 'admin_post_accessible_forms_tools', array( self::class, 'action' ) );
		add_filter( 'site_status_tests', array( Health::class, 'site_tests' ) );
	}
	public static function url( $tab = 'templates', array $args = array() ) {
		return add_query_arg(
			array_merge(
				array(
					'page' => self::SLUG,
					'tab'  => $tab,
				),
				$args
			),
			admin_url( 'admin.php' )
		);
	}
	public static function menus() {
		add_submenu_page(
			'edit.php?post_type=accessible_form',
			__( 'Tools & guidance', 'accessible-forms-by-accessible-org' ),
			__( 'Tools & guidance', 'accessible-forms-by-accessible-org' ),
			'edit_accessible_forms',
			self::SLUG,
			array( self::class, 'render' )
		);
		if ( current_user_can( 'read_accessible_form_entries' ) && ! current_user_can( 'edit_accessible_forms' ) ) {
			add_menu_page(
				__( 'Submissions', 'accessible-forms-by-accessible-org' ),
				__( 'Submissions', 'accessible-forms-by-accessible-org' ),
				'read_accessible_form_entries',
				EntriesTable::SLUG,
				array( EntriesTable::class, 'render_page' ),
				'dashicons-feedback',
				26
			);
		}
	}
	public static function form_start( $operation, array $hidden = array() ) {
		echo '<form method="post" action="' .
			esc_url( admin_url( 'admin-post.php' ) ) .
			'"><input type="hidden" name="action" value="accessible_forms_tools"><input type="hidden" name="operation" value="' .
			esc_attr( $operation ) .
			'">';
		echo '<input type="hidden" name="_wpnonce" value="' . esc_attr( wp_create_nonce( 'accessible_forms_tools' ) ) . '">';
		wp_referer_field();
		foreach ( $hidden as $key => $value ) {
			echo '<input type="hidden" name="' . esc_attr( $key ) . '" value="' . esc_attr( $value ) . '">';
		}
	}
	/** Native buttons on screens containing several independent tool forms. */
	public static function submit( $text = null, $type = 'primary', $name = 'submit', $wrap = true ) {
		// Match WordPress button classes, using a button whose caption can wrap.
		$types   = is_array( $type ) ? $type : explode( ' ', $type );
		$classes = array( 'button' );
		foreach ( $types as $variant ) {
			if ( in_array( $variant, array( 'secondary', 'button-secondary' ), true ) ) { continue; }
			$classes[] = in_array( $variant, array( 'primary', 'small', 'large', 'compact' ), true ) ? 'button-' . $variant : $variant;
		}
		$text = $text ?: __( 'Save Changes', 'accessible-forms-by-accessible-org' );
		if ( $wrap ) { echo '<p class="submit">'; }
		echo '<button type="submit" id="' . esc_attr( wp_unique_id( 'af-tool-submit-' ) ) . '" class="' .
			esc_attr( implode( ' ', array_unique( array_filter( $classes ) ) ) ) . '"' .
			( $name ? ' name="' . esc_attr( $name ) . '"' : '' ) . ' value="' . esc_attr( $text ) . '">' .
			esc_html( $text ) . '</button>';
		if ( $wrap ) { echo '</p>'; }
	}
	public static function fail( $message ) {
		wp_die(
			esc_html( $message ),
			'',
			array(
				'back_link' => true,
				'response'  => 400,
			)
		);
	}
	public static function action() {
		check_admin_referer( 'accessible_forms_tools' );
		$operation    = sanitize_key( wp_unslash( $_POST['operation'] ?? '' ) );
		$settings_ops = array(
			'diagnostics',
			'run_queue',
			'purge',
			'test_mode',
			'time_migrate_start',
			'time_migrate_batch',
		);
		if (
			! current_user_can(
				in_array( $operation, $settings_ops, true ) ? 'manage_accessible_forms_settings' : 'edit_accessible_forms'
			)
		) {
			self::fail( __( 'You do not have permission to use this tool.', 'accessible-forms-by-accessible-org' ) );
		}
		switch ( $operation ) {
			case 'time_migrate_start':
				$result = \AccessibleForms\TimeMigration::start( sanitize_text_field( wp_unslash( $_POST['original_zone'] ?? '' ) ), sanitize_key( wp_unslash( $_POST['repeated_hour'] ?? '' ) ), ! empty( $_POST['confirm_zone'] ), absint( $_POST['form_id'] ?? 0 ) );
				if ( is_wp_error( $result ) ) { self::fail( $result->get_error_message() ); }
				wp_safe_redirect( self::url( 'health', array( 'updated' => 1 ) ) ); exit();
			case 'time_migrate_batch':
				$processed = \AccessibleForms\TimeMigration::batch();
				if ( ! $processed && 'running' === ( get_option( \AccessibleForms\TimeMigration::OPTION )['status'] ?? '' ) ) { self::fail( __( 'This date batch could not finish. Historical dates and progress were kept. Try again shortly.', 'accessible-forms-by-accessible-org' ) ); }
				wp_safe_redirect( self::url( 'health', array( 'updated' => 1 ) ) ); exit();
			case 'template':
				$key = sanitize_key( wp_unslash( $_POST['template'] ?? '' ) );
				// Add-ons may offer templates of their own, such as saved ones.
				$schema = FormLibrary::template( $key ) ?: Extensions::filter( 'accessible_forms_template_schema', null, $key );
				if ( ! is_array( $schema ) || ! $schema ) {
					self::fail( __( 'Template not found.', 'accessible-forms-by-accessible-org' ) );
				}
				$schema['recipients'] = array( sanitize_email( wp_unslash( $_POST['recipient'] ?? '' ) ) );
				$id                   = FormLibrary::create( $schema, $schema['heading'] );
				if ( is_wp_error( $id ) ) {
					self::fail( $id->get_error_message() );
				}
				wp_safe_redirect( get_edit_post_link( $id, 'raw' ) );
				exit();
			case 'diagnostics':
				nocache_headers();
				header( 'Content-Type: application/json; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename="accessible-forms-diagnostics.json"' );
				echo wp_json_encode( Health::report(), JSON_PRETTY_PRINT );
				exit();
			case 'run_queue':
				Notifications::run();
				wp_safe_redirect( self::url( 'health', array( 'updated' => 1 ) ) );
				exit();
			case 'purge':
				Entries::purge();
				wp_safe_redirect( self::url( 'health', array( 'updated' => 1 ) ) );
				exit();
			case 'test_mode':
				$settings                   = Settings::get();
				$settings['test_delivery']  = ! empty( $_POST['test_delivery'] );
				$settings['test_recipient'] = sanitize_email( wp_unslash( $_POST['test_recipient'] ?? '' ) );
				if ( $settings['test_delivery'] && ! is_email( $settings['test_recipient'] ) ) {
					self::fail( __( 'Provide a valid test inbox.', 'accessible-forms-by-accessible-org' ) );
				}
				// The same rule as the Settings tab: an empty field keeps the current period.
				$settings['spam_retention_days'] = Settings::spam_retention_days(
					sanitize_text_field( wp_unslash( $_POST['spam_retention_days'] ?? '' ) ),
					(int) ( $settings['spam_retention_days'] ?? 0 )
				);
				Settings::update( $settings );
				Audit::record( 'delivery_mode_changed' );
				wp_safe_redirect( self::url( 'health', array( 'updated' => 1 ) ) );
				exit();
			default:
				// Add-on tools check their own capability, then redirect and exit.
				Extensions::notify( 'accessible_forms_tools_action', $operation );
				self::fail( __( 'Unknown action.', 'accessible-forms-by-accessible-org' ) );
		}
		wp_safe_redirect( self::url( 'templates', array( 'updated' => 1 ) ) );
		exit();
	}
	public static function render() {
		if ( ! current_user_can( 'edit_accessible_forms' ) ) {
			self::fail( __( 'You cannot use these form tools.', 'accessible-forms-by-accessible-org' ) );
		}
		$tabs = array(
			'templates' => __( 'Templates', 'accessible-forms-by-accessible-org' ),
			'usage'     => __( 'Used on', 'accessible-forms-by-accessible-org' ),
			'guide'     => __( 'Guide', 'accessible-forms-by-accessible-org' ),
		);
		if ( current_user_can( 'manage_accessible_forms_settings' ) ) {
			$tabs += array(
				'health'   => __( 'Health', 'accessible-forms-by-accessible-org' ),
				'activity' => __( 'Activity', 'accessible-forms-by-accessible-org' ),
			);
		}
		// Add-ons add tabs, checking their own capability before listing one.
		$tabs = (array) Extensions::filter( 'accessible_forms_tools_tabs', $tabs );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen selection; every action verifies a POST nonce and capability.
		$tab = sanitize_key( wp_unslash( $_GET['tab'] ?? 'templates' ) );
		if ( ! isset( $tabs[ $tab ] ) ) {
			$tab = 'templates';
		}
		$async_tabs = (array) Extensions::filter( 'accessible_forms_async_tabs', self::CORE_TABS, 'tools' );
		echo '<div class="wrap af-tools" data-af-tabs="tools"><h1>' .
			esc_html__( 'Tools & guidance', 'accessible-forms-by-accessible-org' ) .
			'</h1><nav class="nav-tab-wrapper" aria-label="' .
			esc_attr__( 'Form tools', 'accessible-forms-by-accessible-org' ) .
			'">';
		foreach ( $tabs as $key => $label ) {
			echo '<a class="nav-tab' .
				( $key === $tab ? ' nav-tab-active' : '' ) .
				'" href="' .
				esc_url( self::url( $key ) ) .
				'"' .
				( $key === $tab ? ' aria-current="page"' : '' ) .
				( in_array( $key, $async_tabs, true ) ? ' data-af-tab' : '' ) .
				( in_array( $key, array( 'health', 'activity' ), true ) ? ' data-af-tab-refresh' : '' ) .
				'>' .
				esc_html( $label ) .
				'</a>';
		}
		echo '</nav><section class="af-tools-content" data-af-tab-content><h2>' . esc_html( $tabs[ $tab ] ) . '</h2>';
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen selection; every action verifies a POST nonce and capability.
		if ( isset( $_GET['updated'] ) ) {
			echo '<p role="status">' . esc_html__( 'Changes saved.', 'accessible-forms-by-accessible-org' ) . '</p>';
		}
		if ( in_array( $tab, self::CORE_TABS, true ) ) {
			self::{$tab}();
		} else {
			Extensions::notify( 'accessible_forms_tools_tab', $tab );
		}
		echo '</section></div>';
	}
	private static function templates() {
		echo '<p>' .
			esc_html__(
				'Start with a useful set of accessible fields. Each template creates an independent draft; review it before publishing.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		$templates = (array) Extensions::filter( 'accessible_forms_template_choices', FormLibrary::templates() );
		self::form_start( 'template' );
		Editor::select( 'template', __( 'Starting template', 'accessible-forms-by-accessible-org' ), $templates, 'contact' );
		Editor::input(
			'recipient',
			__( 'Notification recipient', 'accessible-forms-by-accessible-org' ),
			get_option( 'admin_email' ),
			'email',
			__( 'Confirm who should receive this form’s enquiries.', 'accessible-forms-by-accessible-org' ),
			array( 'required' => 'required' )
		);
		self::submit( __( 'Create draft form', 'accessible-forms-by-accessible-org' ) );
		echo '</form>';
	}
	public static function form_picker( $selected = 0, $mode = 'edit', $empty_label = '' ) {
		$identity = wp_unique_id( 'af-form-picker-' );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only catalog pagination; actions verify their own nonce.
		$number = max( 1, absint( $_GET['af_form_page'] ?? 1 ) );
		$page = \AccessibleForms\FormCatalog::admin_options( '', $number, $mode );
		$options = array( '' => $empty_label ?: __( 'Choose a form', 'accessible-forms-by-accessible-org' ) );
		foreach ( $page['items'] as $item ) { $options[ $item['id'] ] = $item['label']; }
		$post = $selected ? get_post( $selected ) : null;
		if ( $post && 'accessible_form' === $post->post_type && ( 'entries' === $mode ? Capabilities::form( $selected ) : current_user_can( 'edit_post', $selected ) ) ) {
			$options[ $selected ] = ( $post->post_title ?: __( '(no title)', 'accessible-forms-by-accessible-org' ) ) . ' (#' . $selected . ')';
		}
		echo '<div class="af-form-picker" data-af-form-picker data-page="' . esc_attr( (string) $number ) . '" data-mode="' . esc_attr( $mode ) . '" data-url="' . esc_url( admin_url( 'admin-ajax.php' ) ) . '" data-nonce="' . esc_attr( wp_create_nonce( 'accessible_forms_admin_forms' ) ) . '">';
		Editor::select( 'form_id', __( 'Form', 'accessible-forms-by-accessible-org' ), $options, $selected, $identity . '-select' );
		echo '<div data-af-picker-tools hidden><label for="' . esc_attr( $identity . '-query' ) . '">' . esc_html__( 'Find a form by name', 'accessible-forms-by-accessible-org' ) . '</label><div class="af-picker-search"><input type="search" id="' . esc_attr( $identity . '-query' ) . '"><button type="button" class="button" data-af-picker-search>' . esc_html__( 'Search forms', 'accessible-forms-by-accessible-org' ) . '</button><button type="button" class="button" data-af-picker-more' . ( $page['pages'] > $number ? '' : ' hidden' ) . '>' . esc_html__( 'Load more forms', 'accessible-forms-by-accessible-org' ) . '</button></div><p class="description" role="status"></p></div>';
		echo '<noscript><p class="description">';
		if ( $number > 1 ) { echo '<a href="' . esc_url( add_query_arg( array( 'af_form_page' => $number - 1, 'form_id' => $selected ?: false ) ) ) . '">' . esc_html__( 'Previous forms', 'accessible-forms-by-accessible-org' ) . '</a> '; }
		if ( $number < $page['pages'] ) { echo '<a href="' . esc_url( add_query_arg( array( 'af_form_page' => $number + 1, 'form_id' => $selected ?: false ) ) ) . '">' . esc_html__( 'Next forms', 'accessible-forms-by-accessible-org' ) . '</a>'; }
		echo '</p></noscript></div>';
	}
	private static function usage() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen selection; every action verifies a POST nonce and capability.
		$id = absint( $_GET['form_id'] ?? 0 );
		echo '<form method="get"><input type="hidden" name="page" value="' .
			esc_attr( self::SLUG ) .
			'"><input type="hidden" name="tab" value="usage">';
		self::form_picker( $id );
		self::submit( __( 'Find placements', 'accessible-forms-by-accessible-org' ), 'secondary' );
		echo '</form><p>' .
			esc_html__(
				'Checks stored pages, posts, public custom content, synced patterns and saved templates, including nested blocks. Theme files, widgets and third-party builder data may need separate inspection.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';
		if ( ! $id || ! current_user_can( 'edit_post', $id ) ) {
			return;
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only screen selection; every action verifies a POST nonce and capability.
		$page = max( 1, absint( $_GET['scan_page'] ?? 1 ) );
		// Add-ons report placement that does not live in content, such as automatic rules.
		Extensions::notify( 'accessible_forms_usage_summary', $id );
		$scan = Placement::scan_batch( $id, $page );
		echo '<ul class="af-page-choices">';
		$found = 0;
		foreach ( $scan['ids'] as $post_id ) {
			$post = get_post( $post_id );
			if ( $post && current_user_can( 'edit_post', $post->ID ) ) {
				++$found;
				echo '<li><div><strong>' .
					esc_html( $post->post_title ) .
					'</strong><span>' .
					esc_html( $post->post_type . ' · ' . $post->post_status ) .
					'</span></div><a class="button" href="' .
					esc_url( get_edit_post_link( $post->ID, 'raw' ) ) .
					'">' .
					esc_html__( 'Edit placement', 'accessible-forms-by-accessible-org' ) .
					'</a></li>';
			}
		}
		echo '</ul>';
		if ( ! $found ) {
			echo '<p>' . esc_html__( 'No placements in this batch of content.', 'accessible-forms-by-accessible-org' ) . '</p>';
		}
		if ( $page > 1 ) {
			echo '<a class="button" href="' .
				esc_url(
					self::url(
						'usage',
						array(
							'form_id'   => $id,
							'scan_page' => $page - 1,
						)
					)
				) .
				'">' .
				esc_html__( 'Previous batch', 'accessible-forms-by-accessible-org' ) .
				'</a> ';
		}
		if ( $page < $scan['pages'] ) {
			echo '<a class="button" href="' .
				esc_url(
					self::url(
						'usage',
						array(
							'form_id'   => $id,
							'scan_page' => $page + 1,
						)
					)
				) .
				'">' .
				esc_html__( 'Check next 100 items', 'accessible-forms-by-accessible-org' ) .
				'</a>';
		}
	}
	/** Forms that do not meet the accessibility checks, with a link to fix each. */
	private static function accessibility_checks() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only audit pagination.
		$page = max( 1, absint( $_GET['check_page'] ?? 1 ) );
		$counts = wp_count_posts( 'accessible_form' );
		$total = 0;
		foreach ( array( 'publish', 'draft', 'pending', 'private', 'future' ) as $status ) { $total += (int) ( $counts->$status ?? 0 ); }
		$pages = max( 1, (int) ceil( $total / 200 ) );
		$page = min( $page, $pages );
		$forms = \AccessibleForms\FormCheck::forms( 200, $page );
		echo '<h3>' . esc_html__( 'Form accessibility checks', 'accessible-forms-by-accessible-org' ) . '</h3>';
		echo '<p>' . esc_html( sprintf( /* translators: 1: batch number, 2: number of batches. */ __( 'Reviewing batch %1$d of %2$d, up to 200 forms per batch.', 'accessible-forms-by-accessible-org' ), $page, $pages ) ) . '</p>';
		if ( $page > 1 ) { echo '<a class="button" href="' . esc_url( self::url( 'health', array( 'check_page' => $page - 1 ) ) ) . '">' . esc_html__( 'Previous batch', 'accessible-forms-by-accessible-org' ) . '</a> '; }
		if ( $page < $pages ) { echo '<a class="button" href="' . esc_url( self::url( 'health', array( 'check_page' => $page + 1 ) ) ) . '">' . esc_html__( 'Check next batch', 'accessible-forms-by-accessible-org' ) . '</a>'; }
		if ( ! $forms ) {
			echo '<p>' . esc_html__( 'The forms in this batch meet the current configuration checks. Check the published pages and complete the manual accessibility review as well.', 'accessible-forms-by-accessible-org' ) . '</p>';
			return;
		}
		echo '<table class="widefat striped"><thead><tr><th scope="col">' . esc_html__( 'Form', 'accessible-forms-by-accessible-org' ) . '</th><th scope="col">' .
			esc_html__( 'Published version', 'accessible-forms-by-accessible-org' ) . '</th><th scope="col">' . esc_html__( 'Unpublished edits', 'accessible-forms-by-accessible-org' ) . '</th></tr></thead><tbody>';
		foreach ( $forms as $id => $form ) {
			$title = get_the_title( $id ) ?: __( '(no title)', 'accessible-forms-by-accessible-org' );
			echo '<tr><th scope="row">' . ( current_user_can( 'edit_post', $id ) ? '<a href="' . esc_url( (string) get_edit_post_link( $id ) ) . '">' . esc_html( $title ) . '</a>' : esc_html( $title ) ) . '</th><td>' .
				esc_html(
					$form['live']
						/* translators: %s: number of problems. */
						? sprintf( _n( '%s problem, shown to visitors', '%s problems, shown to visitors', $form['live'], 'accessible-forms-by-accessible-org' ), number_format_i18n( $form['live'] ) )
						: __( 'Meets the checks', 'accessible-forms-by-accessible-org' )
				) . '</td><td>' .
				esc_html( $form['pending'] ? __( 'Saved with problems; not published', 'accessible-forms-by-accessible-org' ) : __( 'None', 'accessible-forms-by-accessible-org' ) ) .
				'</td></tr>';
		}
		echo '</tbody></table>';
	}

	private static function health() {
		$report = Health::report();
		echo '<table class="widefat striped"><tbody>';
		$rows = array(
			__( 'Storage', 'accessible-forms-by-accessible-org' )            => $report['storage']
				? __( 'Available', 'accessible-forms-by-accessible-org' )
				: __( 'Needs attention — reactivate to repair tables', 'accessible-forms-by-accessible-org' ),
			__( 'Pending notifications', 'accessible-forms-by-accessible-org' ) => $report['notifications']['pending'],
			__( 'Failed notifications', 'accessible-forms-by-accessible-org' ) => $report['notifications']['failed'],
			__( 'Uncertain delivery', 'accessible-forms-by-accessible-org' ) => $report['notifications']['uncertain'],
			__( 'Retention scheduled', 'accessible-forms-by-accessible-org' ) => $report['cleanup_next']
				? wp_date( 'Y-m-d H:i', $report['cleanup_next'] )
				: __( 'Not scheduled', 'accessible-forms-by-accessible-org' ),
			__( 'Last cleanup', 'accessible-forms-by-accessible-org' )       => $report['cleanup_last']
				? wp_date( 'Y-m-d H:i', $report['cleanup_last'] )
				: __( 'Not run yet', 'accessible-forms-by-accessible-org' ),
			__( 'Verification', 'accessible-forms-by-accessible-org' )       =>
				$report['spam_provider'] .
				( $report['verification_ready']
					? ''
					: ' — ' . __( 'Add the provider keys in Settings', 'accessible-forms-by-accessible-org' ) ) .
				( $report['verification_secure']
					? ''
					: ' — ' . __( 'Needs HTTPS: browsers cannot run the automatic check on this site address, so every message is held for review', 'accessible-forms-by-accessible-org' ) ),
			__( 'Oldest pending notification (UTC)', 'accessible-forms-by-accessible-org' ) =>
				$report['oldest_pending'] ?: __( 'None', 'accessible-forms-by-accessible-org' ),
			__( 'Environment', 'accessible-forms-by-accessible-org' )        => $report['environment'],
		);
		foreach ( $rows as $label => $value ) {
			echo '<tr><th scope="row">' .
				esc_html( $label ) .
				'</th><td>' .
				esc_html( (string) $value ) .
				'</td></tr>';
		}
		echo '</tbody></table><div class="af-tool-actions">';
		foreach (
			array(
				'run_queue'   => __( 'Process pending notifications', 'accessible-forms-by-accessible-org' ),
				'purge'       => __( 'Run due retention cleanup', 'accessible-forms-by-accessible-org' ),
				'diagnostics' => __( 'Download diagnostics', 'accessible-forms-by-accessible-org' ),
			)
			as $action => $label
		) {
			self::form_start( $action );
			self::submit( $label, 'secondary' );
			echo '</form>';
		}
		echo '</div>';
		self::historical_dates( $report );
		self::accessibility_checks();
		\AccessibleForms\LiveCheck::render_health_table();
		$settings = Settings::get();
		self::form_start( 'test_mode' );
		echo '<h3>' . esc_html__( 'Testing & retention', 'accessible-forms-by-accessible-org' ) . '</h3>';
		Editor::check(
			'test_delivery',
			__( 'Send all plugin notification emails to a test inbox', 'accessible-forms-by-accessible-org' ),
			$settings['test_delivery'] ?? false
		);
		Editor::input(
			'test_recipient',
			__( 'Test inbox', 'accessible-forms-by-accessible-org' ),
			$settings['test_recipient'] ?? '',
			'email',
			__( 'Original To, Cc and Bcc destinations are replaced. Use this on staging.', 'accessible-forms-by-accessible-org' )
		);
		Editor::input(
			'spam_retention_days',
			__( 'Delete spam and review items after (days)', 'accessible-forms-by-accessible-org' ),
			$settings['spam_retention_days'] ?? 30,
			'number',
			__(
				'Spam and review items use this shorter limit, or their form retention if earlier.',
				'accessible-forms-by-accessible-org'
			),
			array(
				'min' => 1,
				'max' => 3650,
			)
		);
		self::submit();
		echo '</form>';
	}
	/** Only shown to settings administrators when historical dates need attention. */
	private static function historical_dates( array $report ) {
		$state = get_option( \AccessibleForms\TimeMigration::OPTION, array() );
		$pending = $report['historical_dates'] ?? 0;
		if ( ! $pending && ! $state ) { return; }
		echo '<details class="af-settings-disclosure"><summary>' . esc_html__( 'Historical entry dates', 'accessible-forms-by-accessible-org' ) . '</summary>';
		echo '<p>' . esc_html( sprintf( /* translators: %s: number of entries with unconfirmed dates. */ __( '%s entries have historical dates whose original time zone is unconfirmed.', 'accessible-forms-by-accessible-org' ), number_format_i18n( $pending ) ) ) . '</p>';
		echo '<p>' . esc_html__( 'New submissions use UTC and display in your site time zone. Historical dates keep their original values until you confirm where they came from. Unconfirmed dates are excluded from response-time statistics and date-based cleanup; existing expiry dates still apply.', 'accessible-forms-by-accessible-org' ) . '</p>';
		if ( 'running' === ( $state['status'] ?? '' ) ) {
			echo '<p role="status">' . esc_html__( 'Conversion is running in small background batches. You can also process the next batch here.', 'accessible-forms-by-accessible-org' ) . '</p>';
			self::form_start( 'time_migrate_batch' ); self::submit( __( 'Process next date batch', 'accessible-forms-by-accessible-org' ), 'secondary' ); echo '</form>';
		} elseif ( $pending ) {
			self::form_start( 'time_migrate_start' );
			self::form_picker( 0, 'entries', __( 'All forms', 'accessible-forms-by-accessible-org' ) );
			$selected_zone = wp_timezone_string();
			if ( preg_match( '/^([+-])(\d{2}):(\d{2})$/D', $selected_zone, $offset ) ) { $selected_zone = 'UTC' . $offset[1] . ( (int) $offset[2] + (int) $offset[3] / 60 ); }
			echo '<p><label for="af-original-zone">' . esc_html__( 'Original time zone', 'accessible-forms-by-accessible-org' ) . '</label><br><select name="original_zone" id="af-original-zone" aria-describedby="af-original-zone-help">' . wp_timezone_choice( $selected_zone, get_user_locale() ) . '</select></p>';
			echo '<p id="af-original-zone-help" class="description">' . esc_html__( 'Use the time zone in effect when these records were created. If it changed, process each form separately only when its original zone is known. Keep unknown records unchanged.', 'accessible-forms-by-accessible-org' ) . '</p>';
			Editor::select( 'repeated_hour', __( 'Dates during a repeated daylight-saving hour', 'accessible-forms-by-accessible-org' ), array( 'preserve' => __( 'Keep these dates unconfirmed', 'accessible-forms-by-accessible-org' ), 'earlier' => __( 'Use the earlier occurrence', 'accessible-forms-by-accessible-org' ), 'later' => __( 'Use the later occurrence', 'accessible-forms-by-accessible-org' ) ), 'preserve', 'af-repeated-hour' );
			echo '<p><label for="af-confirm-zone"><input type="checkbox" id="af-confirm-zone" name="confirm_zone" value="1" required> ' . esc_html__( 'I have verified this original time zone for the selected historical records.', 'accessible-forms-by-accessible-org' ) . '</label></p>';
			echo '<p class="description">' . esc_html__( 'Conversion preserves the original dates. Invalid or nonexistent local times remain unconfirmed. It does not change follow-up calendar dates, send emails or delete entries.', 'accessible-forms-by-accessible-org' ) . '</p>';
			self::submit( __( 'Convert confirmed historical dates', 'accessible-forms-by-accessible-org' ), 'secondary' ); echo '</form>';
		} else {
			echo '<p role="status">' . esc_html__( 'All stored entry dates have confirmed UTC provenance.', 'accessible-forms-by-accessible-org' ) . '</p>';
		}
		echo '</details>';
	}
	private static function activity() {
		echo '<p>' .
			esc_html__(
				'Recent administrative changes. Answers and credentials are not copied into this log. Records expire after 90 days.',
				'accessible-forms-by-accessible-org'
			) .
			'</p><table class="widefat striped"><thead><tr><th>' .
			esc_html__( 'When (UTC)', 'accessible-forms-by-accessible-org' ) .
			'</th><th>' .
			esc_html__( 'Action', 'accessible-forms-by-accessible-org' ) .
			'</th><th>' .
			esc_html__( 'User', 'accessible-forms-by-accessible-org' ) .
			'</th></tr></thead><tbody>';
		foreach ( Audit::recent() as $row ) {
			$user = get_userdata( $row['actor'] );
			echo '<tr><td>' .
				esc_html( EntryWorkflow::local_time( $row['created_at'] ) ) .
				'</td><td>' .
				esc_html( str_replace( '_', ' ', $row['action'] ) ) .
				'</td><td>' .
				esc_html( $user ? $user->display_name : __( 'System', 'accessible-forms-by-accessible-org' ) ) .
				'</td></tr>';
		}
		echo '</tbody></table>';
	}
	private static function guide() {
		echo '<ol class="af-guide"><li><strong>' .
			esc_html__( 'Create a draft', 'accessible-forms-by-accessible-org' ) .
			'</strong><p>' .
			esc_html__(
				'Choose a template or add the fields you need. Keep labels descriptive and required questions purposeful.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></li><li><strong>' .
			esc_html__( 'Review delivery and appearance', 'accessible-forms-by-accessible-org' ) .
			'</strong><p>' .
			esc_html__(
				'Confirm recipients, preview the confirmation and choose a palette that passes every contrast check.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></li><li><strong>' .
			esc_html__( 'Publish and place the form', 'accessible-forms-by-accessible-org' ) .
			'</strong><p>' .
			esc_html__(
				'Publish the form, then choose where it appears: on selected content, automatically across a content type, or in an Accessible Form block.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></li><li><strong>' .
			esc_html__( 'Test the complete journey', 'accessible-forms-by-accessible-org' ) .
			'</strong><p>' .
			esc_html__(
				'Use the keyboard, send a test entry and confirm both storage and actual inbox delivery. Check on a phone and with your site theme.',
				'accessible-forms-by-accessible-org'
			) .
			'</p></li></ol><h3>' .
			esc_html__( 'Troubleshooting', 'accessible-forms-by-accessible-org' ) .
			'</h3>';
		foreach (
			array(
				__( 'No email arrived', 'accessible-forms-by-accessible-org' ) => __(
					'Open the entry and check notification history. Review pending work and mail settings in Health. Acceptance by a mail service does not guarantee inbox delivery.',
					'accessible-forms-by-accessible-org'
				),
				__( 'The form is missing', 'accessible-forms-by-accessible-org' ) => __(
					'Check that the selected form is published, open and correctly selected in its page block. Clear the page cache after changing placement.',
					'accessible-forms-by-accessible-org'
				),
				__( 'A message needs review', 'accessible-forms-by-accessible-org' ) => __(
					'Check the verification reason. Accept the message with or without sending a notification, and adjust your spam limits if they caused a false positive.',
					'accessible-forms-by-accessible-org'
				),
				__( 'A color was rejected', 'accessible-forms-by-accessible-org' ) => __(
					'The editor identifies the failing pair. Choose a darker or lighter color, or use a preset. Check focus and errors in the preview as well.',
					'accessible-forms-by-accessible-org'
				),
			)
			as $question => $answer
		) {
			echo '<details><summary>' .
				esc_html( $question ) .
				'</summary><p>' .
				esc_html( $answer ) .
				'</p></details>';
		}
	}
}
