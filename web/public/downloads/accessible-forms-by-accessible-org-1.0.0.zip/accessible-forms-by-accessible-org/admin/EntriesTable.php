<?php
/**
 * Entries screen: list table, bulk actions, CSV export.
 *
 * @package AccessibleForms
 */

namespace AccessibleForms\Admin;

use AccessibleForms\Entries;
use AccessibleForms\Spam;
use AccessibleForms\Capabilities;
use AccessibleForms\Notifications;
use AccessibleForms\Audit;
use AccessibleForms\Extensions;
use WP_List_Table;

if ( ! defined( 'ABSPATH' ) ) {
	exit();
}

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

/**
 * Stored submissions.
 */
class EntriesTable extends WP_List_Table {
	const SLUG = 'accessible-forms-entries';

	/**
	 * Constructor.
	 */
	public function __construct() {
		parent::__construct(
			array(
				'singular' => 'entry',
				'plural'   => 'entries',
				'ajax'     => false,
			)
		);
	}

	/**
	 * Admin URL for the entries list.
	 *
	 * @param array $args Extra query arguments.
	 * @return string
	 */
	public static function url( array $args = array() ) {
		// add_query_arg() expects encoded values: a search for "tom & jerry" or "C++"
		// must stay one value on every generated link.
		return add_query_arg(
			urlencode_deep(
				array_merge(
					array(
						'post_type' => 'accessible_form',
						'page'      => self::SLUG,
					),
					$args
				)
			),
			// The screen sits under the Forms menu (edit.php?post_type=...). WordPress
			// cannot resolve admin.php with a post_type for such a screen.
			admin_url( 'edit.php' )
		);
	}

	/**
	 * Column definitions.
	 *
	 * @return array
	 */
	public function get_columns() {
		$columns = array(
			'cb'         => '<input type="checkbox">',
			'summary'    => __( 'Submission', 'accessible-forms-by-accessible-org' ),
			'form'       => __( 'Form', 'accessible-forms-by-accessible-org' ),
			'created_at' => __( 'Received', 'accessible-forms-by-accessible-org' ),
			'delivery'   => __( 'Notification', 'accessible-forms-by-accessible-org' ),
		);
		// Add-ons may add columns, such as follow-up progress.
		return (array) Extensions::filter( 'accessible_forms_entry_columns', $columns );
	}

	/**
	 * Sortable columns.
	 *
	 * @return array
	 */
	protected function get_sortable_columns() {
		return array(
			'created_at' => array( 'created_at', true ),
		);
	}

	/**
	 * Bulk actions.
	 *
	 * @return array
	 */
	protected function get_bulk_actions() {
		$actions = array();
		if ( current_user_can( 'manage_accessible_form_entries' ) ) {
			$actions = array(
				'read'   => __( 'Mark as read', 'accessible-forms-by-accessible-org' ),
				'unread' => __( 'Mark as unread', 'accessible-forms-by-accessible-org' ),
				'spam'   => __( 'Mark as spam', 'accessible-forms-by-accessible-org' ),
				'ham'    => __( 'Accept / restore without notifying', 'accessible-forms-by-accessible-org' ),
			);
		}
		if ( current_user_can( 'delete_accessible_form_entries' ) ) {
			$actions['trash'] = __( 'Move to Trash', 'accessible-forms-by-accessible-org' );
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Read-only list view state; actions verify their own nonce.
			if ( 'trash' === sanitize_key( wp_unslash( $_GET['status'] ?? '' ) ) ) {
				$actions['delete'] = __( 'Delete permanently', 'accessible-forms-by-accessible-org' );
			}
		}
		return (array) Extensions::filter( 'accessible_forms_entry_bulk_actions', $actions );
	}

	/**
	 * Status filter links above the table.
	 *
	 * @return array
	 */
	protected function get_views() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$current = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only list filters.
		$filters = array(
			'form_id' => isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0,
			'search'  => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
		);
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$filters = array_merge( $filters, self::extra_filters() );
		$counts  = array();
		foreach ( array( '', 'received', 'unread', 'review', 'spam', 'trash' ) as $status ) {
			$counts[ $status ] = Entries::count(
				Capabilities::query( array_merge( $filters, array( 'status' => $status ) ) )
			);
		}

		$labels = array(
			''         => __( 'All', 'accessible-forms-by-accessible-org' ),
			'received' => __( 'Received', 'accessible-forms-by-accessible-org' ),
			'unread'   => __( 'Unread', 'accessible-forms-by-accessible-org' ),
			'spam'     => __( 'Spam', 'accessible-forms-by-accessible-org' ),
			'review'   => __( 'Needs review', 'accessible-forms-by-accessible-org' ),
			'trash'    => __( 'Trash', 'accessible-forms-by-accessible-org' ),
		);

		$views = array();

		foreach ( $labels as $key => $label ) {
			$views[ $key ? $key : 'all' ] = sprintf(
				'<a href="%s"%s>%s <span class="count">(%s)</span></a>',
				esc_url(
					self::url(
						array_merge(
							self::extra_filters(),
							array(
								'status'  => $key,
								'form_id' => $filters['form_id'],
								's'       => $filters['search'],
							)
						)
					)
				),
				$current === $key ? ' class="current" aria-current="page"' : '',
				esc_html( $label ),
				esc_html( number_format_i18n( $counts[ $key ] ) )
			);
		}

		return $views;
	}

	/**
	 * Row checkbox.
	 *
	 * @param array $item Entry row.
	 * @return string
	 */
	protected function column_cb( $item ) {
		return sprintf(
			'<label class="screen-reader-text" for="entry-%1$s">%2$s</label>' .
				'<input type="checkbox" id="entry-%1$s" name="entry[]" value="%1$s">',
			esc_attr( (string) $item['id'] ),
			esc_html(
				sprintf(
					/* translators: %s: entry ID. */
					__( 'Select entry %s', 'accessible-forms-by-accessible-org' ),
					$item['id']
				)
			)
		);
	}

	/**
	 * The primary column: a readable précis plus row actions.
	 *
	 * @param array $item Entry row.
	 * @return string
	 */
	protected function column_summary( $item ) {
		$parts = array();

		foreach ( Entries::display_values( $item ) as $key => $value ) {
			$value = is_array( $value ) ? implode( ', ', $value ) : (string) $value;

			if ( '' === trim( $value ) ) {
				continue;
			}

			$parts[] = wp_trim_words( $value, count( $parts ) ? 12 : 8 );

			if ( count( $parts ) >= 3 ) {
				break;
			}
		}

		// The first answer (usually a name) is the link; the next ones give context.
		$first  = $parts ? array_shift( $parts ) : __( '(no values)', 'accessible-forms-by-accessible-org' );
		$url    = EntryView::url( $item['id'], Inbox::current() );
		$unread = empty( $item['is_read'] ) && 'spam' !== $item['status'];

		$title = sprintf( '<strong><a class="row-title" href="%s">%s</a></strong>', esc_url( $url ), esc_html( $first ) );

		if ( $unread ) {
			$title .=
				' <span class="af-badge af-badge--info af-unread-label">' . esc_html__( 'Unread', 'accessible-forms-by-accessible-org' ) . '</span>';
		}
		if ( $parts ) {
			$title .= '<span class="af-entry-precis">' . esc_html( implode( ' · ', $parts ) ) . '</span>';
		}

		return $title;
	}

	/** Render row actions once; row_actions() also supplies the native mobile toggle. */
	protected function handle_row_actions( $item, $column_name, $primary ) {
		if ( $column_name !== $primary ) {
			return '';
		}
		$actions = array(
			'view' => sprintf( '<a href="%s">%s</a>', esc_url( EntryView::url( $item['id'], Inbox::current() ) ), esc_html__( 'View', 'accessible-forms-by-accessible-org' ) ),
		);
		return $this->row_actions( $actions, true );
	}

	/**
	 * Default column renderer.
	 *
	 * @param array  $item   Entry row.
	 * @param string $column Column key.
	 * @return string
	 */
	protected function column_default( $item, $column ) {
		switch ( $column ) {
			case 'created_at':
				$timestamp = \AccessibleForms\EntryTime::timestamp( $item );
				if ( null === $timestamp ) { return esc_html( \AccessibleForms\EntryTime::display( $item ) ); }

				return esc_html(
					sprintf(
						/* translators: %s: human-readable time difference. */
						__( '%s ago', 'accessible-forms-by-accessible-org' ),
						human_time_diff( $timestamp, time() )
					)
				) .
					'<span class="af-cell-meta">' .
					esc_html( wp_date( get_option( 'date_format' ), $timestamp ) ) .
					'</span>';

			case 'form':
				$title = $item['snapshot']['title'] ?? get_the_title( $item['form_id'] );

				return esc_html( $title ? $title : __( '(deleted form)', 'accessible-forms-by-accessible-org' ) );

			case 'delivery':
				if ( 'review' === $item['status'] ) {
					return '<span class="af-badge af-badge--warn">' . esc_html__( 'Needs review', 'accessible-forms-by-accessible-org' ) . '</span>';
				}
				if ( 'queued' === $item['mail_status'] ) {
					return '<span class="af-badge af-badge--neutral">' . esc_html__( 'Queued', 'accessible-forms-by-accessible-org' ) . '</span>';
				}
				if ( 'uncertain' === $item['mail_status'] ) {
					return '<span class="af-badge af-badge--warn">' . esc_html__( 'Delivery uncertain', 'accessible-forms-by-accessible-org' ) . '</span>';
				}
				if ( 'spam' === $item['status'] ) {
					$labels = Spam::reason_labels() + array( 'manual' => __( 'Marked by hand', 'accessible-forms-by-accessible-org' ) );
					$reason = $item['spam_reason']
						? $labels[ $item['spam_reason'] ] ?? $item['spam_reason']
						: '';

					return '<span class="af-badge af-badge--neutral">' .
						esc_html__( 'Spam', 'accessible-forms-by-accessible-org' ) .
						'</span>' .
						( $reason ? '<span class="af-cell-meta">' . esc_html( $reason ) . '</span>' : '' );
				}

				if ( 'failed' === $item['mail_status'] ) {
					return '<span class="af-badge af-badge--error">' .
						esc_html__( 'Email failed', 'accessible-forms-by-accessible-org' ) .
						'</span>' .
						'<span class="af-cell-meta">' .
						esc_html__( 'Entry was still stored', 'accessible-forms-by-accessible-org' ) .
						'</span>';
				}

				if ( 'sent' === $item['mail_status'] ) {
					return '<span class="af-badge af-badge--ok">' .
						esc_html__( 'Accepted by mail service', 'accessible-forms-by-accessible-org' ) .
						'</span>';
				}
				if ( 'skipped' === $item['mail_status'] ) {
					return '<span class="af-muted">' . esc_html__( 'Not sent', 'accessible-forms-by-accessible-org' ) . '</span>';
				}

				return '<span class="af-muted">' . esc_html__( 'Unknown', 'accessible-forms-by-accessible-org' ) . '</span>';
		}

		// Add-on columns render themselves.
		return (string) Extensions::filter( 'accessible_forms_entry_column', '', $column, $item );
	}

	/**
	 * Highlight unread rows.
	 *
	 * @param array $item Entry row.
	 */
	public function single_row( $item ) {
		$classes = empty( $item['is_read'] ) && 'spam' !== $item['status'] ? 'af-unread' : '';

		echo '<tr id="af-entry-row-' . esc_attr( $item['id'] ) . '" class="' . esc_attr( $classes ) . '">';
		$this->single_row_columns( $item );
		echo '</tr>';
	}

	/**
	 * Load rows.
	 */
	public function prepare_items() {
		$per_page = 20;
		$paged    = $this->get_pagenum();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only filters.
		$args = array(
			'form_id'  => isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0,
			'status'   => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
			'search'   => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'orderby'  => isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'created_at',
			'order'    => isset( $_GET['order'] ) ? sanitize_key( wp_unslash( $_GET['order'] ) ) : 'desc',
			'per_page' => $per_page,
			'page'     => $paged,
		);
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		$args  = Capabilities::query( array_merge( $args, self::extra_filters() ) );
		$total = Entries::count( $args );

		$this->items           = Entries::query( $args );
		$this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns(), 'summary' );

		$this->set_pagination_args(
			array(
				'total_items' => $total,
				'per_page'    => $per_page,
				'total_pages' => (int) ceil( $total / $per_page ),
			)
		);
	}

	/**
	 * Process a bulk action.
	 */
	private function handle_bulk_action() {
		$action = $this->current_action();

		$core = in_array( $action, array( 'read', 'unread', 'spam', 'ham', 'delete', 'trash' ), true );
		if ( ! $core && ! isset( $this->get_bulk_actions()[ $action ] ) ) {
			return false;
		}

		check_admin_referer( 'bulk-' . $this->_args['plural'] );

		if ( ! current_user_can( 'read_accessible_form_entries' ) ) {
			wp_die( esc_html__( 'You do not have permission to do that.', 'accessible-forms-by-accessible-org' ) );
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- Verified above.
		$ids = isset( $_REQUEST['entry'] ) ? array_map( 'intval', (array) wp_unslash( $_REQUEST['entry'] ) ) : array();

		if ( ! $ids ) {
			return false;
		}
		// An add-on's bulk action checks its own permissions and returns a result notice key.
		if ( ! $core ) {
			return (string) Extensions::filter( 'accessible_forms_entry_bulk', 'updated', $action, $ids );
		}

		return Experience::bulk( $action, $ids );
	}

	/**
	 * On the Spam and Needs review views, say when messages are deleted.
	 *
	 * @param string $status Current status filter.
	 */
	private static function held_notice( $status ) {
		if ( ! in_array( $status, array( 'spam', 'review' ), true ) ) {
			return;
		}
		$days   = Entries::held_retention_days();
		$counts = Entries::held_counts( $status, 7 );

		echo '<div class="notice ' . ( $counts['expiring'] > 0 ? 'notice-warning' : 'notice-info' ) . ' inline af-held-notice"><p>' .
			esc_html(
				sprintf(
					/* translators: %d: number of days. */
					_n(
						'Messages here are deleted automatically %d day after they arrive.',
						'Messages here are deleted automatically %d days after they arrive.',
						$days,
						'accessible-forms-by-accessible-org'
					),
					$days
				)
			) .
			' <strong>' .
			esc_html(
				sprintf(
					/* translators: %d: number of messages. */
					_n(
						'%d will be deleted in the next 7 days.',
						'%d will be deleted in the next 7 days.',
						$counts['expiring'],
						'accessible-forms-by-accessible-org'
					),
					$counts['expiring']
				)
			) .
			'</strong> ';
		if ( 'review' === $status ) {
			esc_html_e( 'Open a message and accept it to keep it with your received submissions.', 'accessible-forms-by-accessible-org' );
		}
		if ( current_user_can( 'manage_accessible_forms_settings' ) ) {
			echo ' <a href="' .
				esc_url( SettingsPage::url( 'privacy' ) . '#af-spam_retention_days' ) .
				'">' .
				esc_html__( 'Change how long these messages are kept', 'accessible-forms-by-accessible-org' ) .
				'</a>';
		}
		echo '</p></div>';
	}

	/** Handle changes before output, then remove the action from the URL. */
	public static function process_actions() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Routing only; the action verifies its nonce before modifying entries.
		if ( ! isset( $_GET['page'] ) || self::SLUG !== sanitize_key( wp_unslash( $_GET['page'] ) ) ) {
			return;
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		$table  = new self();
		$result = $table->handle_bulk_action();
		if ( ! $result ) {
			return;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Nonce checked in handle_bulk_action().
		$filters = array(
			'form_id'   => isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0,
			'status'    => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '',
			's'         => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'af_notice' => $result,
		);
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		wp_safe_redirect( self::url( array_merge( self::extra_filters(), $filters ) ) );
		exit();
	}

	/** Search filters sit above the table, separate from bulk actions. */
	private function render_filters() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display only.
		$current_form = isset( $_GET['form_id'] ) ? (int) $_GET['form_id'] : 0;

		$forms = get_posts(
			array(
				'post_type'      => 'accessible_form',
				'post_status'    => array( 'publish', 'draft', 'pending', 'future', 'private', 'trash' ),
				'posts_per_page' => -1,
				'orderby'        => 'title',
				'order'          => 'ASC',
			)
		);

		echo '<div class="af-entry-filters">';
		echo '<span class="af-filter-field"><label for="af-filter-form">' .
			esc_html__( 'Form', 'accessible-forms-by-accessible-org' ) .
			'</label>';
		echo '<select name="form_id" id="af-filter-form">';
		echo '<option value="0">' . esc_html__( 'All forms', 'accessible-forms-by-accessible-org' ) . '</option>';

		foreach ( $forms as $form ) {
			if ( ! Capabilities::form( $form->ID ) ) {
				continue;
			}
			echo '<option value="' .
				esc_attr( (string) $form->ID ) .
				'"' .
				selected( $current_form, $form->ID, false ) .
				'>' .
				esc_html( $form->post_title ) .
				'</option>';
		}

		echo '</select></span>';
		echo '<span class="af-filter-actions">';
		submit_button( __( 'Filter', 'accessible-forms-by-accessible-org' ), '', 'filter_action', false );
		$active_filters            = array_merge( self::extra_filters(), Inbox::current() );
		$active_filters['form_id'] = $active_filters['form_id'] ?: '';
		// Paging and sorting are not filters; clearing them would be a surprise.
		unset( $active_filters['paged'], $active_filters['orderby'], $active_filters['order'] );
		if ( array_filter( $active_filters, static fn( $value ) => '' !== (string) $value ) ) {
			echo '<a class="af-clear-filters" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Clear filters', 'accessible-forms-by-accessible-org' ) . '</a>';
		}
		echo '</span></div>';
		$advanced = array_filter( self::extra_filters(), static fn( $value ) => '' !== (string) $value );
		echo '<details class="af-more-filters" id="af-entry-more-filters"' . ( $advanced ? ' open' : '' ) . '><summary id="af-entry-more-filters-toggle">' . esc_html__( 'More filters', 'accessible-forms-by-accessible-org' );
		if ( $advanced ) {
			/* translators: %s: number of active advanced filters. */
			echo ' <span class="af-filter-active-count">' . esc_html( sprintf( __( '(%s active)', 'accessible-forms-by-accessible-org' ), number_format_i18n( count( $advanced ) ) ) ) . '</span>';
		}
		echo '</summary><div class="af-advanced-filters">';
		self::filter_controls();
		echo '</div></details>';
		$today = new \DateTimeImmutable( 'today', wp_timezone() );
		echo '<nav class="af-date-shortcuts" aria-label="' . esc_attr__( 'Entry date shortcuts', 'accessible-forms-by-accessible-org' ) . '">';
		foreach ( array( 1 => __( 'Today', 'accessible-forms-by-accessible-org' ), 7 => __( 'Last 7 days', 'accessible-forms-by-accessible-org' ), 30 => __( 'Last 30 days', 'accessible-forms-by-accessible-org' ) ) as $days => $label ) {
			$range = Inbox::url_filters( Inbox::current() );
			unset( $range['paged'] );
			$range['date_from'] = $today->modify( '-' . ( $days - 1 ) . ' days' )->format( 'Y-m-d' );
			$range['date_to'] = $today->format( 'Y-m-d' );
			echo '<a href="' . esc_url( self::url( $range ) ) . '">' . esc_html( $label ) . '</a>';
		}
		echo '</nav>';
	}

	/**
	 * Empty state.
	 */
	public function no_items() {
		$filters = Inbox::current();
		$extra = self::extra_filters();
		$filtered = ! empty( $filters['search'] ) || array_filter( $extra, static fn( $value ) => '' !== (string) $value );
		$status = $filters['status'] ?? '';
		if ( $filtered ) {
			echo '<strong class="af-empty-title">' . esc_html__( 'No entries match these filters', 'accessible-forms-by-accessible-org' ) . '</strong><p>' . esc_html__( 'Try a broader date range, a different search, or clear your filters.', 'accessible-forms-by-accessible-org' ) . '</p><a class="button" href="' . esc_url( self::url() ) . '">' . esc_html__( 'Clear filters', 'accessible-forms-by-accessible-org' ) . '</a>'; return;
		}
		$empty = array(
			'unread' => array( __( 'No unread submissions', 'accessible-forms-by-accessible-org' ), __( 'Received submissions you have not opened appear here. Use Received to revisit messages you have already read.', 'accessible-forms-by-accessible-org' ) ),
			'spam' => array( __( 'No spam to review', 'accessible-forms-by-accessible-org' ), __( 'Messages marked as spam will appear here. You can review and accept them before their retention period ends.', 'accessible-forms-by-accessible-org' ) ),
			'review' => array( __( 'No messages need review', 'accessible-forms-by-accessible-org' ), __( 'Messages with incomplete verification will appear here for you to review.', 'accessible-forms-by-accessible-org' ) ),
			'trash' => array( __( 'Trash is empty', 'accessible-forms-by-accessible-org' ), __( 'Entries moved to Trash will appear here and can be restored before they are deleted.', 'accessible-forms-by-accessible-org' ) ),
		);
		if ( isset( $empty[ $status ] ) ) { echo '<strong class="af-empty-title">' . esc_html( $empty[ $status ][0] ) . '</strong><p>' . esc_html( $empty[ $status ][1] ) . '</p>'; return; }
		echo '<strong class="af-empty-title">' . esc_html__( 'No submissions yet', 'accessible-forms-by-accessible-org' ) . '</strong><p>' . esc_html__( 'Publish and place your form, then send a test submission from its page. Your stored message will appear here.', 'accessible-forms-by-accessible-org' ) . '</p>';
		$form_id = $filters['form_id'];
		if ( $form_id && PlacementScreen::can_view() && \AccessibleForms\Schema::get( $form_id ) ) {
			echo '<p><a class="button" href="' . esc_url( Placement::url( $form_id ) ) . '">' . esc_html__( 'Choose where this form appears', 'accessible-forms-by-accessible-org' ) . '</a></p>';
		}
		echo '<p><a href="' . esc_url( admin_url( 'edit.php?post_type=accessible_form' ) ) . '">' . esc_html__( 'Manage your forms', 'accessible-forms-by-accessible-org' ) . '</a></p>';
	}

	/** Filter summaries are server-rendered links and also work without JavaScript. */
	private function filter_summary() {
		$filters = Inbox::url_filters( Inbox::current() );
		$names = array( 'status' => __( 'Status', 'accessible-forms-by-accessible-org' ), 'form_id' => __( 'Form', 'accessible-forms-by-accessible-org' ), 's' => __( 'Search', 'accessible-forms-by-accessible-org' ), 'date_from' => __( 'From', 'accessible-forms-by-accessible-org' ), 'date_to' => __( 'To', 'accessible-forms-by-accessible-org' ), 'mail_status' => __( 'Notification', 'accessible-forms-by-accessible-org' ), 'workflow' => __( 'Progress', 'accessible-forms-by-accessible-org' ), 'assignee' => __( 'Assignee', 'accessible-forms-by-accessible-org' ) );
		/* translators: %s: localized number of matching entries. */
		echo '<div class="af-filter-summary"><p id="af-result-summary">' . esc_html( sprintf( _n( '%s entry matches', '%s entries match', $this->get_pagination_arg( 'total_items' ), 'accessible-forms-by-accessible-org' ), number_format_i18n( $this->get_pagination_arg( 'total_items' ) ) ) ) . '</p><ul aria-label="' . esc_attr__( 'Active filters', 'accessible-forms-by-accessible-org' ) . '">';
		foreach ( $names as $key => $name ) {
			if ( ! isset( $filters[ $key ] ) || '' === (string) $filters[ $key ] || ( 'form_id' === $key && ! $filters[ $key ] ) ) { continue; }
			$value = $filters[ $key ];
			if ( 'form_id' === $key ) { $value = Capabilities::form( (int) $value ) ? ( get_the_title( (int) $value ) ?: __( '(deleted form)', 'accessible-forms-by-accessible-org' ) ) : __( 'Selected form', 'accessible-forms-by-accessible-org' ); }
			/* translators: %d: member account ID. */
			elseif ( 'assignee' === $key ) { $value = '0' === (string) $value ? __( 'Unassigned', 'accessible-forms-by-accessible-org' ) : sprintf( __( 'Member #%d', 'accessible-forms-by-accessible-org' ), (int) $value ); }
			elseif ( in_array( $key, array( 'status', 'workflow', 'mail_status' ), true ) ) {
				$labels = array( 'received' => __( 'Received', 'accessible-forms-by-accessible-org' ), 'unread' => __( 'Unread', 'accessible-forms-by-accessible-org' ), 'review' => __( 'Needs review', 'accessible-forms-by-accessible-org' ), 'spam' => __( 'Spam', 'accessible-forms-by-accessible-org' ), 'trash' => __( 'Trash', 'accessible-forms-by-accessible-org' ), 'new' => __( 'New', 'accessible-forms-by-accessible-org' ), 'in_progress' => __( 'In progress', 'accessible-forms-by-accessible-org' ), 'resolved' => __( 'Resolved', 'accessible-forms-by-accessible-org' ), 'queued' => __( 'Queued', 'accessible-forms-by-accessible-org' ), 'sent' => __( 'Accepted', 'accessible-forms-by-accessible-org' ), 'failed' => __( 'Failed', 'accessible-forms-by-accessible-org' ), 'uncertain' => __( 'Uncertain', 'accessible-forms-by-accessible-org' ) );
				$value = $labels[ $value ] ?? $value;
			}
			$remaining = $filters; unset( $remaining[ $key ], $remaining['paged'] );
			$text = $name . ': ' . $value;
			/* translators: %s: filter name and selected value. */
			echo '<li><a class="af-filter-chip" href="' . esc_url( self::url( $remaining ) ) . '" aria-label="' . esc_attr( sprintf( __( 'Remove filter: %s', 'accessible-forms-by-accessible-org' ), $text ) ) . '"><span>' . esc_html( $text ) . '</span><span aria-hidden="true" class="dashicons dashicons-no-alt"></span></a></li>';
		}
		echo '</ul></div>';
	}

	/**
	 * Render the entries screen.
	 */
	public static function render_page() {
		if ( ! current_user_can( 'read_accessible_form_entries' ) ) {
			wp_die( esc_html__( 'You do not have permission to view this page.', 'accessible-forms-by-accessible-org' ) );
		}

		$table = new self();
		$table->prepare_items();

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only list view state; actions verify their own nonce.
		$form_id = isset( $_GET['form_id'] ) ? absint( $_GET['form_id'] ) : 0;
		$status  = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '';
		$notice  = isset( $_GET['af_notice'] ) ? sanitize_key( wp_unslash( $_GET['af_notice'] ) ) : '';
		// phpcs:enable WordPress.Security.NonceVerification.Recommended

		echo '<div class="wrap af-entries af-entry-list">';
		echo '<h1 class="wp-heading-inline">' . esc_html__( 'Entries', 'accessible-forms-by-accessible-org' ) . '</h1>';
		// Add-ons add page actions here, such as an export.
		Extensions::notify( 'accessible_forms_entries_page_actions', $form_id, $status );
		echo '<hr class="wp-header-end"><p class="af-page-description">' .
			esc_html__(
				'Review messages from all your forms. Search and filter the entries you need.',
				'accessible-forms-by-accessible-org'
			) .
			'</p>';

		if ( 'deleted' === $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' .
				esc_html__( 'Entry deleted.', 'accessible-forms-by-accessible-org' ) .
				'</p></div>';
		}
		if ( ! Experience::notice() && 'updated' === $notice ) {
			echo '<div class="notice notice-success is-dismissible"><p>' .
				esc_html__( 'Selected entries updated.', 'accessible-forms-by-accessible-org' ) .
				'</p></div>';
		}
		// Add-ons explain the outcome of their own bulk actions.
		Extensions::notify( 'accessible_forms_entries_notice', $notice );
		self::held_notice( $status );
		if ( Entries::count( Capabilities::query( array( 'form_id' => $form_id, '_unconfirmed_time' => true ) ) ) ) {
			echo '<div class="notice notice-info inline"><p>' . esc_html__( 'Some historical entry dates have an unconfirmed time zone. Their saved calendar values remain visible, but chronological sorting is approximate until their original zone is confirmed.', 'accessible-forms-by-accessible-org' );
			if ( current_user_can( 'manage_accessible_forms_settings' ) ) { echo ' <a href="' . esc_url( Management::url( 'health' ) ) . '">' . esc_html__( 'Review historical dates', 'accessible-forms-by-accessible-org' ) . '</a>'; }
			echo '</p></div>';
		}

		Inbox::render();
		echo '<nav class="af-list-views" aria-label="' . esc_attr__( 'Filter entries by status', 'accessible-forms-by-accessible-org' ) . '">';
		$table->views();
		echo '</nav>';

		echo '<form method="get" id="af-entries-form">';
		echo '<input type="hidden" name="post_type" value="accessible_form">';
		echo '<input type="hidden" name="page" value="' . esc_attr( self::SLUG ) . '">';

		if ( $status ) {
			echo '<input type="hidden" name="status" value="' . esc_attr( $status ) . '">';
		}

		echo '<div class="af-list-toolbar">';
		$table->search_box( __( 'Search entries', 'accessible-forms-by-accessible-org' ), 'af-entry-search' );
		$table->render_filters();
		echo '</div>';
		$table->filter_summary();
		echo '<p id="af-selection-status" class="af-selection-status" role="status" hidden></p>';
		$table->display();

		echo '</form></div>';
	}

	public static function extra_filters() {
		$args = array();
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- Read-only allowlisted filters; database queries enforce capabilities.
		foreach ( (array) Extensions::filter( 'accessible_forms_entry_filter_keys', array( 'date_from', 'date_to', 'mail_status' ) ) as $key ) {
			if ( isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ) {
				$args[ $key ] = sanitize_text_field( wp_unslash( $_GET[ $key ] ) );
			}
		}
		// phpcs:enable WordPress.Security.NonceVerification.Recommended
		return $args;
	}
	private static function filter_controls() {
		$filters = self::extra_filters();
		foreach (
			array(
				/* translators: Visible label before the start date of the received-date filter. */
				'date_from' => _x( 'From', 'received date filter', 'accessible-forms-by-accessible-org' ),
				/* translators: Visible label before the end date of the received-date filter. */
				'date_to'   => _x( 'To', 'received date filter', 'accessible-forms-by-accessible-org' ),
			)
			as $key => $label
		) {
			// A visible label: an empty date field alone does not say which end of the range it sets.
			echo '<span class="af-filter-field af-date-filter"><label for="af-filter-' .
				esc_attr( $key ) .
				'">' .
				esc_html( $label ) .
				'<span class="screen-reader-text"> ' .
				esc_html__( 'received date', 'accessible-forms-by-accessible-org' ) .
				'</span></label><input type="date" id="af-filter-' .
				esc_attr( $key ) .
				'" name="' .
				esc_attr( $key ) .
				'" value="' .
				esc_attr( $filters[ $key ] ?? '' ) .
				'"></span> ';
		}
		foreach (
			array(
				'mail_status' => array(
					''          => __( 'All notifications', 'accessible-forms-by-accessible-org' ),
					'queued'    => __( 'Queued', 'accessible-forms-by-accessible-org' ),
					'sent'      => __( 'Accepted', 'accessible-forms-by-accessible-org' ),
					'failed'    => __( 'Failed', 'accessible-forms-by-accessible-org' ),
					'uncertain' => __( 'Uncertain', 'accessible-forms-by-accessible-org' ),
				),
			)
			as $key => $options
		) {
			echo '<span class="af-filter-field"><label for="af-filter-' .
				esc_attr( $key ) .
				'">' .
				esc_html__( 'Notification', 'accessible-forms-by-accessible-org' ) .
				'</label><select name="' .
				esc_attr( $key ) .
				'" id="af-filter-' .
				esc_attr( $key ) .
				'">';
			foreach ( $options as $value => $label ) {
				echo '<option value="' .
					esc_attr( (string) $value ) .
					'"' .
					selected( $filters[ $key ] ?? '', (string) $value, false ) .
					'>' .
					esc_html( $label ) .
					'</option>';
			}
			echo '</select></span> ';
		}
		// Add-ons add filters of their own, such as progress or assignee.
		Extensions::notify( 'accessible_forms_entry_filter_controls', $filters );
	}

}
